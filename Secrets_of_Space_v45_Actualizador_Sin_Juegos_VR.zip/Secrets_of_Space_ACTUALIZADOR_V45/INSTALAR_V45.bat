@echo off
setlocal
chcp 65001 >nul
set TARGET=C:\xampp\htdocs\planetas
if not "%~1"=="" set TARGET=%~1
cls
echo ====================================
echo    SECRETS OF SPACE - v45
 echo REALIDAD VIRTUAL SIN JUEGOS
 echo ====================================
 echo Proyecto: %TARGET%
 echo.
py "%~dp0aplicar_v45_sin_juegos_vr.py" "%TARGET%"
echo.
pause
