#!/usr/bin/env python3
"""Secrets of Space v45: remove only quizzes and mini-games inside Realidad Virtual.
Preserves all five games in Aventuras en el espacio, 3D models and progress.
Compatible with structured v40-v44 style project trees with `assets/js/pages/`.
"""
from __future__ import annotations
from pathlib import Path
import re,sys,tempfile,shutil
from datetime import datetime

DEFAULT = Path('C:/xampp/htdocs/planetas')
MARKER = '<!-- SOS v45: Realidad Virtual sin cuestionarios ni retos -->'
FILES = [
    'realidad-virtual.php',
    'assets/js/pages/realidad-virtual.js',
    'assets/js/data/catalogo-realidad-virtual.js',
    'assets/js/core/idiomas.js',
]

def remove_html_div(html: str, class_name: str) -> str:
    entry = re.search(r'<div\b[^>]*\bclass=["\'][^"\']*\b'+re.escape(class_name)+r'\b[^"\']*["\'][^>]*>',html,re.I)
    if not entry:
        if re.search(r'id=["\']vr-quiz-open["\']',html):
            raise ValueError('Se encontró parte del cuestionario pero no el contenedor de la actividad.')
        return html
    depth=0; end=None
    for tag in re.finditer(r'</?div\b[^>]*>',html[entry.start():],re.I):
        if tag.group().lower().startswith('</'):depth-=1
        else:depth+=1
        if depth==0:
            end=entry.start()+tag.end();break
    if end is None: raise ValueError('No fue posible cerrar la sección del cuestionario sin riesgo.')
    return html[:entry.start()]+html[end:]

def function_bounds(js: str,name: str):
    m=re.search(r'(?m)^function\s+'+re.escape(name)+r'\s*\([^)]*\)\s*\{',js)
    if not m:return None
    depth=0
    for i in range(m.end()-1,len(js)):
        if js[i]=='{': depth+=1
        if js[i]=='}':
            depth-=1
            if depth==0:return m.start(),i+1
    raise ValueError('La función '+name+' no tiene cierre reconocido.')

def remove_function(js,name):
    bounds=function_bounds(js,name)
    if not bounds: return js
    a,b=bounds
    return js[:a]+js[b:].lstrip('\n')

def replace_function(js,name,replacement):
    bounds=function_bounds(js,name)
    if not bounds: raise ValueError('No se encontró la función '+name+'; requiere revisar compatibilidad.')
    a,b=bounds
    return js[:a]+replacement+js[b:]

def transform_html(html):
    if MARKER in html and 'learning-challenge' not in html:return html
    old=html
    html=remove_html_div(html,'learning-challenge')
    if html==old and 'vr-quiz-open' not in old:
        # Some branches may have already removed the quiz.
        pass
    html=html.replace('03 · SUPERA EL RETO','03 · CONOCE SUS HISTORIAS')
    html=re.sub(r'(assets/js/pages/realidad-virtual\.js\?v=)[\w.-]+',r'\g<1>45',html)
    html=re.sub(r'(assets/js/core/idiomas\.js\?v=)[\w.-]+',r'\g<1>45',html)
    if MARKER not in html:html=html.replace('</head>',MARKER+'\n</head>',1)
    if 'vr-quiz-open' in html or 'learning-challenge' in html:raise ValueError('Quedó una sección de cuestionario en realidad-virtual.php.')
    return html

def transform_controller(js):
    js=re.sub(r'\bquizDone\s*:\s*\{\s*moon\s*:\s*false\s*,\s*mars\s*:\s*false\s*\}\s*,\s*','',js)
    js=re.sub(r'\bquizOpen\s*:\s*false\s*,\s*','',js)
    update="""function updateProgress(){
 const cur=state.discovered[state.world].size,total=WORLDS[state.world].items.length;
 el('vr-progress-top').textContent=`${cur} / ${total}`;
 el('vr-progress-label').textContent=window.CosmicI18n?.lang()==='en'?`${cur} of ${total}`:`${cur} de ${total}`;
 el('vr-progress-bar').style.width=`${(cur/total)*100}%`;
 if(cur===total)toast(window.CosmicI18n?.lang()==='en'?'Expedition complete! All records have been discovered.':'¡Archivo explorado por completo! Ya conoces todos los registros de esta expedición.');
}"""
    if 'function updateProgress' in js:js=replace_function(js,'updateProgress',update)
    else:raise ValueError('No se encontró updateProgress().')
    js=remove_function(js,'showQuiz')
    js=remove_function(js,'resetQuiz')
    js=re.sub(r'(?m)^[ \t]*el\(["\']vr-quiz-open["\']\)\.addEventListener\(["\']click["\'],\s*showQuiz\);[ \t]*\n?','',js)
    js=re.sub(r'(?m)^[ \t]*if\(state\.quizOpen\)\s*showQuiz\(\);\s*\n?','',js)
    js=re.sub(r'\bresetQuiz\(\);\s*','',js)
    if re.search(r'\b(?:quizDone|quizOpen|showQuiz|resetQuiz|vr-quiz-open|vr-challenge-status|vr-challenge-copy)\b',js):
        raise ValueError('Quedaron referencias al juego en el controlador: se canceló por seguridad.')
    return js

def transform_catalog(data):
    data,n=re.subn(r'(?m)^\s*quiz\s*:\s*\{[^\n]*\}\s*,\s*\n','',data)
    if n==0 and re.search(r'\bquiz\s*:',data):raise ValueError('Estructura del catálogo de preguntas incompatible.')
    data=data.replace('Misiones visibles en Realidad Virtual: Luna, Marte y preguntas de repaso.','Misiones visibles en Realidad Virtual: exploración científica de Luna y Marte.')
    return data

def transform_language(text):
    text=text.replace("'vr.step3':'03 · COMPLETE THE CHALLENGE'", "'vr.step3':'03 · LEARN THEIR STORIES'")
    # Old quiz keys are unused after v45. Remove each entry without modifying the mission translations.
    key_pattern=r"(?:,)?'vr\.(?:challenge|unlock|quiz\.[^']+|(?:moon|mars)\.(?:question|answers\.\d+|explanation))'\s*:\s*'(?:\\.|[^'\\])*'"
    text=re.sub(key_pattern,'',text)
    # Each removed translation occupied a full line ending in a comma.
    # Strip orphan separators without touching live translation entries.
    text=re.sub(r'(?m)^[ \t]*,[ \t]*\n','',text)
    return text

def transform_all(contents):
    out={
        FILES[0]:transform_html(contents[FILES[0]]),
        FILES[1]:transform_controller(contents[FILES[1]]),
        FILES[2]:transform_catalog(contents[FILES[2]]),
        FILES[3]:transform_language(contents[FILES[3]])
    }
    return out

def main():
    target=Path(sys.argv[1]).expanduser().resolve() if len(sys.argv)>1 else DEFAULT.resolve()
    if not target.is_dir():print('ERROR: no existe la carpeta de Secrets of Space:',target);return 2
    files={rel:target/rel for rel in FILES}
    missing=[rel for rel,path in files.items() if not path.is_file()]
    if missing:print('ERROR: faltan estos archivos; NO se modificó nada:',', '.join(missing));return 3
    try:
        originals={rel:path.read_text(encoding='utf-8') for rel,path in files.items()}
        if MARKER in originals[FILES[0]] and not re.search(r'\b(?:quizOpen|quizDone|showQuiz|resetQuiz)\b',originals[FILES[1]]):
            print('La v45 ya está aplicada. No se modificó ningún archivo.');return 0
        changes=transform_all(originals)
    except (OSError,UnicodeError,ValueError) as e:
        print('NO SE MODIFICÓ NADA: revisión de compatibilidad fallida:',e);return 4
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    backup=target/'docs'/'historial'/f'respaldo_antes_sin_juegos_vr_v45_{stamp}'
    try:
        for rel,path in files.items():
            dst=backup/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dst)
    except OSError as e:
        print('No se cambió nada. Falló el respaldo:',e);return 5
    try:
        for rel,new_text in changes.items():
            dst=files[rel]
            with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=dst.parent,prefix='.sos-v45-',delete=False) as handle:
                handle.write(new_text);tmp=Path(handle.name)
            tmp.replace(dst)
    except OSError as e:
        for rel,old in originals.items():
            try:files[rel].write_text(old,encoding='utf-8')
            except OSError as restore_error:print('ADVERTENCIA: Restauración manual requerida:',restore_error)
        print('FALLÓ INSTALACIÓN. Se intentó restaurar el original:',e);print('Respaldo:',backup);return 6
    print('OK: Secrets of Space v45 · Realidad Virtual sin juegos ni cuestionarios.')
    print('- Retirados el reto de conocimiento, sus preguntas y desbloqueo.')
    print('- Conservadas la Luna, Marte, sus fichas, los modelos 3D y el progreso.')
    print('- Aventuras en el espacio y sus cinco videojuegos NO se modificaron.')
    print('Respaldo:',backup)
    print('Abre http://localhost/planetas/realidad-virtual.php y presiona Ctrl+F5')
    return 0

if __name__=='__main__':sys.exit(main())
