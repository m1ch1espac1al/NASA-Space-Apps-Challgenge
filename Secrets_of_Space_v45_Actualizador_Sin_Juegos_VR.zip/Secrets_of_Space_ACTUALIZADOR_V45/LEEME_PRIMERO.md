# Secrets of Space v45 — Realidad Virtual sin videojuegos

Esta actualización retira **únicamente las actividades de juego incluidas dentro de la página Realidad Virtual** (Luna y Marte):

- Reto de conocimiento y cuestionarios al completar una expedición.
- Sus preguntas, respuestas, botones, desbloqueos y estado de juego.
- La instrucción de introducción «Supera el reto», que ahora dice «Conoce sus historias».

**Se conserva:** exploración y modelos 3D de Luna/Marte, objetos seleccionables, fichas científicas, bitácora, progreso de hallazgos y animaciones. **Aventuras en el espacio permanece intacto**, con Memoria Cósmica, Rompecabezas espacial, Salto orbital, Tormenta de meteoritos y Orbital Recovery.

## Instalación sobre tu carpeta existente

1. Confirma que `http://localhost/planetas/realidad-virtual.php` abre correctamente.
2. Extrae el actualizador en Escritorio o Descargas. **No copies el ZIP sobre `htdocs`.**
3. Ejecuta `INSTALAR_V45.bat` con Python 3 instalado.
4. El instalador crea un respaldo dentro de `C:\xampp\htdocs\planetas\docs\historial\respaldo_antes_sin_juegos_vr_v45_...`.
5. Abre la página y presiona **Ctrl + F5**.

El instalador solo modifica cuatro archivos de Realidad Virtual y comprueba la compatibilidad antes de sobrescribir. Se puede ejecutar otra vez sin duplicar modificaciones.

## Paquete alternativo

También existe una entrega `Secrets_of_Space_v45_Proyecto_Completo.zip` con la carpeta `planetas/` completa. No necesitas descargar ambos. Usa el actualizador si tu instalación ya funciona y deseas conservar todos tus archivos locales.
