/* Cosmic Legacy v17 — traducción local ES / EN, sin servicios externos. */
(()=>{
 const EN={
 'orbit.shared':'ONE VISUAL ORBIT · TWO WORLDS','orbit.drag':'DRAG IN ANY DIRECTION','orbit.earth':'EARTH SYSTEM · MOON','orbit.mars':'MARS SYSTEM · PHOBOS · DEIMOS','site.tagline':'ECHOES OF EXPLORATION','site.team':'TEAM','site.disclaimer':'ILLUSTRATIVE ORBITAL TOUR · DISTANCES NOT TO SCALE · NOT AFFILIATED WITH NASA',
 'nav.explore':'Explore','nav.missions':'Missions','nav.vr':'Virtual reality','nav.stories':'Stories','nav.about':'About','nav.back':'BACK',
 'hero.title1':'ABANDONED','hero.title2':'BUT NOT FORGOTTEN','hero.subtitle':'Missions end. Their stories remain.<br>Discover the worlds that changed how we explore.','hero.start':'BEGIN EXPLORATION',
 'planet.earth.name':'EARTH','planet.moon.name':'MOON','planet.mars.name':'MARS',
 'distance.title':'DISTANCES FROM EARTH','distance.average':'average distance','distance.variable':'variable distance','distance.moonmars':'MOON–MARS','distance.estimated':'approximate range','distance.note':'Moon–Mars: indicative estimate based on Earth–Mars and Earth–Moon distances; it changes continuously.','zoom.title':'WORLD SIZE',
 'hint.rotation':'ONE 3D ORBIT · DRAG TO TILT ITS ANGLE','hint.select':'CHOOSE A WORLD TO LEARN MORE',
 'explore.choose':'SELECT ONE ↓','explore.drag':'DRAG TO ROTATE THE PLANET 360°','explore.source':'OFFICIAL NASA SOURCE ↗',
 'moon.satellites':'MARS NATURAL SATELLITES','modal.return':'RETURN TO THE UNIVERSE ↗',
 'planet.earth.title':'Earth','planet.moon.title':'The Moon','planet.mars.title':'Mars',
 'planet.earth.type':'OUR HOME PLANET','planet.moon.type':'NATURAL SATELLITE','planet.mars.type':'THE RED PLANET',
 'planet.earth.intro':'Our home: a world of oceans, continents and life. The great space missions began here.',
 'planet.moon.intro':'Our natural satellite preserves traces, instruments and vehicles from the historic Apollo missions.',
 'planet.mars.intro':'A desert world where robotic explorers left extraordinary scientific discoveries and lasting legacies.',
 'planet.earth.story':'Earth is the starting point of missions to the Moon and Mars. Seeing it from space transformed our understanding of climate, oceans and the atmosphere.',
 'planet.moon.story':'Scientific instruments and vehicles from the Apollo missions remain on the lunar surface, preserving the history of human exploration.',
 'planet.mars.story':'Sojourner, Spirit, Opportunity, InSight and Ingenuity are examples of missions that expanded our knowledge of Mars.',
 'callout.explore':'EXPLORE','callout.story':'DISCOVER ITS STORY',
 'focus.moon.kicker':'DESTINATION 01 · THE MOON','focus.mars.kicker':'DESTINATION 02 · MARS',
 'focus.moon.title':'Lunar legacy','focus.mars.title':'Traces on Mars',
 'focus.moon.summary':'Explore instruments, landers and records from NASA’s lunar missions.',
 'focus.mars.summary':'Discover robotic missions on Mars; other-destination missions are labeled separately.',
 'focus.moon.count':'4 RECORDS · 3 EQUIPMENT/MISSION GROUPS',
 'focus.mars.count':'9 RECORDS · 6 FROM MARS',
 'focus.auto':'AUTOMATIC ROTATION · DRAG TO EXPLORE','focus.rotate':'ROTATING · GENTLE CONTROL',
 'focus.return':'RETURNING TO AUTOMATIC ORIENTATION','focus.wait':'RETURN TO AUTOMATIC ORIENTATION IN',
 'focus.marsmoons':'MARS, PHOBOS AND DEIMOS · DRAG TO EXPLORE',
 'modal.stories.title':'Stories that remain','modal.stories.body':'Equipment that reached the Moon and Mars preserves remarkable scientific achievements. Choose a world to discover its story.',
 'modal.missions.title':'Missions and discoveries','modal.missions.body':'Explore mission designs, instruments and scientific achievements.',
 'modal.about.title':'About Cosmic Legacy','modal.about.body':'Educational prototype inspired by NASA Space Apps Challenge. Visual distances and sizes are not all to scale; this is not an official NASA website.',
 'vr.mission01':'MISSION 01','vr.destination01':'DESTINATION 01','vr.destination02':'DESTINATION 02','vr.observation':'OBSERVATION STATION','vr.online':'ONLINE','vr.moonhint':'Orbital distances are illustrative, not to physical scale.','vr.objectdisclaimer':'Documented educational selection; not a complete inventory of items on the Moon.','vr.lesson':'WHAT DID THE MISSION TEACH US?','vr.challenge':'✦ KNOWLEDGE CHALLENGE','vr.footerdisclaimer':'SCIENTIFIC-ARTISTIC RECREATION · MARKERS DO NOT SHOW EXACT LOCATIONS','vr.notphoto':'SCHEMATIC REPRESENTATION · NOT A PHOTOGRAPH','vr.originalsource':'READ ORIGINAL NASA DOCUMENTATION ↗','vr.equipment.view':'View artifact','vr.noresults':'No matching records.','marsmoon.phobos':'Phobos · 22.2 km across · orbital radius 9,377 km · one orbit every 7 h 39 min.','marsmoon.deimos':'Deimos · 12.6 km across · orbital radius 23,460 km · one orbit every 30 h 21 min.','marsmoon.drag':' Drag the small moon to rotate it.','marsmoon.hint':'Phobos and Deimos orbit Mars. Select a moon or drag it to rotate.','story.remains':'a story that remains','story.kicker':'STORIES OF EXPLORATION','vr.note.0':'Apollo 11 carried no rover; Armstrong and Aldrin explored on foot.','vr.note.1':'EASEP was an experiment package, not a robotic rover.','vr.note.2':'Surveyor 3 was a stationary robotic lander. Apollo 12 brought some components back to Earth.','vr.note.3':'Apollo 12 carried no rover; astronauts explored on foot with automated instruments.','vr.note.4':'Apollo 14 used a hand-pulled MET cart, not a self-driving robot.','vr.note.5':'Apollo 15 carried the first Apollo lunar rover, driven by astronauts.','vr.note.6':'These instruments kept working after the astronauts returned home.','vr.note.7':'Apollo 16’s rover was driven by astronauts Young and Duke.','vr.note.8':'Apollo 17 was the last crewed Apollo lunar landing.','vr.header':'INTERACTIVE SPACE ARCHIVE','vr.mode':'3D EXPERIENCE','vr.home':'← Home','vr.discovery.back':'BACK TO MAP','vr.discovery.kicker':'LUNAR ARCHIVE · DISCOVERY','vr.discovery.equipment':'EQUIPMENT AND COMPONENTS','vr.discovery.source':'VIEW NASA SOURCE ↗',
 'vr.gateway1':'THEY DEPARTED.','vr.gateway2':'THEIR LEGACY REMAINS.',
 'vr.intro':'Travel to the worlds that preserve the traces of our missions. Discover landers, vehicles and instruments and learn what they taught us.',
 'vr.step1':'01 · CHOOSE A WORLD','vr.step2':'02 · EXPLORE THE REMAINS','vr.step3':'03 · COMPLETE THE CHALLENGE',
 'vr.moon.count':'4 historic discoveries','vr.mars.count':'9 robotic discoveries','vr.begin':'START EXPLORATION ↗',
 'vr.disclaimer':'Educational artistic recreation. Not a complete inventory or a map of exact locations. Not affiliated with NASA.',
 'vr.back':'← CHOOSE WORLD','vr.found':'FOUND','vr.rings':'◎ ACTIVATE COSMIC RINGS',
 'vr.log':'EXPEDITION LOG','vr.documented':'DOCUMENTED OBJECTS','vr.search':'Search mission...',
 'vr.archivefoot':'Select a marker on the planet or a record. Points are illustrative, not exact coordinates.',
 'vr.drag':'↔ DRAG TO ROTATE','vr.points':'✦ SELECT THE GLOWING POINTS','vr.record':'DISCOVERY RECORD',
 'vr.emptytitle':'Your next discovery awaits','vr.emptydesc':'Find a signal on the globe or select a record from the log.',
 'vr.museum':'LUNAR ARTIFACT MUSEUM','vr.left':'What did this mission leave?',
 'vr.diagram':'ILLUSTRATIVE DIAGRAM · NOT TO SCALE','vr.expand':'EXPAND AND READ DETAILS ↗',
 'vr.nasa':'VIEW NASA SOURCE ↗','vr.unlock':'UNLOCK CHALLENGE ↗',
 'vr.history':'HISTORICAL ARTIFACTS: NOT OBJECTS TO COLLECT',
 'vr.moon.intro':'Discover landers, vehicles and scientific instruments NASA left on the lunar surface.',
 'vr.mars.intro':'Find the robots and landers that studied the Red Planet and learn what they discovered.',
 'vr.world.moon.title':'Explore the Moon','vr.world.mars.title':'Explore Mars',
 'vr.world.moon.tag':'MOON','vr.world.mars.tag':'MARS',
 'vr.world.moon.sector':'LUNAR EXPEDITION','vr.world.mars.sector':'MARTIAN EXPEDITION',
 'vr.foundcount':'found','vr.pieces':'PARTS','vr.new':'New documented discovery:',
 'vr.quiz.ready':'You have discovered four records. Test your knowledge.',
 'vr.quiz.locked':'Discover more records to unlock the knowledge challenge.',
 'vr.quiz.done':'Challenge completed! Keep exploring or choose another world.',
 'vr.quiz.try':'Try again: review the equipment story.',
 'vr.quiz.correct':'Correct!','vr.quiz.open':'ANSWER CHALLENGE ↗','vr.quiz.repeat':'REPEAT QUESTION ↗',
 'vr.quiz.blocked':'LOCKED','vr.quiz.available':'AVAILABLE','vr.quiz.completed':'COMPLETED',
 'vr.moon.question':'Which part of the Apollo lunar module stayed on the Moon after the crew departed?',
 'vr.moon.answers.0':'The descent stage','vr.moon.answers.1':'The command module','vr.moon.answers.2':'The ascent stage',
 'vr.moon.explanation':'The descent stage remained on the Moon while the ascent stage returned to lunar orbit.',
 'vr.mars.question':'What pioneering achievement did the small helicopter Ingenuity accomplish?',
 'vr.mars.answers.0':'The first controlled, powered flight on another planet','vr.mars.answers.1':'Bringing Martian rocks back to Earth','vr.mars.answers.2':'Landing humans on Mars',
 'vr.mars.explanation':'Ingenuity demonstrated powered flight in Mars’s thin atmosphere and completed 72 flights.',
 'vr.equipment.what':'WHAT IS IT?','vr.equipment.purpose':'WHAT WAS IT FOR?','vr.equipment.fate':'WHAT HAPPENED TO IT?','vr.equipment.discovery':'WHY DOES IT MATTER?',
 };
 const home={
  moon:[
   ['LUNAR MODULE + EXPERIMENTS · 1969','Scientific instruments from the first crewed Moon landing.','The Eagle descent stage stayed on the Moon. Astronauts deployed EASEP, including a seismometer and laser retroreflector.'],
   ['MODULE + SCIENCE STATION · 1971','Scientific experiments left after the crew returned.','Apollo 15 carried a lunar module, the first crewed lunar rover (LRV) and an ALSEP experiment station.'],
   ['IDENTIFIER · NOT A ROVER','A mission identification system, not an object on the surface.','NSSDCA and COSPAR catalog space missions and objects. This is a documentary reference, not a lunar vehicle.'],
   ['ROBOTIC LANDER · 1967','A probe that studied lunar soil before the Apollo missions.','Surveyor 3 landed in 1967 and examined soil with a scoop. Apollo 12 later brought some components back to Earth.']
  ],
  mars:[
   ['LANDER AND ROVER · 1997','Delivered Sojourner, the first rover to explore Mars.','Pathfinder tested an airbag landing system and delivered Sojourner to study rocks and Martian conditions.'],
   ['ROVER · 2004','Explored rocks and evidence of ancient water.','Spirit explored Gusev Crater and found signs of ancient environments with water.'],
   ['ROVER · 2004','A rover that worked for almost 15 years.','Opportunity studied sediments and minerals revealing ancient water-related conditions on Mars.'],
   ['LANDER · 1976','A historic surface exploration mission.','Viking 1 returned images and measurements of Martian soil and atmosphere.'],
   ['LANDER · 2018','Listened to marsquakes to study the planet’s interior.','InSight deployed a seismometer to investigate the structure and seismic activity of Mars.'],
   ['HELICOPTER · 2021','The first controlled, powered flight on another planet.','Ingenuity completed 72 flights on Mars, demonstrating flight in a very thin atmosphere.'],
   ['OTHER DESTINATION · VESTA AND CERES','Not a Mars mission: Dawn orbited Vesta and Ceres.','Dawn studied two asteroid-belt bodies with ion propulsion and did not land on Mars.'],
   ['OTHER DESTINATION · ASTEROID EROS','Not a Mars mission: NEAR reached asteroid Eros.','NEAR Shoemaker orbited and landed on asteroid Eros in 2001.'],
   ['OTHER DESTINATION · JUPITER','Pioneer 10 explored Jupiter and continued to deep space.','Pioneer 10 carried out a pioneering Jupiter flyby; it did not land on Mars.']
  ]
 };
 const vr={
 moon:[
 ['LUNAR DESCENT STAGE','Eagle brought Armstrong and Aldrin to the Moon. Its lower stage remained after the ascent stage launched.','The descent stage preserves the history of humanity’s first crewed lunar landing.'],
 ['SCIENTIFIC EXPERIMENTS','Apollo 11 deployed a seismometer and laser retroreflector on the Moon.','These instruments supported studies of the Moon’s interior and distance from Earth.'],
 ['ROBOTIC LANDER','Surveyor 3 landed softly and tested the lunar surface with a mechanical scoop.','Its measurements helped prepare for later crewed landings.'],
 ['SCIENCE STATION','Apollo 12 left instruments that continued measuring the lunar environment after the crew departed.','These experiments collected scientific data remotely.'],
 ['EQUIPMENT CART','Apollo 14 astronauts used a two-wheeled cart to carry tools and samples on foot.','Lunar transportation evolved from manual carts to electric rovers.'],
 ['CREWED LUNAR ROVER','Apollo 15 used the first crew-driven lunar rover to cover more terrain.','The rover helped astronauts study more distant geological sites.'],
 ['SCIENTIFIC EXPERIMENT STATION','Apollo 15 left instruments that monitored the lunar environment.','Science continued after the astronauts returned home.'],
 ['CREWED LUNAR ROVER','Apollo 16 astronauts explored highland terrain with the second Apollo lunar rover.','Lunar vehicles expanded the area accessible for geological investigation.'],
 ['CREWED LUNAR ROVER','Apollo 17 used the final Apollo-era crewed rover in the Taurus-Littrow valley.','Its traverses expanded the last Apollo mission’s scientific reach.']
 ],
 mars:[
 ['LANDER','Viking 1 landed on Mars and sent back images and atmospheric measurements.','A landmark in direct study of the Martian surface.'],
 ['LANDER','Viking 2 studied a second site on Mars with photography and scientific experiments.','Two surface locations broadened the evidence.'],
 ['LANDER','Mars Pathfinder demonstrated airbag landing and delivered the Sojourner rover.','It opened a new era of mobile Martian exploration.'],
 ['ROVER','Sojourner analyzed rocks and soil after being delivered by Pathfinder.','It proved that small rovers could explore another planet.'],
 ['ROVER','Spirit explored Gusev Crater and found signs of water-related geological processes.','Rock minerals reveal Mars’s ancient environmental history.'],
 ['ROVER','Opportunity operated for almost 15 years and investigated sediments and minerals.','A 90-sol design life turned into years of scientific exploration.'],
 ['POLAR LANDER','Phoenix investigated soil and water ice in northern Martian latitudes.','It helped us understand water ice at the Martian poles.'],
 ['SEISMIC LANDER','InSight deployed a seismometer to study marsquakes and the planet’s interior.','Seismic waves reveal internal structure without deep drilling.'],
 ['HELICOPTER','Ingenuity completed 72 flights after the first powered, controlled flight on another planet.','Robotic flight can complement surface exploration on Mars.']
 ]
 };
 const equip={
  lander:['DESCENT STAGE · FIXED STRUCTURE','The lower part of the lunar module had four landing legs and a descent engine.','Land safely and support liftoff of the ascent stage.','The upper stage departed; the descent stage remained on the Moon.','It enabled astronauts to land and return to orbit.'],
  seismic:['AUTOMATED SCIENTIFIC INSTRUMENT','A sensitive instrument that recorded vibrations on the lunar surface.','Measure moonquakes, impacts and surface conditions.','The equipment was left on the lunar surface for remote measurement.','Seismic data provided clues about the Moon’s interior.'],
  reflector:['PASSIVE OPTICAL EXPERIMENT','An array of prisms that reflects laser light toward its source.','Measure the Earth–Moon distance with laser pulses.','It remained on the Moon and requires no power to reflect light.','Laser ranging supports precise studies of lunar motion.'],
  surveyor:['ROBOTIC LANDER · NOT A ROVER','A three-legged robotic probe equipped with a camera and mechanical scoop.','Land softly and study lunar soil from a fixed location.','The main structure remained, while Apollo 12 recovered some parts.','Its tests helped scientists understand lunar soil strength.'],
  camera:['TELEVISION CAMERA','An optical camera system that transmitted images from the lunar surface.','Photograph the terrain and Surveyor 3 experiments.','Apollo 12 recovered the camera and returned it to Earth.','Scientists studied the effects of lunar exposure.'],
  scoop:['ROBOTIC SOIL SCOOP','A remotely controlled scoop for digging and testing lunar soil.','Investigate the physical properties of the soil.','Apollo 12 brought the scoop back to Earth.','Its tests helped assess surface stability.'],
  alsep:['AUTOMATED EXPERIMENT ARRAY','A group of connected experiments and a lunar surface science station.','Collect and transmit scientific data after the crew left.','The equipment remained; ALSEP transmissions ended in 1977.','It extended the scientific life of the Apollo missions.'],
  magnet:['MAGNETIC FIELD INSTRUMENT','A scientific device designed to measure surface magnetic fields.','Study lunar magnetism and its environment.','The instrument remained with the Apollo science station.','Its measurements helped explain lunar magnetic properties.'],
  met:['HAND-PULLED EQUIPMENT CART','A two-wheeled cart used to carry tools, cameras and samples.','Reduce the effort of carrying equipment on foot.','The cart was left on the Moon after its mission.','It preceded the electric lunar rovers used later.'],
  rover:['CREW-DRIVEN ELECTRIC VEHICLE','An electric four-wheeled lunar rover with two astronaut seats.','Extend exploration range and transport tools and samples.','The rover remained parked on the lunar surface.','It made longer geological excursions possible.'],
  heat:['THERMAL PROBE','A probe system with sensors placed beneath the lunar soil.','Measure heat escaping from inside the Moon.','The sensors and surface equipment remained on the Moon.','Its measurements helped study the Moon’s thermal history.']
 };
 const status={'Permanece en la Luna':'Remains on the Moon','Permanece con el experimento':'Remains with the experiment','Estructura principal permanece':'Main structure remains','RECUPERADA POR APOLLO 12':'RECOVERED BY APOLLO 12','Equipo científico dejado en la superficie':'Science equipment left on the surface'};
 let lang='es';try{lang=localStorage.getItem('cosmic-language')==='en'?'en':'es';}catch(e){}
 function t(key,fallback=''){return lang==='en'?(Object.prototype.hasOwnProperty.call(EN,key)?EN[key]:fallback):fallback;}
 function homeField(world,index,field,original){const row=home[world]?.[index];return lang==='en'&&row?row[{type:0,short:1,description:2}[field]]||original:original;}
 function vrField(world,index,field,original){const row=vr[world]?.[index];return lang==='en'&&row?row[{type:0,description:1,learn:2}[field]]||original:original;}
 function equipField(item,field,original){if(lang!=='en')return original;
  if(field==='name')return original.replace('Etapa de descenso','Descent stage').replace('Estación ALSEP','ALSEP station').replace('Sismómetro pasivo','Passive seismometer').replace('Retrorreflector láser','Laser retroreflector').replace('Vehículo Lunar LRV','Lunar Rover LRV').replace('Sonda robótica','Robotic lander').replace('Cámara de televisión','Television camera').replace('Pala mecánica','Mechanical scoop').replace('Carrito MET','MET cart').replace('Detector de polvo lunar','Lunar dust detector').replace('Magnetómetro de superficie','Surface magnetometer').replace('Experimento de flujo de calor','Heat-flow experiment');
  if(field==='status')return status[original]||original;
  const d=equip[item.art];if(!d)return original;
  return d[{class:0,what:1,purpose:2,fate:3,discovery:4}[field]]||original;
 }
 function apply(){document.documentElement.lang=lang;document.title=lang==='en'?(location.pathname.includes('realidad-virtual')?'Virtual reality | Cosmic Legacy':'Cosmic Legacy — Abandoned but not forgotten'):(location.pathname.includes('realidad-virtual')?'Realidad virtual | Cosmic Legacy':'Cosmic Legacy — Abandonados pero no olvidados');
  document.querySelectorAll('[data-i18n]').forEach(node=>{const k=node.dataset.i18n; if(!node.hasAttribute('data-i18n-es'))node.setAttribute('data-i18n-es',node.textContent);node.textContent=lang==='es'?node.getAttribute('data-i18n-es'):t(k,node.getAttribute('data-i18n-es'));});
  document.querySelectorAll('[data-i18n-html]').forEach(node=>{const k=node.dataset.i18nHtml;if(!node.hasAttribute('data-i18n-es-html'))node.setAttribute('data-i18n-es-html',node.innerHTML);node.innerHTML=lang==='es'?node.getAttribute('data-i18n-es-html'):t(k,node.getAttribute('data-i18n-es-html'));});
  document.querySelectorAll('[data-i18n-placeholder]').forEach(node=>{if(!node.hasAttribute('data-i18n-es-placeholder'))node.setAttribute('data-i18n-es-placeholder',node.placeholder);node.placeholder=lang==='es'?node.getAttribute('data-i18n-es-placeholder'):t(node.dataset.i18nPlaceholder,node.getAttribute('data-i18n-es-placeholder'));});
  document.querySelectorAll('[data-lang]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lang===lang)));
 }
 function setLang(value){if(!['es','en'].includes(value)||lang===value)return;lang=value;try{localStorage.setItem('cosmic-language',lang);}catch(e){}apply();window.dispatchEvent(new CustomEvent('cosmic-language-change',{detail:{lang}}));}
 function boot(){document.querySelectorAll('[data-lang]').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.lang)));apply();}
 window.CosmicI18n={t,lang:()=>lang,setLang,apply,homeField,vrField,equipField};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
