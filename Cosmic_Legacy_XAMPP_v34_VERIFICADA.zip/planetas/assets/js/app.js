// Cosmic Legacy — escena espacial automática, con selección sin detener rotaciones.
const $ = id => document.getElementById(id);
const tr=(key,es='')=>window.CosmicI18n?.t(key,es)??es;
const locHome=(world,index,field,es)=>window.CosmicI18n?.homeField(world,index,field,es)??es;
const data = {
 earth:{title:'La Tierra',type:'NUESTRO PLANETA',intro:'Nuestro hogar: un mundo de océanos, continentes y vida. Desde aquí comenzaron las grandes misiones espaciales.',story:'La Tierra es el punto de partida de las misiones que llegaron a la Luna y a Marte. Observarla desde el espacio también transformó nuestra comprensión del clima, los océanos y la atmósfera.',facts:['Tercer planeta desde el Sol.','Único mundo conocido que alberga vida.','Origen de las misiones Apolo y de los vehículos que exploraron Marte.']},
 moon:{title:'La Luna',type:'SATÉLITE NATURAL',intro:'Nuestro satélite conserva huellas, instrumentos y vehículos de las históricas misiones Apolo.',story:'En la superficie lunar aún permanecen instrumentos y vehículos de las misiones Apolo. Sus trayectorias, imágenes y experimentos ayudan a contar la historia de los primeros exploradores humanos de otro mundo.',facts:['Distancia media a la Tierra: 384,400 km.','Apollo 11 realizó el primer alunizaje humano en 1969.','Los vehículos de las misiones Apolo 15, 16 y 17 permanecen allí.']},
 mars:{title:'Marte',type:'EL PLANETA ROJO',intro:'Un mundo desértico donde antiguos exploradores robóticos dejaron descubrimientos y un legado extraordinario.',story:'Sojourner, Spirit, Opportunity, InSight e Ingenuity son ejemplos de equipos que hicieron historia en Marte. Sus datos aportaron pistas sobre su geología, su pasado con agua y las posibilidades del vuelo robótico.',facts:['La distancia a la Tierra cambia durante las órbitas.','Fobos y Deimos son las dos lunas naturales de Marte.','Ingenuity realizó el primer vuelo propulsado y controlado en otro planeta en 2021.']}
};
// Catálogo basado en páginas de NASA. Nota: no todos son rovers ni son misiones a Marte.
const missionCatalog={
 moon:[
  {name:'Apollo 11 LM / EASEP',type:'MÓDULO LUNAR + EXPERIMENTOS · 1969',short:'Instrumentos científicos de la primera misión tripulada que aterrizó en la Luna.',description:'El módulo lunar Eagle dejó su etapa de descenso en la superficie. Los astronautas desplegaron EASEP, con un experimento sísmico y un retroreflector láser que permitieron estudiar la Luna.',source:'https://science.nasa.gov/wp-content/uploads/2023/09/Apollo_11.pdf'},
  {name:'Apollo 15 Lunar Module / ALSEP',type:'MÓDULO + ESTACIÓN CIENTÍFICA · 1971',short:'Experimentos científicos que permanecieron tras el regreso de la tripulación.',description:'Apollo 15 llevó un módulo lunar, el primer vehículo lunar tripulado (LRV) y una estación de experimentos ALSEP. El instrumental registró información sobre la superficie y el entorno lunar.',source:'https://www.nasa.gov/wp-content/uploads/static/history/SP-4029/Apollo_18-31_ALSEP_Arrays_and_Status.htm'},
  {name:'NSSDCA / COSPAR',type:'IDENTIFICADOR · NO ES UN ROVER',short:'Sistema de identificación de misiones, no un objeto dejado sobre la superficie.',description:'NSSDCA y COSPAR se utilizan para identificar y catalogar misiones y objetos espaciales. Se conserva aquí el nombre que solicitaste como referencia documental; no representa un cuarto vehículo lunar.',source:'https://nssdc.gsfc.nasa.gov/nmc/'},
  {name:'Surveyor 3 (Agrimensor 3)',type:'SONDA DE ATERRIZAJE · 1967',short:'Una sonda que analizó el suelo lunar antes de las misiones Apolo.',description:'Surveyor 3 aterrizó en la Luna en 1967 y examinó el terreno con una pala de muestreo. En 1969 astronautas de Apollo 12 visitaron la sonda y recuperaron piezas para estudiarlas en la Tierra.',source:'https://science.nasa.gov/mission/surveyor-3/'}
 ],
 mars:[
  {name:'Mars Pathfinder',type:'ATERRIZADOR Y ROVER · 1997',short:'Entregó a Sojourner, el primer rover que exploró Marte.',description:'Pathfinder demostró un sistema de aterrizaje con bolsas de aire y llevó el pequeño rover Sojourner. Juntos estudiaron rocas, clima y el ambiente marciano.',source:'https://science.nasa.gov/mission/mars-pathfinder/'},
  {name:'Spirit',type:'ROVER · 2004',short:'Exploró rocas y antiguas huellas de agua en Marte.',description:'Spirit investigó el cráter Gusev y encontró señales de antiguos ambientes con agua. Su misión superó muchas veces la duración prevista.',source:'https://science.nasa.gov/mission/mer-spirit/'},
  {name:'Opportunity',type:'ROVER · 2004',short:'Un explorador cuya misión duró casi 15 años.',description:'Opportunity estudió sedimentos y minerales que aportaron pruebas de antiguas condiciones con agua en Marte. Su última comunicación fue en 2018.',source:'https://science.nasa.gov/mission/mer-opportunity/'},
  {name:'Viking 1',type:'ATERRIZADOR · 1976',short:'Una misión histórica de exploración de la superficie marciana.',description:'Viking 1 realizó el primer aterrizaje estadounidense plenamente exitoso en Marte y envió fotografías y mediciones del suelo y la atmósfera.',source:'https://science.nasa.gov/mission/viking-1/'},
  {name:'InSight Lander',type:'ATERRIZADOR · 2018',short:'Escuchó los temblores marcianos para estudiar el interior del planeta.',description:'InSight colocó un sismómetro sobre Marte para investigar su estructura interna y la actividad sísmica.',source:'https://science.nasa.gov/mission/insight/'},
  {name:'Ingenuity Mars Helicopter',type:'HELICÓPTERO · 2021',short:'El primer vuelo motorizado y controlado en otro planeta.',description:'Ingenuity realizó 72 vuelos en Marte y demostró que la exploración aérea es posible en una atmósfera muy tenue. Su misión terminó en 2024.',source:'https://science.nasa.gov/mission/mars-2020-perseverance/ingenuity-mars-helicopter/'},
  {name:'Dawn',type:'OTRO DESTINO · VESTA Y CERES',short:'No estuvo en Marte: orbitó Vesta y el planeta enano Ceres.',description:'Dawn investigó Vesta y Ceres en el cinturón de asteroides, utilizando propulsión iónica. Aparece como misión relacionada, pero no es equipo abandonado en Marte.',source:'https://science.nasa.gov/mission/dawn/'},
  {name:'NEAR Shoemaker',type:'OTRO DESTINO · ASTEROIDE EROS',short:'No fue a Marte: orbitó y aterrizó en el asteroide Eros.',description:'NEAR Shoemaker fue la primera nave en orbitar un asteroide y logró posarse en Eros en 2001. No debe confundirse con un rover marciano.',source:'https://science.nasa.gov/mission/near-shoemaker/'},
  {name:'Pioneer 10',type:'OTRO DESTINO · JÚPITER',short:'Exploró Júpiter y continúa en una trayectoria hacia el espacio profundo.',description:'Pioneer 10 realizó el primer sobrevuelo cercano de Júpiter. No aterrizó en Marte; su misión pertenece a la exploración del sistema solar exterior.',source:'https://science.nasa.gov/mission/pioneer-10/'}
 ]
};
let focusPlanet=null,currentMissionIndex=0;
const app=$('app'),explorePanel=$('explore-panel'),exploreList=$('explore-list');
function chooseMission(index){
 const m=missionCatalog[focusPlanet]?.[index];if(!m)return;currentMissionIndex=index;
 exploreList.querySelectorAll('.mission-entry').forEach((b,i)=>{b.classList.toggle('active',i===index);b.setAttribute('aria-pressed',String(i===index));});
 $('explore-detail-type').textContent=locHome(focusPlanet,index,'type',m.type);
 $('explore-detail-title').textContent=m.name;
 $('explore-detail-desc').textContent=locHome(focusPlanet,index,'description',m.description);
 $('explore-detail-source').href=m.source;
}
function renderExploreContent(){
 const key=focusPlanet;if(!key)return;
 $('explore-kicker').textContent=tr('focus.'+key+'.kicker',key==='moon'?'DESTINO 01 · LA LUNA':'DESTINO 02 · MARTE');
 $('explore-title').textContent=tr('focus.'+key+'.title',key==='moon'?'Legado lunar':'Huellas en Marte');
 $('explore-summary').textContent=tr('focus.'+key+'.summary',key==='moon'?'Explora instrumentos, aterrizadores y registros de nuestras misiones lunares.':'Descubre robots marcianos y, por separado, misiones de otros destinos incluidas en tu selección.');
 const missions=missionCatalog[key];
 $('explore-count').textContent=tr('focus.'+key+'.count',key==='moon'?'4 REGISTROS · 3 EQUIPOS/MISIONES':'9 REGISTROS · 6 DE MARTE');
 exploreList.replaceChildren();
 for(const [i,m] of missions.entries()){
  const b=document.createElement('button');b.type='button';b.className='mission-entry';
  const n=document.createElement('span');n.className='mission-index';n.textContent=String(i+1).padStart(2,'0');
  const content=document.createElement('span');content.className='mission-content';
  const name=document.createElement('strong');name.textContent=m.name;
  const desc=document.createElement('small');desc.textContent=locHome(key,i,'short',m.short);
  content.append(name,desc);const arrow=document.createElement('span');arrow.className='mission-arrow';arrow.textContent='↗';
  b.append(n,content,arrow);b.addEventListener('click',()=>chooseMission(i));exploreList.append(b);
 }
 chooseMission(Math.min(currentMissionIndex,missions.length-1));
}
function openExplore(key){
 if(key!=='moon'&&key!=='mars')return;
 focusPlanet=key;currentMissionIndex=0;hideCard(true);
 app.classList.add('focus-mode');app.classList.toggle('focus-moon',key==='moon');app.classList.toggle('focus-mars',key==='mars');
 explorePanel.hidden=false;$('explore-back').hidden=false;
 const marsControls=$('moon-controls');if(marsControls)marsControls.hidden=key!=='mars';
 renderExploreContent();
 sceneControl?.focus?.(key);blockCacheTime=-Infinity;
 $('explore-back').focus({preventScroll:true});
}
function closeExplore(){
 if(!focusPlanet)return;
 focusPlanet=null;app.classList.remove('focus-mode','focus-moon','focus-mars');
 explorePanel.hidden=true;$('explore-back').hidden=true;
 if($('moon-controls'))$('moon-controls').hidden=true;
 sceneControl?.focus?.(null);blockCacheTime=-Infinity;hideCard(true);
}
$('explore-back').addEventListener('click',closeExplore);
// Zoom exclusivo del menú. No cambia texto, paneles, cámara ni el modo de exploración.
const menuScale={value:1,min:.70,max:1.45,step:.15};
function setMenuScale(value){
 const rounded=Math.round(Math.max(menuScale.min,Math.min(menuScale.max,value))*100)/100;
 menuScale.value=rounded;
 const output=$('zoom-value'); if(output)output.textContent=Math.round(rounded*100)+'%';
 $('zoom-minus').disabled=rounded<=menuScale.min+.001;
 $('zoom-plus').disabled=rounded>=menuScale.max-.001;
 sceneControl?.zoom?.();
 blockCacheTime=-Infinity;
 if(selected&&!card.hidden)positionCard();
}
$('zoom-minus').addEventListener('click',e=>{e.stopPropagation();setMenuScale(menuScale.value-menuScale.step);});
$('zoom-plus').addEventListener('click',e=>{e.stopPropagation();setMenuScale(menuScale.value+menuScale.step);});
// Un único carrusel orbital visual. No corresponde a una órbita astronómica real.
const commonOrbit={phase:Math.PI,target:null,tilt:-.39,dragging:false,pointer:null,lastX:0,lastY:0,startX:0,startY:0,moved:false,
 pauseUntil:0,suppressUntil:0,rate:.052};
function shiftCommonOrbit(direction){
 if(focusPlanet)return;
 commonOrbit.target=(commonOrbit.target??commonOrbit.phase)+direction*Math.PI;
 commonOrbit.pauseUntil=performance.now()+1200;
 hideCard();
}
document.addEventListener('keydown',e=>{
 if(focusPlanet||e.altKey||e.ctrlKey||e.metaKey||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
 if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();shiftCommonOrbit(e.key==='ArrowLeft'?-1:1);}
 if(e.key==='ArrowUp'||e.key==='ArrowDown'){
  e.preventDefault();commonOrbit.tilt+=e.key==='ArrowUp'?.13:-.13;
  commonOrbit.pauseUntil=performance.now()+900;
 }
});
function orbitAdvance(dt,now){
 if(commonOrbit.dragging||focusPlanet)return;
 if(commonOrbit.target!==null){
  const d=commonOrbit.target-commonOrbit.phase;
  commonOrbit.phase+=d*(1-Math.exp(-dt*5.5));
  if(Math.abs(d)<.005){commonOrbit.phase=commonOrbit.target;commonOrbit.target=null;commonOrbit.pauseUntil=now+1200;}
 }else if(now>commonOrbit.pauseUntil)commonOrbit.phase+=dt*commonOrbit.rate;
}
function attachOrbitDrag(host,isAllowed){
 const start=e=>{
  if(!isAllowed()||e.button!==0||e.pointerType==='touch'&&!e.isPrimary)return;
  commonOrbit.pointer=e.pointerId;commonOrbit.startX=commonOrbit.lastX=e.clientX;commonOrbit.startY=commonOrbit.lastY=e.clientY;
  commonOrbit.moved=false;commonOrbit.dragging=true;
  commonOrbit.target=null;
  try{host.setPointerCapture(e.pointerId);}catch(_){}
 };
 const move=e=>{
  if(commonOrbit.pointer!==e.pointerId||!commonOrbit.dragging)return;
  const dx=e.clientX-commonOrbit.lastX,dy=e.clientY-commonOrbit.lastY;
  commonOrbit.lastX=e.clientX;commonOrbit.lastY=e.clientY;
  if(Math.hypot(e.clientX-commonOrbit.startX,e.clientY-commonOrbit.startY)>6)commonOrbit.moved=true;
  if(commonOrbit.moved){
   commonOrbit.phase-=dx*.0105;
   // Arriba/abajo INCLINA el plano de la órbita alrededor de su centro fijo.
   // No cambia la posición vertical de todo el sistema.
   commonOrbit.tilt+=dy*.0065;
   if(Math.abs(commonOrbit.tilt)>Math.PI*2)commonOrbit.tilt=Math.atan2(Math.sin(commonOrbit.tilt),Math.cos(commonOrbit.tilt));
   commonOrbit.suppressUntil=performance.now()+350;e.preventDefault();
  }
 };
 const end=e=>{
  if(commonOrbit.pointer!==e.pointerId)return;
  if(commonOrbit.moved){commonOrbit.suppressUntil=performance.now()+350;hideCard();}
  commonOrbit.pointer=null;commonOrbit.dragging=false;commonOrbit.pauseUntil=performance.now()+900;
  try{host.releasePointerCapture(e.pointerId);}catch(_){}
 };
 host.addEventListener('pointerdown',start);host.addEventListener('pointermove',move);
 host.addEventListener('pointerup',end);host.addEventListener('pointercancel',end);
 host.addEventListener('lostpointercapture',end);
}
let selected=null, sceneControl=null;
const path=$('callout-path'),node=$('callout-node'),card=$('planet-callout');
let cardVersion=0;
function openModal(title,body,facts=[],kicker='ARCHIVO COSMIC LEGACY'){
 $('modal-title').textContent=title;$('modal-body').textContent=body;$('modal-kicker').textContent=kicker;
 const ex=$('modal-extra');ex.replaceChildren();if(facts.length){let ul=document.createElement('ul');for(const fact of facts){const li=document.createElement('li');li.textContent=fact;ul.append(li)}ex.append(ul)}
 $('modal-layer').hidden=false;$('close-modal').focus();
}
function closeModal(){$('modal-layer').hidden=true;}
$('close-modal').addEventListener('click',closeModal);$('modal-ok').addEventListener('click',closeModal);document.querySelector('[data-close]').addEventListener('click',closeModal);
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!$('modal-layer').hidden)closeModal();else if(focusPlanet)closeExplore();else hideCard();}});
function story(key=selected||'earth'){const d=data[key];openModal(tr('planet.'+key+'.title',d.title)+': '+tr('story.remains','una historia que permanece'),tr('planet.'+key+'.story',d.story),d.facts,tr('story.kicker','HISTORIAS DE LA EXPLORACIÓN'));}
$('callout-story').addEventListener('click',()=>{if(selected==='moon'||selected==='mars')openExplore(selected);});
$('nav-missions').addEventListener('click',()=>openModal(tr('modal.missions.title','Misiones y descubrimientos'),tr('modal.missions.body','Exploramos cómo se diseñaron las misiones, qué instrumentos llevaron y qué contribuciones realizaron a la ciencia.'), ['Apolo: exploración humana de la superficie lunar.','Opportunity: geología y evidencias de agua antigua en Marte.','Ingenuity: demostración de vuelo robótico en Marte.'],'EXPLORACIÓN NASA'));
$('nav-about').addEventListener('click',()=>openModal(tr('modal.about.title','Acerca de Cosmic Legacy'),'Proyecto educativo inspirado en el desafío “Abandoned but not Forgotten” de NASA Space Apps Challenge. Separaciones y distancias visuales no están a escala; el tamaño relativo de Marte y la Luna sí se ajusta al de la Tierra. No es una web oficial ni está afiliada a NASA.', ['Los tres cuerpos giran automáticamente y a la vez.','Seleccionar un mundo revela una ficha informativa animada.','Distancia lunar media: NASA Science. Distancia a Marte: NASA Moon to Mars Architecture.'],'ACERCA DEL PROYECTO'));
$('mobile-menu').addEventListener('click',()=>{const open=document.querySelector('.navigation').classList.toggle('open');$('mobile-menu').setAttribute('aria-expanded',String(open))});
document.querySelectorAll('.navigation button').forEach(b=>b.addEventListener('click',()=>document.querySelector('.navigation').classList.remove('open')));

// Animación reversible de tarjetas: la salida se reproduce, nunca desaparece de golpe.
let closeCardTimer=null;
function resetCardImmediately(){
 if(closeCardTimer!==null){clearTimeout(closeCardTimer);closeCardTimer=null;}
 card.hidden=true;selected=null;
 card.classList.remove('callout-visible','callout-exiting');
 path.classList.remove('drawn','retracting');node.classList.remove('node-visible');
 card.style.transition='none';path.style.transition='none';node.style.transition='none';
}
function hideCard(immediate=false){
 if(immediate){cardVersion++;resetCardImmediately();return;}
 if(card.hidden||!selected||card.classList.contains('callout-exiting'))return;
 const token=++cardVersion;
 card.classList.add('callout-exiting');card.classList.remove('callout-visible');
 path.classList.add('retracting');path.classList.remove('drawn');
 node.classList.remove('node-visible');
 // El panel se repliega antes de que la línea se retraiga por completo.
 closeCardTimer=setTimeout(()=>{
  if(token!==cardVersion)return;
  resetCardImmediately();
 },870);
}
function selectPlanet(key){
 if(focusPlanet||!data[key])return;
 if(closeCardTimer!==null){clearTimeout(closeCardTimer);closeCardTimer=null;}
 const d=data[key];cardVersion++;selected=key;
 $('callout-title').textContent=tr('planet.'+key+'.title',d.title);$('callout-type').textContent=tr('planet.'+key+'.type',d.type);$('callout-desc').textContent=tr('planet.'+key+'.intro',d.intro);
 $('callout-story').hidden=key==='earth';
 $('callout-action-text').textContent=tr('callout.explore','EXPLORAR');
 card.hidden=false;
 card.classList.remove('callout-visible','callout-exiting');
 path.classList.remove('drawn','retracting');node.classList.remove('node-visible');
 card.style.transition='none';path.style.transition='none';node.style.transition='none';
 sceneControl?.select?.(key);positionCard();
 const length=Math.max(1,path.getTotalLength());
 path.style.strokeDasharray=String(length);path.style.strokeDashoffset=String(length);
 void card.offsetHeight;void path.getBoundingClientRect().width;
 const token=cardVersion;
 requestAnimationFrame(()=>{
  if(token!==cardVersion)return;
  card.style.transition='';path.style.transition='';node.style.transition='';
  requestAnimationFrame(()=>{
   if(token!==cardVersion)return;
   path.classList.add('drawn');node.classList.add('node-visible');card.classList.add('callout-visible');
  });
 });
}
document.querySelectorAll('[data-planet]').forEach(b=>b.addEventListener('click',e=>{if(performance.now()<commonOrbit.suppressUntil){e.preventDefault();e.stopPropagation();return;}e.stopPropagation();selectPlanet(b.dataset.planet)}));
window.addEventListener('cosmic-language-change',()=>{
 if(selected && !card.hidden){const d=data[selected];$('callout-title').textContent=tr('planet.'+selected+'.title',d.title);$('callout-type').textContent=tr('planet.'+selected+'.type',d.type);$('callout-desc').textContent=tr('planet.'+selected+'.intro',d.intro);$('callout-story').hidden=selected==='earth';$('callout-action-text').textContent=tr('callout.explore','EXPLORAR');positionCard();}
 if(focusPlanet)renderExploreContent();
});

$('app').addEventListener('click',e=>{
 if(performance.now()<commonOrbit.suppressUntil||focusPlanet||e.target.closest('button,a,#planet-callout,.topbar,.distance-panel'))return;
 hideCard();
});
function screenFallback(key){const ref=document.querySelector('.fallback-planet[data-planet="'+key+'"]');const a=ref?.getBoundingClientRect();if(!a)return null;return {x:a.left+a.width/2,y:a.top+a.height/2,r:a.width*.45};}
function positionCard(){
 if(!selected||card.hidden)return;
 const viewport=$('app').getBoundingClientRect(),target=sceneControl?.project?.(selected)||screenFallback(selected);if(!target)return;
 const x=target.x-viewport.left,y=target.y-viewport.top;
 const w=card.offsetWidth||225,h=card.offsetHeight||150;
 const isMobile=innerWidth<=650;
 const side=selected==='moon'?-1:1; // Luna izquierda y Marte derecha; la ficha sigue la órbita
 let bx=x+(side===1?target.r+17:-target.r-w-17);
 let by=y-(selected==='earth'?target.r*.37:target.r*.15)-h*.45;
 const maxBottom=isMobile?Math.max(260,viewport.height*.76):viewport.height*.72;
 bx=Math.max(12,Math.min(viewport.width-w-12,bx));by=Math.max(isMobile?78:100,Math.min(maxBottom-h,by));
 card.style.left=bx+'px';card.style.top=by+'px';
 const cx=side===1?bx:bx+w,cy=Math.min(by+h-12,Math.max(by+12,y));
 const sx=x+side*target.r*.77,sy=y-target.r*.18;
 const midX=sx+(cx-sx)*.47;
 path.setAttribute('d',`M ${sx.toFixed(1)} ${sy.toFixed(1)} L ${midX.toFixed(1)} ${cy.toFixed(1)} L ${cx.toFixed(1)} ${cy.toFixed(1)}`);
 node.setAttribute('cx',sx);node.setAttribute('cy',sy);
}
// Cosmic Legacy v8 — luces animadas sin desvanecer y con recorridos COMPLETOS.
// Planificación de 20 rutas por tipo, entradas alrededor de las cuatro esquinas.
const starCanvas=$('star-canvas'),skyCtx=starCanvas.getContext('2d',{alpha:true});
const effectsCanvas=$('effects-canvas'),fx=effectsCanvas.getContext('2d',{alpha:true});
let W=1,H=1,DPR=1,stars=[];
const rand=(a,b)=>a+Math.random()*(b-a);
const asteroidSprite=new Image();asteroidSprite.decoding='async';asteroidSprite.src='assets/img/asteroide-sprite.png';
const cometPalettes=[
 {head:'#f4ffff',body:'rgba(125,206,255,',glow:'rgba(74,176,255,'},
 {head:'#fff9e2',body:'rgba(255,207,127,',glow:'rgba(255,174,57,'},
 {head:'#f1ffe7',body:'rgba(167,249,135,',glow:'rgba(100,215,92,'},
 {head:'#fff1ed',body:'rgba(255,148,154,',glow:'rgba(245,97,127,'}
];
// Prerenderizar cometas evita crear gradientes y sombras costosas 60 veces por segundo.
// La cola es completamente recta y un degradado largo difumina los saltos a alta velocidad.
function createCometSprite(c){
 const buffer=document.createElement('canvas');buffer.width=512;buffer.height=112;
 const g=buffer.getContext('2d',{alpha:true});const headX=474,centerY=56;
 const glow=g.createLinearGradient(0,0,headX,0);
 glow.addColorStop(0,c.glow+'0)');glow.addColorStop(.18,c.glow+'.06)');
 glow.addColorStop(.67,c.glow+'.29)');glow.addColorStop(1,c.glow+'.76)');
 g.fillStyle=glow;g.beginPath();g.moveTo(0,centerY);g.lineTo(headX,centerY-14);g.lineTo(headX,centerY+14);g.closePath();g.fill();
 const fine=g.createLinearGradient(0,0,headX,0);
 fine.addColorStop(0,c.body+'0)');fine.addColorStop(.32,c.body+'.15)');
 fine.addColorStop(.77,c.body+'.50)');fine.addColorStop(1,c.head);
 g.strokeStyle=fine;g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(6,centerY);g.lineTo(headX,centerY);g.stroke();
 const core=g.createRadialGradient(headX,centerY,0,headX,centerY,32);
 core.addColorStop(0,'rgba(255,255,255,1)');core.addColorStop(.12,c.body+'.90)');
 core.addColorStop(.45,c.glow+'.42)');core.addColorStop(1,c.glow+'0)');
 g.fillStyle=core;g.beginPath();g.arc(headX,centerY,32,0,Math.PI*2);g.fill();
 g.fillStyle='#ffffff';g.beginPath();g.arc(headX,centerY,2.4,0,Math.PI*2);g.fill();
 return buffer;
}
const fxTypes={
 cometa:{interval:10000,first:10000,cursor:0,chance:.33},
 asteroide:{interval:10000,first:10000,cursor:8,chance:.33}
};
const effectItems=[];const bootTime=performance.now();
const cometSprites=cometPalettes.map(createCometSprite);
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const effectBags={cometa:[],asteroide:[]};let cometColorBag=[];
function nextRouteIndex(type){if(!effectBags[type].length)effectBags[type]=shuffle([0,1,2,3,4]);return effectBags[type].pop();}
function nextCometPalette(){if(!cometColorBag.length)cometColorBag=shuffle([0,1,2,3]);return cometPalettes[cometColorBag.pop()];}
for(const cfg of Object.values(fxTypes))cfg.next=bootTime+cfg.first;

function resizeSkies(){
 W=innerWidth;H=innerHeight;
 DPR=Math.min(devicePixelRatio||1,innerWidth<700?1.15:1.3);
 for(const canvas of [starCanvas,effectsCanvas]){
  canvas.width=Math.round(W*DPR);canvas.height=Math.round(H*DPR);
  canvas.style.width=W+'px';canvas.style.height=H+'px';
 }
 skyCtx.setTransform(DPR,0,0,DPR,0,0);fx.setTransform(DPR,0,0,DPR,0,0);
 stars=Array.from({length:Math.min(460,Math.round(W*H/3200))},()=>({
  x:Math.random()*W,y:Math.random()*H,r:rand(.25,1.25),base:rand(.17,.75),
  phase:rand(0,Math.PI*2),speed:rand(.00025,.0022),cross:Math.random()<.08
 }));
 blockCacheTime=-Infinity;
}
function drawTwinkles(now){
 skyCtx.clearRect(0,0,W,H);
 for(const s of stars){
  const f=.74+.26*Math.sin(now*s.speed+s.phase),alpha=s.base*f;
  skyCtx.fillStyle=`rgba(220,235,255,${alpha})`;
  skyCtx.beginPath();skyCtx.arc(s.x,s.y,s.r,0,Math.PI*2);skyCtx.fill();
  if(s.cross&&f>.92){const a=s.r*3.4;skyCtx.strokeStyle=`rgba(174,213,255,${(f-.82)*.7})`;
   skyCtx.lineWidth=.5;skyCtx.beginPath();skyCtx.moveTo(s.x-a,s.y);skyCtx.lineTo(s.x+a,s.y);
   skyCtx.moveTo(s.x,s.y-a);skyCtx.lineTo(s.x,s.y+a);skyCtx.stroke();}
 }
}
function isDisplayed(el){return !!(el&&!el.hidden&&getComputedStyle(el).display!=='none'&&el.getBoundingClientRect().width>0);}
let blockCache=[],blockCacheTime=-Infinity;
function safeRects(now=performance.now()){
 // v26: excluir SOLO los discos de los planetas. Nunca recortar por cajas de
 // texto, paneles o etiquetas: esos recortes ocultaban asteroides y cometas.
 if(now-blockCacheTime<55)return blockCache;
 blockCacheTime=now;
 const blocks=[];
 for(const key of ['earth','moon','mars']){
  if(focusPlanet&&key!==focusPlanet)continue;
  const p=sceneControl?.project?.(key)||screenFallback(key);
  if(p&&p.r>0)blocks.push({type:'circle',x:p.x,y:p.y,r:Math.max(2,p.r*.985)});
 }
 blockCache=blocks;
 return blocks;
}
function blocked(x,y,r,b){
 if(b.type==='circle')return Math.hypot(x-b.x,y-b.y)<r+b.r;
 return x+r>b.x&&x-r<b.x+b.w&&y+r>b.y&&y-r<b.y+b.h;
}
function pointFree(x,y,r,blocks){return blocks.every(b=>!blocked(x,y,r,b));}
function pathPos(route,t){return {x:route.x0+(route.x1-route.x0)*t,y:route.y0+(route.y1-route.y0)*t};}
function routeDirection(route){const dx=route.x1-route.x0,dy=route.y1-route.y0,d=Math.hypot(dx,dy)||1;return {x:dx/d,y:dy/d,length:d,theta:Math.atan2(dy,dx)};}
// Cinco rutas desde cada esquina. Todas terminan FUERA del borde opuesto.
// La escena elige solamente los corredores seguros, por encima o al lado del contenido.
function makeRoutes(kind){
 // Cinco direcciones geométricamente distintas: 3 diagonales de esquinas y
 // 2 pasillos de laterales. Extremos siempre FUERA de pantalla.
 const m=Math.max(125,Math.min(W,H)*.18);
 const slip=kind==='asteroide'?.045:0;
 return [
  {id:kind+'-diagonal-NO-SE',index:0,x0:-m,y0:-m*.7,x1:W+m,y1:H+m*.65},
  {id:kind+'-diagonal-NE-SO',index:1,x0:W+m,y0:-m*.5,x1:-m,y1:H+m*.7},
  {id:kind+'-diagonal-SO-NE',index:2,x0:-m,y0:H+m*.62,x1:W+m,y1:-m*.45},
  {id:kind+'-lateral-I-D',index:3,x0:-m,y0:H*(.28+slip),x1:W+m,y1:H*(.37+slip)},
  {id:kind+'-lateral-D-I',index:4,x0:W+m,y0:H*(.72-slip),x1:-m,y1:H*(.59-slip)}
 ];
}
function radiusFor(type,size){return type==='cometa'?7:Math.max(10,size*.60);}
function routeClear(route,radius,blocks,type){
 const vec=routeDirection(route);const steps=Math.max(22,Math.ceil(vec.length/16));let seen=0;
 for(let i=0;i<=steps;i++){
  const p=pathPos(route,i/steps);
  if(p.x<0||p.y<0||p.x>W||p.y>H)continue;
  seen++;
  if(!pointFree(p.x,p.y,radius,blocks))return false;
  if(type==='cometa'){
   const tail={x:p.x-vec.x*80,y:p.y-vec.y*80};
   if(tail.x>=0&&tail.x<=W&&tail.y>=0&&tail.y<=H&&!pointFree(tail.x,tail.y,5,blocks))return false;
  }
 }
 return seen>Math.min(12,steps/2);
}
function startEffect(type,now){
 const cfg=fxTypes[type],routes=makeRoutes(type);
 const size=type==='cometa'?rand(150,230):rand(17,44)*(W<650?.72:1);
 // Las trayectorias se reparten por ciclos: ninguna de las cinco se repite
 // hasta que las otras cuatro hayan tenido oportunidad de salir.
 const route=routes[nextRouteIndex(type)];
 const vec=routeDirection(route),speed=type==='cometa'?rand(1900,3100):rand(155,385);
 const duration=vec.length/speed*1000,spinSign=Math.random()<.5?-1:1;
 effectItems.push({type,route,vec,begin:now,duration,size,radius:radiusFor(type,size),
  color:type==='cometa'?nextCometPalette():cometPalettes[0],
  rotation:rand(0,Math.PI*2),spin:spinSign*(.35+speed*.0085),speed});
}
function drawComet(it,p){
 const c=it.color,idx=cometPalettes.indexOf(c),sprite=cometSprites[Math.max(0,idx)];
 // Una sola imagen prerenderizada por cometa, transformada en la dirección de su viaje.
 // La cola cubre varios píxeles de desplazamiento rápido para evitar parpadeo visual.
 const width=it.size,thickness=22+Math.min(11,it.speed/420);
 fx.save();fx.globalCompositeOperation='screen';
 fx.translate(p.x,p.y);fx.rotate(it.vec.theta);
 fx.drawImage(sprite,-width,-thickness/2,width+Math.min(22,width*.13),thickness);
 fx.restore();
}
function drawAsteroid(it,p,now){
 const size=it.size;
 fx.save();fx.translate(p.x,p.y);
 fx.rotate(it.rotation+(now-it.begin)/1000*it.spin);
 if(asteroidSprite.complete&&asteroidSprite.naturalWidth){
  fx.drawImage(asteroidSprite,-size/2,-size/2,size,size);
 }else{
  fx.fillStyle='#778399';fx.beginPath();
  for(let i=0;i<11;i++){const ang=i/11*Math.PI*2,rr=size*(i%3===0?.44:.37),x=Math.cos(ang)*rr,y=Math.sin(ang)*rr;
   if(i===0)fx.moveTo(x,y);else fx.lineTo(x,y);}
  fx.closePath();fx.fill();
 }
 fx.restore();
}
function renderEffect(it,now,blocks){
 const u=Math.min(1,(now-it.begin)/it.duration),p=pathPos(it.route,u);
 if(p.x<-it.size||p.y<-it.size||p.x>W+it.size||p.y>H+it.size)return;
 // Se dibuja la trayectoria completa; un recorte geométrico impide tapar UI y planetas.
 // Sin opacidad progresiva: conserva el brillo hasta cruzar completamente el borde final.
 if(it.type==='cometa')drawComet(it,p,blocks);else drawAsteroid(it,p,now);
}
let lastSkyDraw=-Infinity,lastEffectsDraw=-Infinity;
function animateSpace(now){
 requestAnimationFrame(animateSpace);
 if(document.hidden)return;
 if(now-lastSkyDraw>=50){drawTwinkles(now);lastSkyDraw=now;} // 20 fps para estrellas
 if(now-lastEffectsDraw<16)return; // 60 fps cuando hay efectos: cometas rápidos y fluidos
 lastEffectsDraw=now;
 if(!$('modal-layer').hidden){fx.clearRect(0,0,W,H);return;}
 for(const [type,cfg] of Object.entries(fxTypes)){
  if(now>=cfg.next){
   const opportunities=Math.floor((now-cfg.next)/cfg.interval)+1;
   cfg.next+=opportunities*cfg.interval;
   if(Math.random()<cfg.chance)startEffect(type,now);
  }
 }
 if(effectItems.length===0){
  // El último fotograma del efecto se limpia una única vez, no 60 veces por segundo.
  if(animateSpace.hadEffects){fx.clearRect(0,0,W,H);animateSpace.hadEffects=false;}
  return;
 }
 animateSpace.hadEffects=true;
 fx.clearRect(0,0,W,H);
 const blocks=safeRects(now);
 fx.save(); fx.beginPath();fx.rect(0,0,W,H);
 for(const b of blocks){
  if(b.type==='circle'){fx.moveTo(b.x+b.r,b.y);fx.arc(b.x,b.y,b.r,0,Math.PI*2);}
  else if(fx.roundRect)fx.roundRect(b.x,b.y,b.w,b.h,9);
  else fx.rect(b.x,b.y,b.w,b.h);
 }
 fx.clip('evenodd');
 for(let i=effectItems.length-1;i>=0;i--){
  const it=effectItems[i];if(now>=it.begin+it.duration){effectItems.splice(i,1);continue;}
  renderEffect(it,now,blocks);
 }
 fx.restore();
}
addEventListener('resize',()=>{resizeSkies();effectItems.length=0;positionCard()});
resizeSkies();requestAnimationFrame(animateSpace);

// Three.js: modelos con texturas mejoradas, brillos sutiles y lunas marcianas.
(async()=>{
 try{
  // Cargar Three primero: un fallo del cargador GLB no debe apagar los planetas.
  const THREE=await import('three');
  let GLTFLoader=null;
  try{({GLTFLoader}=await import('three/addons/loaders/GLTFLoader.js'));}
  catch(error){console.warn('GLB no disponible: se utilizarán modelos de roca de respaldo',error);}
  const host=$('universe'),scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(43,1,.1,1000);camera.position.set(0,0,21.1);
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,innerWidth<700?1.1:1.45));
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.44;
  renderer.setClearColor(0x000000,0);
  host.append(renderer.domElement);

  const loader=new THREE.TextureLoader();
  const gltfLoader=GLTFLoader?new GLTFLoader():null;
  function texture(name,colors=true){
   const t=loader.load('assets/img/'+name);
   if(colors)t.colorSpace=THREE.SRGBColorSpace;
   t.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);
   return t;
  }
  function glowSprite(stops,scale){
   const canvas=document.createElement('canvas');canvas.width=canvas.height=320;
   const ctx=canvas.getContext('2d');const g=ctx.createRadialGradient(160,160,8,160,160,160);
   for(const s of stops)g.addColorStop(s[0],s[1]);
   ctx.fillStyle=g;ctx.fillRect(0,0,320,320);
   const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;
   const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending}));
   sprite.scale.set(scale,scale,1);return sprite;
  }
  function makeHaloSphere(radius,color,opacity=.18){
   return new THREE.Mesh(new THREE.SphereGeometry(radius,48,36),new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,side:THREE.BackSide,blending:THREE.AdditiveBlending,
    uniforms:{uColor:{value:new THREE.Color(color)},uOpacity:{value:opacity}},
    vertexShader:'varying vec3 vNormalW; varying vec3 vViewDir; void main(){ vec4 worldPos=modelMatrix*vec4(position,1.0); vNormalW=normalize(mat3(modelMatrix)*normal); vViewDir=normalize(cameraPosition-worldPos.xyz); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader:'uniform vec3 uColor; uniform float uOpacity; varying vec3 vNormalW; varying vec3 vViewDir; void main(){ float rim=pow(1.0-max(0.0,dot(normalize(vNormalW),normalize(vViewDir))),2.9); gl_FragColor=vec4(uColor,rim*uOpacity); }'
   }));
  }
  const maps={
   earth:texture('earth-night-user.jpg'), earthNight:texture('earth-night-user.jpg'), clouds:texture('earth-clouds-alpha.png'),
   moon:texture('moon-map-hd.jpg'), mars:texture('mars-map-hd.jpg'),
   earthBump:texture('earth-relief.jpg',false), moonBump:texture('moon-relief.jpg',false), marsBump:texture('mars-relief.jpg',false)
  };
  scene.add(new THREE.AmbientLight(0x8fa8d2,.38));
  const light=new THREE.DirectionalLight(0xffe8cb,2.65);light.position.set(-8,5,12);scene.add(light);
  const fill=new THREE.DirectionalLight(0x4b81d3,.18);fill.position.set(6,-3,-7);scene.add(fill);
  function planet(radius,color,bump,bumpScale){
   return new THREE.Mesh(new THREE.SphereGeometry(radius,96,72),new THREE.MeshStandardMaterial({map:color,bumpMap:bump,bumpScale,roughness:.94,metalness:0}));
  }
  // Una sola órbita visible: Tierra y Marte avanzan opuestos sobre el mismo anillo.
  // Es un carrusel narrativo, NO un modelo de la órbita real de Marte alrededor de la Tierra.
  // En portada los tamaños aparentes priorizan Luna y Marte; no son una escala física.
  const earthR=2.55,moonR=1.20,marsR=1.92;
  const earthHome=new THREE.Vector3(),marsHome=new THREE.Vector3();
  // v26: radio principal un 43% más ancho y profundidad un 70% mayor que v23;
  // la línea y los planetas usan estos mismos parámetros en cada fotograma.
  const mainPath={rx:12.25,centerY:1.02,depth:8.25};
  // La Luna recorre una órbita espacial inclinada, desplazada hacia el observador.
  // Así nunca queda enterrada detrás del disco terrestre en la portada.
  const moonPath={rx:4.60,ry:1.35}; let earthOrbitalPhase=.18;
  // v27: la Tierra usa DIRECTAMENTE el mapa nocturno proporcionado por el equipo.
  const earth=planet(earthR,maps.earth,maps.earthBump,.018);
  earth.material.emissiveMap=maps.earthNight;earth.material.emissive.set(0xffffff);earth.material.emissiveIntensity=1.2;
  earth.rotation.y=-1.55;earth.rotation.z=.07;scene.add(earth);
  const moon=planet(moonR,maps.moon,maps.moonBump,.10);moon.rotation.y=-.55;scene.add(moon);
  // Prioridad de visibilidad artística: la Luna no desaparece detrás de la Tierra.
  moon.renderOrder=12;moon.material.depthTest=false;
  const mars=planet(marsR,maps.mars,maps.marsBump,.075);mars.rotation.y=.5;scene.add(mars);
  const lunarOrbit=new THREE.Group(); scene.add(lunarOrbit);
  // Trayectoria lunar 3D: plano elíptico inclinado respecto al plano de cámara.
  lunarOrbit.rotation.set(.26,.18,-.09);
  const lunarGuideGroup=new THREE.Group();lunarOrbit.add(lunarGuideGroup);
  const lunarPoints=[];
  for(let i=0;i<=192;i++){
   const angle=i/192*Math.PI*2;
   lunarPoints.push(new THREE.Vector3(moonPath.rx*Math.cos(angle),moonPath.ry*Math.sin(angle),0));
  }
  const lunarGuide=new THREE.Line(new THREE.BufferGeometry().setFromPoints(lunarPoints),new THREE.LineBasicMaterial({color:0xa9c8df,transparent:true,opacity:.24,depthWrite:false}));
  lunarGuideGroup.add(lunarGuide);

  const sharedGuide=new THREE.Group();sharedGuide.position.y=mainPath.centerY;scene.add(sharedGuide);
  // El anillo existe sobre un plano XZ; el gesto vertical lo inclina en 3D.
  function orbitEllipse(group,rx,depth,color,opacity=.19){
   const pts=[];for(let j=0;j<=192;j++){const a=j/192*Math.PI*2;pts.push(new THREE.Vector3(rx*Math.cos(a),0,depth*Math.sin(a)));}
   const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color,transparent:true,opacity,depthWrite:false}));
   group.add(line);return line;
  }
  const oneOrbitalRing=orbitEllipse(sharedGuide,mainPath.rx,mainPath.depth,0x8bc9f5,.37);
  const orbitPoint=new THREE.Vector3();
  lunarGuide.visible=false;

  // Astronauta retirado en v24.
  const astronautMap=texture('astronauta-easteregg.png');
  const astronautHeight=moonR*.18;
  const astronaut=new THREE.Mesh(new THREE.PlaneGeometry(astronautHeight*.78,astronautHeight),new THREE.MeshBasicMaterial({map:astronautMap,transparent:true,depthWrite:false,depthTest:true,alphaTest:.075,side:THREE.DoubleSide}));
  const hiddenDirection=new THREE.Vector3(.04,.18,-.983).normalize();
  astronaut.position.copy(hiddenDirection).multiplyScalar(moonR*1.018);
  astronaut.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),hiddenDirection); astronaut.translateY(astronautHeight*.24); moon.add(astronaut); astronaut.visible=false;

  const clouds=new THREE.Mesh(new THREE.SphereGeometry(earthR*1.013,96,72),new THREE.MeshStandardMaterial({map:maps.clouds,transparent:true,depthWrite:false,opacity:.25,roughness:1,side:THREE.DoubleSide})); earth.add(clouds);
  const lightDirection=light.position.clone().sub(earth.position).normalize();
  const nightSphere=new THREE.Mesh(new THREE.SphereGeometry(earthR*1.008,96,72),new THREE.ShaderMaterial({
   uniforms:{nightMap:{value:maps.earthNight},lightDirection:{value:lightDirection}},
   vertexShader:`varying vec2 vUv; varying vec3 vNormalW; void main(){ vUv=uv; vNormalW=normalize(mat3(modelMatrix)*normal); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
   fragmentShader:`uniform sampler2D nightMap; uniform vec3 lightDirection; varying vec2 vUv; varying vec3 vNormalW; void main(){ float dotNL=dot(normalize(vNormalW),normalize(lightDirection)); float darkness=(1.0-smoothstep(-0.25,0.18,dotNL)); vec3 tex=texture2D(nightMap,vUv).rgb; float lum=max(max(tex.r,tex.g),tex.b); float alpha=darkness*smoothstep(0.03,0.38,lum)*0.42; gl_FragColor=vec4(tex*1.08,alpha); }`,
   transparent:true, depthWrite:false, blending:THREE.AdditiveBlending
  })); nightSphere.visible=false;earth.add(nightSphere); // La propia esfera emite las luces; evitar doble textura superpuesta
  const atmos=makeHaloSphere(earthR*1.055,0x78b9ef,.17); earth.add(atmos);
  // Brillo realista solo en el contorno; nunca sobre la textura central.
  const moonHalo=makeHaloSphere(moonR*1.09,0xe1ecf5,.075);moon.add(moonHalo);
  const marsHalo=makeHaloSphere(marsR*1.09,0xd9917b,.082);mars.add(marsHalo);

  // Sistema marciano: órbitas inspiradas en Fobos y Deimos (visualmente comprimidas).
  const moonMaterial=new THREE.MeshStandardMaterial({color:0xa7acb5,roughness:1,metalness:0});
  function rockPlaceholder(size){ return new THREE.Mesh(new THREE.IcosahedronGeometry(size,2),moonMaterial.clone()); }
  const phobosOrbit=new THREE.Group(),deimosOrbit=new THREE.Group();
  phobosOrbit.position.copy(mars.position); deimosOrbit.position.copy(mars.position);
  phobosOrbit.rotation.set(-.52,.12,.22);deimosOrbit.rotation.set(.67,-.30,-.19);
  scene.add(phobosOrbit,deimosOrbit);
  // Las lunas marcianas giran sobre anillos auténticamente 3D inclinados en profundidad.
  // Un rotor independiente gira dentro de un plano fijo: evita reducir su órbita a un círculo 2D.
  const phobosGuideR=marsR*1.95,deimosGuideR=marsR*2.70;
  function orbit3D(group,r,color,opacity){
   const points=[];
   for(let n=0;n<=192;n++){
    const angle=n/192*Math.PI*2;
    points.push(new THREE.Vector3(r*Math.cos(angle),0,r*Math.sin(angle)));
   }
   const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color,transparent:true,opacity,depthWrite:false}));
   group.add(line);return line;
  }
  const phobosGuide=orbit3D(phobosOrbit,phobosGuideR,0xd6bbaa,.27);
  const deimosGuide=orbit3D(deimosOrbit,deimosGuideR,0xaebcd1,.19);
  phobosGuide.visible=false;deimosGuide.visible=false;
  const phobosRotor=new THREE.Group(),deimosRotor=new THREE.Group();
  phobosOrbit.add(phobosRotor);deimosOrbit.add(deimosRotor);
  const phobosHolder=new THREE.Group(),deimosHolder=new THREE.Group();
  phobosRotor.add(phobosHolder);deimosRotor.add(deimosHolder);
  const phobosBody=new THREE.Group(),deimosBody=new THREE.Group(); phobosHolder.add(phobosBody); deimosHolder.add(deimosBody);
  const phobosVisualR=marsR*.205,deimosVisualR=marsR*.165;
  const phobosFallback=rockPlaceholder(phobosVisualR),deimosFallback=rockPlaceholder(deimosVisualR); phobosBody.add(phobosFallback); deimosBody.add(deimosFallback);
  const phobosHit=new THREE.Mesh(new THREE.SphereGeometry(phobosVisualR*1.75,18,14),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));
  const deimosHit=new THREE.Mesh(new THREE.SphereGeometry(deimosVisualR*1.95,18,14),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));
  phobosHit.userData.subject='phobos'; deimosHit.userData.subject='deimos'; phobosBody.add(phobosHit); deimosBody.add(deimosHit);
  phobosRotor.rotation.y=-1.0;deimosRotor.rotation.y=2.1;
  function prepareModel(root,targetDiameter,subject){
   const bounds=new THREE.Box3().setFromObject(root),sz=new THREE.Vector3(),center=new THREE.Vector3();
   bounds.getSize(sz);bounds.getCenter(center);
   const holder=new THREE.Group();root.position.sub(center);holder.add(root);
   holder.scale.setScalar(targetDiameter/(Math.max(sz.x,sz.y,sz.z)||1));
   holder.traverse(obj=>{obj.userData.subject=subject; if(obj.isMesh){obj.castShadow=false;obj.receiveShadow=false;}});
   return holder;
  }
  if(gltfLoader){
   gltfLoader.load('assets/models/phobos.glb',g=>{phobosFallback.visible=false;phobosBody.add(prepareModel(g.scene,phobosVisualR*2,'phobos'));},undefined,e=>console.warn('Modelo Fobos no cargó',e));
   gltfLoader.load('assets/models/deimos.glb',g=>{deimosFallback.visible=false;deimosBody.add(prepareModel(g.scene,deimosVisualR*2,'deimos'));},undefined,e=>console.warn('Modelo Deimos no cargó',e));
  }

  const lunarOffset=new THREE.Vector3();
  function placeBothSystems(){
   const a=commonOrbit.phase;
   // El punto (0, centerY, 0) de la órbita nunca se traslada por arrastrar.
   // Rotamos su plano alrededor del eje X para mostrar distintos ángulos 3D.
   sharedGuide.position.y=mainPath.centerY;
   sharedGuide.rotation.x=commonOrbit.tilt;
   const orbitZ=mainPath.depth*Math.sin(a);
   orbitPoint.set(mainPath.rx*Math.cos(a),-orbitZ*Math.sin(commonOrbit.tilt),orbitZ*Math.cos(commonOrbit.tilt));
   earthHome.set(orbitPoint.x,mainPath.centerY+orbitPoint.y,orbitPoint.z);
   // Marte comparte el anillo en el extremo opuesto, con pequeño margen
   // de profundidad para conservar su visibilidad en los cruces visuales.
   marsHome.set(-orbitPoint.x,mainPath.centerY-orbitPoint.y,1.25-orbitPoint.z);
   earth.position.copy(earthHome);mars.position.copy(marsHome);
   // La órbita lunar es tridimensional y conserva su propia inclinación.
   lunarOffset.set(moonPath.rx*Math.cos(earthOrbitalPhase),moonPath.ry*Math.sin(earthOrbitalPhase),0);
   lunarOffset.applyEuler(lunarOrbit.rotation);
   // La Luna se mantiene separada en proyección cuando la Tierra está en el borde.
   lunarOrbit.position.set(earthHome.x,earthHome.y,earthHome.z-1.20);
   moon.position.copy(lunarOrbit.position).add(lunarOffset);
   phobosOrbit.position.copy(marsHome);deimosOrbit.position.copy(marsHome);
  }
  const objects={earth,moon,mars}; let activeView=null;
  const camTarget=new THREE.Vector3(0,0,15.5);const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  const zeroVec=new THREE.Vector3();
  function marsWorldPos(){ return mars.getWorldPosition(new THREE.Vector3()); }
  function setMarsMoonLayout(){
   // Mismas órbitas orbitales ilustrativas tanto en portada como en exploración.
   phobosHolder.position.set(phobosGuideR,0,0);
   deimosHolder.position.set(deimosGuideR,0,0);
  }
  function locate(key){
   const o=objects[key]; if(!o)return null; const v=o.getWorldPosition(new THREE.Vector3()).project(camera); if(v.z>=1)return null;
   const r=host.getBoundingClientRect(); const cameraSpace=o.getWorldPosition(new THREE.Vector3()).applyMatrix4(camera.matrixWorldInverse); const depth=Math.abs(cameraSpace.z);
   const diameter=(o.geometry.parameters.radius*2)*o.scale.x*r.height/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*depth);
   return {x:r.left+(v.x+1)/2*r.width,y:r.top+(1-v.y)/2*r.height,r:diameter/2};
  }
  function hitTest(e){
   if(activeView||performance.now()<commonOrbit.suppressUntil)return; const r=host.getBoundingClientRect(); pointer.x=2*(e.clientX-r.left)/r.width-1; pointer.y=1-2*(e.clientY-r.top)/r.height; raycaster.setFromCamera(pointer,camera);
   const hit=raycaster.intersectObjects([earth,moon,mars],false)[0]; if(hit){ const name=Object.keys(objects).find(k=>objects[k]===hit.object); if(name){e.stopPropagation();selectPlanet(name);} }
  }
  host.addEventListener('click',e=>{if(performance.now()<commonOrbit.suppressUntil){e.stopPropagation();e.preventDefault();return;}hitTest(e);});
  attachOrbitDrag(host,()=>!activeView);host.style.cursor='grab';

  const spins={earth:earth.rotation.y,moon:moon.rotation.y,mars:mars.rotation.y,phobos:Math.random()*Math.PI*2,deimos:Math.random()*Math.PI*2};
  const spinRates={earth:.071,moon:.089,mars:.063,phobos:.36,deimos:.14};
  const orbitRates={phobos:.58,deimos:.145};
  const manualStates={moon:{yaw:0,pitch:0,dragged:false,releasedAt:-Infinity},mars:{yaw:0,pitch:0,dragged:false,releasedAt:-Infinity},phobos:{yaw:0,pitch:0,dragged:false,releasedAt:-Infinity},deimos:{yaw:0,pitch:0,dragged:false,releasedAt:-Infinity}};
  let dragSubject=null,dragging=false,dragPointer=null,prevX=0,prevY=0,lastCountdown=-1;
  const countdown=$('rotation-countdown');
  const moonControls=$('moon-controls');
  const moonInfo=$('moon-info');
  const moonFacts={phobos:'Fobos · 22.2 km de diámetro · radio orbital 9,377 km · una vuelta cada 7 h 39 min.',deimos:'Deimos · 12.6 km de diámetro · radio orbital 23,460 km · una vuelta cada 30 h 21 min.'};
  document.querySelectorAll('[data-mars-moon]').forEach(b=>b.addEventListener('click',()=>{
   const key=b.dataset.marsMoon; if(activeView!=='mars')return;
   dragSubject=key; moonInfo.textContent=tr('marsmoon.'+key,moonFacts[key])+tr('marsmoon.drag',' Arrastra el pequeño satélite para girarlo.');
   document.querySelectorAll('[data-mars-moon]').forEach(n=>n.classList.toggle('active',n===b));
  }));
  function subjectLabel(s){ return s==='phobos'?'FOBOS':s==='deimos'?'DEIMOS':s==='moon'?'LUNA':'MARTE'; }
  function activeManual(){ return dragSubject&&manualStates[dragSubject] ? manualStates[dragSubject] : (activeView&&manualStates[activeView] ? manualStates[activeView] : null); }
  function updateCountdown(now){
   if(!countdown){return;} const state=activeManual();
   if(!activeView){countdown.textContent=''; return;}
   if(dragging){countdown.textContent=tr('focus.rotate','GIRANDO · CONTROL SUAVE')+' · '+subjectLabel(dragSubject||activeView);return;}
   if(!state||!state.dragged){countdown.textContent=activeView==='mars'?tr('focus.marsmoons','MARTE, FOBOS Y DEIMOS · ARRASTRA PARA EXPLORAR'):tr('focus.auto','ROTACIÓN AUTOMÁTICA · ARRASTRA PARA EXPLORAR');return;}
   const left=Math.ceil(Math.max(0,(5000-(now-state.releasedAt))/1000));
   countdown.textContent=left>0?`${subjectLabel(dragSubject||activeView)} · ${tr('focus.wait','RETORNO EN')} ${left} s`:`${subjectLabel(dragSubject||activeView)} · ${tr('focus.return','RECUPERANDO ORIENTACIÓN ORIGINAL')}`;
  }
  function releaseDrag(e){
   if(!dragging||(e&&e.pointerId!==dragPointer))return;
   dragging=false;
   const state=dragSubject&&manualStates[dragSubject]; if(state)state.releasedAt=performance.now();
   try{host.releasePointerCapture(dragPointer);}catch(_e){}
   dragPointer=null; host.style.cursor=activeView?'grab':'pointer'; lastCountdown=-1;
  }
  function applyDecay(key,dt,time){
   const st=manualStates[key]; if(!st||dragging&&dragSubject===key||!st.dragged||time-st.releasedAt<5000)return;
   if(Math.abs(st.yaw)>Math.PI)st.yaw=Math.atan2(Math.sin(st.yaw),Math.cos(st.yaw)); if(Math.abs(st.pitch)>Math.PI)st.pitch=Math.atan2(Math.sin(st.pitch),Math.cos(st.pitch));
   const spring=Math.exp(-dt*1.35); st.yaw*=spring; st.pitch*=spring;
   if(Math.abs(st.yaw)<.0003&&Math.abs(st.pitch)<.0003){st.yaw=0;st.pitch=0;st.dragged=false; if(dragSubject===key)dragSubject=activeView==='moon'?'moon':'mars';}
  }
  host.addEventListener('pointerdown',e=>{
   if(!activeView||e.button!==0||e.pointerType==='touch'&&e.isPrimary===false)return;
   const r=host.getBoundingClientRect(); pointer.set(2*(e.clientX-r.left)/r.width-1,1-2*(e.clientY-r.top)/r.height); raycaster.setFromCamera(pointer,camera);
   let targets=[objects[activeView]], subject=activeView;
   if(activeView==='mars')targets=[phobosHit,deimosHit,mars];
   const hits=raycaster.intersectObjects(targets,true);
   if(hits.length){const hit=hits[0].object; if(hit.userData.subject)subject=hit.userData.subject;}
   dragging=true; dragSubject=subject; dragPointer=e.pointerId; prevX=e.clientX; prevY=e.clientY;
   const st=manualStates[subject]; if(st){st.dragged=true; st.releasedAt=-Infinity;}
   host.setPointerCapture(e.pointerId); host.style.cursor='grabbing'; e.preventDefault();
  });
  host.addEventListener('pointermove',e=>{
   if(!dragging||e.pointerId!==dragPointer||!dragSubject)return; const dx=e.clientX-prevX,dy=e.clientY-prevY; prevX=e.clientX; prevY=e.clientY;
   const sensitivity=dragSubject==='phobos'||dragSubject==='deimos'?0.0062:0.0042; const st=manualStates[dragSubject]; if(!st)return;
   st.yaw+=dx*sensitivity; st.pitch+=dy*sensitivity; e.preventDefault();
  });
  host.addEventListener('pointerup',releaseDrag); host.addEventListener('pointercancel',releaseDrag); host.addEventListener('lostpointercapture',releaseDrag);

  function applyBodyZoom(){
   const k=activeView?1:menuScale.value;
   earth.scale.setScalar(k);moon.scale.setScalar(k);mars.scale.setScalar(k);
   phobosBody.scale.setScalar(k);deimosBody.scale.setScalar(k);
  }
  sceneControl={select:()=>{},project:locate,zoom:applyBodyZoom,focus:(key)=>{
   activeView=key;applyBodyZoom();

   releaseDrag(); dragSubject=key==='moon'?'moon':key==='mars'?'mars':null; for(const st of Object.values(manualStates)){st.yaw=0;st.pitch=0;st.dragged=false;st.releasedAt=-Infinity;}
   if(moonControls)moonControls.hidden=key!=='mars';
   if(moonInfo)moonInfo.textContent=tr('marsmoon.hint','Fobos y Deimos orbitan Marte. Selecciona una luna o arrástrala para girarla.');
   astronaut.visible=false; earth.visible=!key; moon.visible=!key||key==='moon'; mars.visible=!key||key==='mars';
   moonHalo.visible=!key||key==='moon'; marsHalo.visible=!key||key==='mars'; sharedGuide.visible=!key;
   // Los satélites siguen orbitando siempre, pero sus tres líneas orbitales se ocultan en la portada.
   lunarOrbit.visible=!key&&false; phobosOrbit.visible=!key||key==='mars'; deimosOrbit.visible=!key||key==='mars';
   lunarGuide.visible=false;
   phobosGuide.visible=key==='mars';deimosGuide.visible=key==='mars';
   host.style.cursor='grab'; setMarsMoonLayout();
  }};
  applyBodyZoom();
  if(focusPlanet)sceneControl.focus(focusPlanet);
  // Etiquetas acopladas a posiciones 3D por transform (sin cambios de layout ni saltos de 170 ms).
  const labelNodes=Object.fromEntries(['earth','moon','mars','phobos','deimos'].map(k=>[k,document.querySelector('[data-marker="'+k+'"]')]));
  const markerRect={width:1,height:1,left:0,top:0};
  function setMarkerPosition(el,x,y,dy=0){
   if(!el)return;
   el.style.transform='translate3d('+x.toFixed(2)+'px,'+(y+dy).toFixed(2)+'px,0) translateX(-50%)';
  }
  function updateMarkers(){
   const width=host.clientWidth,height=host.clientHeight;
   for(const [key,o] of Object.entries(objects)){
    const label=labelNodes[key];if(!label)continue;
    if(activeView){label.style.visibility='hidden';continue;}
    const world=o.getWorldPosition(new THREE.Vector3()),v=world.project(camera);
    const depth=Math.abs(o.getWorldPosition(new THREE.Vector3()).applyMatrix4(camera.matrixWorldInverse).z);
    const radius=o.geometry.parameters.radius*o.scale.x*height/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*depth);
    const x=(v.x+1)*width/2,y=(1-v.y)*height/2+radius+10;
    label.style.visibility=v.z<1&&x>10&&x<width-10&&y>68&&y<height-45?'visible':'hidden';
    setMarkerPosition(label,x,y);
   }
   const mp=mars.getWorldPosition(new THREE.Vector3());const marsCenter=mp.clone().project(camera);
   const mx=(marsCenter.x+1)*width/2,my=(1-marsCenter.y)*height/2;
   const marsDepth=Math.abs(mp.applyMatrix4(camera.matrixWorldInverse).z);
   const mr=marsR*mars.scale.x*height/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*marsDepth);
   for(const [key,body] of [['phobos',phobosBody],['deimos',deimosBody]]){
    const label=labelNodes[key];if(!label)continue;
    const pos=body.getWorldPosition(new THREE.Vector3()),projection=pos.clone().project(camera);
    const x=(projection.x+1)*width/2,y=(1-projection.y)*height/2;
    const hiddenBehind=pos.z<mars.position.z&&Math.hypot(x-mx,y-my)<mr*.94;
    const shown=(!activeView||activeView==='mars')&&!hiddenBehind&&projection.z<1&&x>12&&x<width-12&&y>85&&y<height-42;
    label.style.visibility=shown?'visible':'hidden';
    if(shown)setMarkerPosition(label,x,y,activeView==='mars'?11:15);
   }
  }
  function resize(){
   const ww=Math.max(1,host.clientWidth),hh=Math.max(1,host.clientHeight),small=innerWidth<650;
   mainPath.rx=small?5.85:innerWidth<1050?9.35:12.25;
   mainPath.centerY=small?1.05:1.02;
   mainPath.depth=small?4.65:innerWidth<1050?6.35:8.25;
   moonPath.rx=small?2.80:4.60;moonPath.ry=small?1.95:1.35;
   sharedGuide.position.y=mainPath.centerY;
   // No regenerar la geometría en cada fotograma; al cambiar ventana se ajusta la línea.
   oneOrbitalRing.geometry.dispose();
   const pts=[];for(let j=0;j<=192;j++){const a=j/192*Math.PI*2;pts.push(new THREE.Vector3(mainPath.rx*Math.cos(a),0,mainPath.depth*Math.sin(a)));}
   oneOrbitalRing.geometry=new THREE.BufferGeometry().setFromPoints(pts);
   const lunarCoords=[];
   for(let j=0;j<=192;j++){const t=j/192*Math.PI*2;lunarCoords.push(new THREE.Vector3(moonPath.rx*Math.cos(t),moonPath.ry*Math.sin(t),0));}
   lunarGuide.geometry.dispose();lunarGuide.geometry=new THREE.BufferGeometry().setFromPoints(lunarCoords);
   placeBothSystems();setMarsMoonLayout();
   camera.aspect=ww/hh;camera.fov=small?64:innerWidth<1000?53:43;
   camera.updateProjectionMatrix();renderer.setSize(ww,hh,false);
   camera.updateMatrixWorld();scene.updateMatrixWorld(true);updateMarkers();positionCard();blockCacheTime=-Infinity;
  }
  addEventListener('resize',resize); resize(); $('planet-fallback').style.display='none';
  let lastRender=performance.now(),lastCardUpdate=-Infinity;
  function updateCameraTarget(){
   const small=innerWidth<760;
   if(activeView){
    const o=objects[activeView]; camera.fov=small?54:43; const tan=Math.tan(THREE.MathUtils.degToRad(camera.fov/2));
    const relativeSize=activeView==='mars'?(small?.25:.32):(small?.45:.70);
    const pos=o.getWorldPosition(new THREE.Vector3());
    const depth=o.geometry.parameters.radius/(tan*relativeSize); const centerX=small?.50:(activeView==='moon'?.35:.65); const centerY=small?.29:.50;
    camTarget.set(pos.x-(centerX*2-1)*depth*tan*camera.aspect,pos.y-(1-centerY*2)*depth*tan,pos.z+depth);
   }else{ camera.fov=innerWidth<650?70:innerWidth<1000?53:43; camTarget.set(0,0,innerWidth<650?30:21.1); }
   camera.updateProjectionMatrix();
  }
  function frame(time){
   requestAnimationFrame(frame); if(document.hidden){lastRender=time;return;}
   const targetFrame=innerWidth<700?1000/30:1000/60; if(time-lastRender<targetFrame-1)return;
   const dt=Math.min((time-lastRender)/1000,.08); lastRender=time;
   for(const key of Object.keys(spins))spins[key]+=dt*spinRates[key];
   // El usuario puede adelantar, retroceder o girar manualmente el anillo común.
   // Al enfocar un mundo, se congela el traslado orbital, no la rotación planetaria.
   orbitAdvance(dt,time);
   if(!activeView)earthOrbitalPhase+=dt*.155;
   placeBothSystems();
   phobosRotor.rotation.y+=dt*orbitRates.phobos;
   deimosRotor.rotation.y+=dt*orbitRates.deimos;
   for(const key of Object.keys(manualStates))applyDecay(key,dt,time);
   if(activeView&&time-lastCountdown>=160){updateCountdown(time); lastCountdown=time;}
   earth.rotation.y=spins.earth; moon.rotation.y=spins.moon+manualStates.moon.yaw; mars.rotation.y=spins.mars+manualStates.mars.yaw;
   earth.rotation.x=0; moon.rotation.x=manualStates.moon.pitch; mars.rotation.x=manualStates.mars.pitch;
   phobosBody.rotation.y=spins.phobos+manualStates.phobos.yaw; phobosBody.rotation.x=manualStates.phobos.pitch;
   deimosBody.rotation.y=spins.deimos+manualStates.deimos.yaw; deimosBody.rotation.x=manualStates.deimos.pitch;
   clouds.rotation.y+=dt*.018; updateCameraTarget(); const easing=1-Math.exp(-dt*3.8); camera.position.lerp(camTarget,easing);
   scene.updateMatrixWorld(true);camera.updateMatrixWorld();
   renderer.render(scene,camera);
   // Sin retardo perceptible: los nombres se mueven exactamente con sus satélites.
   updateMarkers();
   if(selected&&!card.hidden&&time-lastCardUpdate>18){positionCard();lastCardUpdate=time;}
  }
  requestAnimationFrame(frame);
 }catch(err){
   console.error('Motor 3D no disponible. Se activa la rotación animada de respaldo:',err);
   $('universe').style.display='none';
   document.body.classList.add('fallback-active');
   const facts={phobos:'Fobos: 22.2 km de diámetro, a unos 9,377 km del centro de Marte, órbita de 7 h 39 min.',deimos:'Deimos: 12.6 km de diámetro, a unos 23,460 km del centro de Marte, órbita de 30 h 21 min.'};
   document.querySelectorAll('[data-mars-moon]').forEach(btn=>btn.addEventListener('click',()=>{
    $('moon-info').textContent=facts[btn.dataset.marsMoon]+' · Los satélites continúan orbitando en este modo animado.';
   }));
   // Respaldo alternativo: una órbita única controlable aunque no cargue WebGL.
   const fallback=$('planet-fallback');
   const fb=Object.fromEntries(['earth','moon','mars'].map(k=>[k,document.querySelector('.fallback-planet[data-planet="'+k+'"]')]));
   const labels=Object.fromEntries(['earth','moon','mars'].map(k=>[k,document.querySelector('[data-marker="'+k+'"]')]));
   document.querySelectorAll('.planet-markers .mars-satellite-label').forEach(el=>el.style.display='none');
   attachOrbitDrag(fallback,()=>!focusPlanet);
   let fallbackLast=performance.now(),fallbackMoonPhase=.18;
   function fallbackFrame(now){
    requestAnimationFrame(fallbackFrame);if(document.hidden){fallbackLast=now;return;}
    if(now-fallbackLast<17)return;
    const dt=Math.min((now-fallbackLast)/1000,.07);fallbackLast=now;
    orbitAdvance(dt,now);
    if(!focusPlanet)fallbackMoonPhase+=dt*.155;
    const W=fallback.clientWidth,H=fallback.clientHeight,small=innerWidth<650;
    const rx=Math.min(W*(small?.36:.45),small?260:690);
    const centerX=W*.5,centerY=H*(small?.34:.35);
    const verticalRadius=H*(small?.43:.52)*Math.sin(commonOrbit.tilt);
    const ry=Math.max(2,Math.abs(verticalRadius));
    // Proyección 2D de un plano orbital inclinado, con centro inmóvil.
    const e={x:centerX+Math.cos(commonOrbit.phase)*rx,y:centerY+Math.sin(commonOrbit.phase)*verticalRadius};
    const m={x:centerX-Math.cos(commonOrbit.phase)*rx,y:centerY-Math.sin(commonOrbit.phase)*verticalRadius};
    const mo={x:e.x+(small?W*.29:Math.min(280,W*.24))*Math.cos(fallbackMoonPhase),
              y:e.y+(small?H*.14:Math.min(145,H*.17))*Math.sin(fallbackMoonPhase)};
    const coords={earth:e,moon:mo,mars:m};
    if(focusPlanet==='moon'){coords.moon={x:W*(small?.5:.35),y:H*(small?.30:.50)};}
    if(focusPlanet==='mars'){coords.mars={x:W*(small?.5:.65),y:H*(small?.30:.50)};}
    const guide=document.querySelector('.fallback-shared-guide');
    if(guide){guide.style.left=centerX+'px';guide.style.top=centerY+'px';guide.style.width=(rx*2)+'px';guide.style.height=(ry*2)+'px';}
    for(const [key,pos] of Object.entries(coords)){
     const node=fb[key],label=labels[key];if(!node)continue;
     if(!(focusPlanet&&focusPlanet!==key)){
      node.style.left=pos.x+'px';node.style.top=pos.y+'px';node.style.transform='translate(-50%,-50%) scale('+(focusPlanet?1:menuScale.value)+')';
      if(label&&!focusPlanet){const diameter=node.offsetWidth*menuScale.value;
       label.style.transform='translate3d('+pos.x.toFixed(1)+'px,'+(pos.y+diameter/2+12).toFixed(1)+'px,0) translateX(-50%)';label.style.visibility='visible';}
     }
    }
    const satSystem=document.querySelector('.fallback-mars-orbits');
    if(satSystem){satSystem.style.left=coords.mars.x+'px';satSystem.style.top=coords.mars.y+'px';}
    for(const [id,phase] of [['p',now*.00058],['d',2.4+now*.00014]]){
     const ring=document.querySelector('.fallback-orbit.orbit-'+id);
     if(!ring)continue;ring.style.left='0';ring.style.top='0';
     const sat=ring.querySelector('.fallback-satellite');if(sat){sat.style.left=(50+48*Math.cos(phase))+'%';sat.style.top=(50+48*Math.sin(phase))+'%';}
    }
    if(selected&&!card.hidden)positionCard();
   }
   requestAnimationFrame(fallbackFrame);
 }
})();
