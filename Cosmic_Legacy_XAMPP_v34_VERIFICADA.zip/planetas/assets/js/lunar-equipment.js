/* Cosmic Legacy v14 · inventario educativo CURADO, no exhaustivo.
   El índice coincide con WORLDS.moon.items de vr.js.
   Esquemas no son fotografías ni modelos exactos. NASA es la fuente documental. */
const NASA_APOLLO = 'https://www.nasa.gov/the-apollo-program/';
const NASA_EASEP = 'https://science.nasa.gov/wp-content/uploads/2023/09/Apollo_11.pdf';
const NASA_LASER = 'https://www.nasa.gov/missions/apollo/apollo-11/the-apollo-experiment-that-keeps-on-giving/';
const NASA_LRV = 'https://nssdc.gsfc.nasa.gov/planetary/lunar/apollo_lrv.html';
const NASA_ALSEP = 'https://www.nasa.gov/wp-content/uploads/static/history/SP-4029/Apollo_18-31_ALSEP_Arrays_and_Status.htm';
const NASA_SURVEYOR = 'https://science.nasa.gov/mission/surveyor-3/';
const rover = (mission,year) => ({name:`Vehículo Lunar LRV · ${mission}`,class:'VEHÍCULO TRIPULADO · NO ROBOT AUTÓNOMO',status:'Permanece en la Luna',year,art:'rover',
 what:'Vehículo eléctrico de cuatro ruedas con dos asientos, antena y espacio para herramientas y muestras. Se conducía por los astronautas.',
 purpose:'Ampliar la distancia de exploración y transportar instrumentos, fotografías y muestras geológicas por la superficie.',
 fate:`El vehículo utilizado en ${mission} quedó estacionado en la Luna al finalizar la misión; la tripulación regresó sin él.`,
 discovery:'Hizo posible estudiar terrenos mucho más alejados del módulo lunar que los recorridos a pie.',source:NASA_LRV,
 photo:'https://assets.science.nasa.gov/content/dam/science/psd/lunar-science/2023/09/as15-85-11471_orig.jpg'});
const descent = (name,year) => ({name:`Etapa de descenso · ${name}`,class:'MÓDULO LUNAR · ESTRUCTURA FIJA',status:'Permanece en la Luna',year,art:'lander',
 what:'Parte inferior del módulo lunar: estructura con cuatro patas, motor de descenso y compartimentos de carga.',
 purpose:'Realizar el aterrizaje y servir como plataforma de lanzamiento de la etapa de ascenso.',
 fate:'La etapa superior despegó para reunirse con la nave orbital; la base quedó en el lugar de aterrizaje.',
 discovery:'Su diseño permitió a los astronautas aterrizar y volver a despegar sin llevar toda la nave a la superficie.',source:NASA_APOLLO});
const alsep = (mission,year) => ({name:`Estación ALSEP · ${mission}`,class:'CONJUNTO DE EXPERIMENTOS',status:'Permanece en la Luna',year,art:'alsep',
 what:'Conjunto de instrumentos automatizados conectados a una estación científica de superficie.',
 purpose:'Registrar fenómenos físicos de la Luna y enviar mediciones por radio a la Tierra después de la partida de los astronautas.',
 fate:'Los equipos se dejaron en la superficie; el programa ALSEP cesó sus transmisiones en 1977.',
 discovery:'Proporcionó información científica durante años, mucho después de que las tripulaciones regresaran.',source:NASA_ALSEP});
const passive = (mission,year) => ({name:`Sismómetro pasivo · ${mission}`,class:'INSTRUMENTO CIENTÍFICO AUTOMÁTICO',status:'Permanece en la Luna',year,art:'seismic',
 what:'Equipo sensible a vibraciones del suelo lunar, con electrónica, sensores y sistema de comunicación.',
 purpose:'Detectar sismos lunares e impactos para investigar el interior de la Luna.',
 fate:'Se instaló para operar sobre la superficie; no se retiró al terminar la visita humana.',
 discovery:'Las señales sísmicas aportaron información sobre la estructura y actividad interna lunar.',source:mission==='Apollo 11'?NASA_EASEP:NASA_ALSEP});
const reflector = (mission,year) => ({name:`Retrorreflector láser · ${mission}`,class:'EXPERIMENTO ÓPTICO PASIVO',status:'Permanece en la Luna',year,art:'reflector',
 what:'Panel con prismas que devuelven la luz láser hacia el lugar desde donde fue enviada.',
 purpose:'Permitir medir con precisión la distancia Tierra–Luna mediante el tiempo de viaje de pulsos láser.',
 fate:'Se quedó colocado en la superficie; a diferencia de los instrumentos activos, no necesita electricidad para reflejar luz.',
 discovery:'Ha apoyado mediciones de la distancia lunar y estudios de la dinámica de la Luna.',source:NASA_LASER});

export const LUNAR_EQUIPMENT = [
 // 0: Apollo 11 Eagle
 {note:'Apollo 11 no llevó ningún rover. Armstrong y Aldrin recorrieron la zona a pie.',items:[
  descent('Eagle · Apollo 11','1969'),passive('Apollo 11','1969'),reflector('Apollo 11','1969')
 ]},
 // 1: Apollo 11 EASEP
 {note:'EASEP era un conjunto de experimentos, no un robot explorador ni un vehículo.',items:[
  passive('Apollo 11 · EASEP','1969'),reflector('Apollo 11 · EASEP','1969'),
  {name:'Detector de polvo lunar (integrado en PSEP)',class:'SENSOR CIENTÍFICO',status:'Permanece con el experimento',year:'1969',art:'seismic',
   what:'Sensor asociado al paquete sísmico para observar cambios relacionados con polvo y condiciones ambientales sobre sus superficies.',
   purpose:'Ayudar a evaluar el ambiente del instrumental desplegado sobre el suelo lunar.',fate:'Formaba parte del instrumental que quedó instalado con el paquete PSEP.',
   discovery:'Ayudó a comprender condiciones de operación para experimentos expuestos a la superficie lunar.',source:'https://science.nasa.gov/wp-content/uploads/2023/09/Apollo_11.pdf'}
 ]},
 // 2: Surveyor 3
 {note:'Surveyor 3 era una sonda robótica fija: no tenía ruedas ni se desplazaba como rover. Apollo 12 recuperó varias piezas.',items:[
  {name:'Sonda robótica Surveyor 3',class:'ATERRIZADOR ROBÓTICO · NO ROVER',status:'Estructura principal permanece',year:'1967',art:'surveyor',
   what:'Sonda automática con tres patas, cámara de televisión y una pala mecánica para estudiar el suelo.',
   purpose:'Realizar un aterrizaje suave y estudiar la superficie lunar desde una posición fija mediante imágenes y pruebas del suelo.',
   fate:'La estructura general quedó en la Luna; astronautas de Apollo 12 retiraron varios componentes en 1969.',
   discovery:'Sus pruebas ayudaron a entender la firmeza del suelo lunar antes de las expediciones tripuladas.',source:NASA_SURVEYOR,
   photo:'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/solar/2023/06/as12-48-7134_1280.jpg'},
  {name:'Cámara de televisión de Surveyor 3',class:'SISTEMA DE IMAGEN',status:'RECUPERADA POR APOLLO 12',year:'1967–1969',art:'camera',
   what:'Cámara robotizada con sistema óptico y espejo orientable para transmitir imágenes de la Luna.',
   purpose:'Fotografiar la superficie y los efectos de las pruebas hechas por Surveyor 3.',
   fate:'Apollo 12 desmontó y devolvió la cámara a la Tierra; no debe mostrarse como si todavía estuviera en la Luna.',
   discovery:'El análisis del equipo recuperado permitió estudiar los efectos de la exposición prolongada en el ambiente lunar.',source:NASA_SURVEYOR},
  {name:'Pala mecánica de Surveyor 3',class:'BRAZO DE INVESTIGACIÓN ROBÓTICA',status:'RECUPERADA POR APOLLO 12',year:'1967–1969',art:'scoop',
   what:'Pala accionada desde la Tierra para excavar pequeñas zanjas y probar la resistencia del suelo lunar.',
   purpose:'Evaluar textura y comportamiento mecánico del terreno.',
   fate:'La pala fue recuperada por Apollo 12 y llevada a la Tierra para estudiarla.',
   discovery:'Sus ensayos ayudaron a confirmar que el suelo podía sostener los módulos lunares.',source:NASA_SURVEYOR}
 ]},
 // 3: Apollo 12 ALSEP
 {note:'Apollo 12 no llevó rover; usó equipos científicos automáticos y exploración humana a pie.',items:[
  alsep('Apollo 12','1969'),passive('Apollo 12','1969'),
  {name:'Magnetómetro de superficie · Apollo 12',class:'INSTRUMENTO CIENTÍFICO',status:'Permanece en la Luna',year:'1969',art:'magnet',
   what:'Instrumento desplegado para medir campos magnéticos sobre la superficie lunar.',
   purpose:'Investigar el magnetismo local y su relación con el interior y el entorno de la Luna.',
   fate:'Quedó junto al sistema ALSEP después de la salida de la tripulación.',
   discovery:'Sus mediciones contribuyeron a comprender las propiedades magnéticas lunares.',source:NASA_ALSEP}
 ]},
 // 4: Apollo 14 MET
 {note:'Apollo 14 utilizó un carrito manual MET, no un vehículo robótico motorizado.',items:[
  {name:'Carrito MET · Apollo 14',class:'CARRO MANUAL · NO ROVER AUTÓNOMO',status:'Permanece en la Luna',year:'1971',art:'met',
   what:'Carrito de dos ruedas que los astronautas empujaban o tiraban para transportar herramientas, cámaras y muestras.',
   purpose:'Reducir el esfuerzo de cargar equipo a mano durante los recorridos lunares.',
   fate:'Después de su uso fue dejado en la Luna.',discovery:'Fue una solución intermedia antes de los vehículos eléctricos LRV de Apollo 15–17.',source:'https://www.nasa.gov/history/alsj-and-afj/'},
  descent('Antares · Apollo 14','1971'),alsep('Apollo 14','1971')
 ]},
 // 5: Apollo 15 Rover
 {note:'Aquí sí aparece un vehículo explorador: el LRV fue conducido por astronautas, no por inteligencia artificial.',items:[
  rover('Apollo 15','1971'),descent('Falcon · Apollo 15','1971'),reflector('Apollo 15','1971')
 ]},
 // 6: Apollo 15 ALSEP
 {note:'Estos instrumentos investigaban el entorno lunar mientras el equipo humano regresaba a la Tierra.',items:[
  alsep('Apollo 15','1971'),passive('Apollo 15','1971'),
  {name:'Experimento de flujo de calor · Apollo 15',class:'SONDAS TÉRMICAS',status:'Equipo científico dejado en la superficie',year:'1971',art:'heat',
   what:'Instrumentos térmicos que utilizaron sensores introducidos bajo el suelo lunar.',
   purpose:'Medir el calor que emerge desde el interior de la Luna.',
   fate:'Los sensores y componentes de superficie no regresaron con los astronautas.',
   discovery:'Sus mediciones ayudaron a estudiar la evolución térmica de la Luna.',source:NASA_ALSEP}
 ]},
 // 7: Apollo 16 Rover
 {note:'El LRV de Apollo 16 fue manejado por los astronautas John Young y Charles Duke.',items:[
  rover('Apollo 16','1972'),descent('Orion · Apollo 16','1972'),alsep('Apollo 16','1972')
 ]},
 // 8: Apollo 17 Rover
 {note:'Apollo 17 fue la última misión Apolo tripulada que aterrizó en la Luna.',items:[
  rover('Apollo 17','1972'),descent('Challenger · Apollo 17','1972'),alsep('Apollo 17','1972')
 ]}
];
