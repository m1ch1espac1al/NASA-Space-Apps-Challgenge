/* Cosmic Legacy v34 — Apollo 15 Falcon/ALSEP 3D educational reconstruction.
 * Uses the original supplied GLB, with locally generated material-detail maps.
 * It improves shading and visual fidelity but does not fabricate new source topology.
 */

export async function createApollo15Scene(host) {
  const THREE = await import('three');
  const [{GLTFLoader}, {OrbitControls}] = await Promise.all([
    import('three/addons/loaders/GLTFLoader.js'),
    import('three/addons/controls/OrbitControls.js')
  ]);
  const mobile = window.matchMedia('(max-width: 700px)').matches;
  const lowPower = mobile || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);

  const renderer = new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance',depth:true,stencil:false});
  const dpr = Math.min(window.devicePixelRatio || 1, lowPower ? 1.35 : 2);
  renderer.setPixelRatio(dpr);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.10;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x02050b, 1);
  renderer.domElement.setAttribute('aria-label','Recreación 3D de Apollo 15 Falcon y equipo ALSEP. Arrastra para girar la cámara, usa la rueda o el gesto de pellizco para acercar.');
  renderer.domElement.style.touchAction='none';
  host.replaceChildren(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x02050b);
  const camera = new THREE.PerspectiveCamera(mobile ? 42 : 38,1,0.06,210);
  camera.position.set(1.0,4.65,13.6);
  const controls = new OrbitControls(camera,renderer.domElement);
  controls.enableDamping=true;
  controls.dampingFactor=0.065;
  controls.enablePan=false;
  controls.rotateSpeed=0.62;
  controls.zoomSpeed=0.9;
  controls.minDistance=5.8;
  controls.maxDistance=19.5;
  controls.minPolarAngle=0.30;
  controls.maxPolarAngle=1.51;
  controls.target.set(0,1.19,0);
  controls.update();

  const resources=[];
  function track(resource){resources.push(resource);return resource;}
  const loader = new THREE.TextureLoader();
  const anisotropy=Math.min(12,renderer.capabilities.getMaxAnisotropy());
  function localTexture(path,{color=false}={}){
    const tex=track(loader.load(path));
    if(color) tex.colorSpace=THREE.SRGBColorSpace;
    tex.anisotropy=anisotropy;
    return tex;
  }

  // The lunar surface uses the original image maps, viewed edge-on as a curved horizon.
  const moonMap=localTexture('assets/img/moon-map-hd.jpg',{color:true});
  const moonBump=localTexture('assets/img/moon-relief.jpg');
  const moonGeo=track(new THREE.SphereGeometry(18,lowPower?128:192,lowPower?80:128));
  const moonMat=track(new THREE.MeshStandardMaterial({map:moonMap,bumpMap:moonBump,bumpScale:0.095,roughness:1,metalness:0}));
  const moon=new THREE.Mesh(moonGeo,moonMat);
  moon.position.set(0,-17.35,0);
  moon.receiveShadow=true;
  scene.add(moon);

  // Studio environment gives metals believable reflections without making space look bright.
  let envRenderTarget=null, pmrem=null, room=null;
  try {
    const {RoomEnvironment}=await import('three/addons/environments/RoomEnvironment.js');
    pmrem=new THREE.PMREMGenerator(renderer);
    room=new RoomEnvironment(renderer);
    envRenderTarget=pmrem.fromScene(room,0.025);
    scene.environment=envRenderTarget.texture;
    scene.environmentIntensity=0.57;
  } catch (e) {
    console.warn('Apollo: no se cargó el entorno de reflejos; se usará iluminación directa.',e);
  }

  scene.add(new THREE.AmbientLight(0xb6c3d6,.31));
  const skyLight=new THREE.HemisphereLight(0xfaf4e7,0x24202a,.77);
  scene.add(skyLight);
  const sun=new THREE.DirectionalLight(0xfff1d8,3.18);
  sun.position.set(-6.4,9.8,6.2);
  sun.castShadow=true;
  sun.shadow.mapSize.set(lowPower?1024:2048,lowPower?1024:2048);
  sun.shadow.camera.left=-10;sun.shadow.camera.right=10;
  sun.shadow.camera.top=10;sun.shadow.camera.bottom=-10;
  sun.shadow.camera.near=.1;sun.shadow.camera.far=42;
  sun.shadow.bias=-.00032;
  sun.shadow.normalBias=.035;
  sun.shadow.radius=2.2;
  scene.add(sun);
  const bounce=new THREE.DirectionalLight(0x91afd5,.39);bounce.position.set(6,2,4);scene.add(bounce);
  const edge=new THREE.DirectionalLight(0xffd08a,.28);edge.position.set(-4,4,-8);scene.add(edge);

  // The surface is curved; a soft diffuse contact mark prevents floating feet.
  const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=256;
  const sc=shadowCanvas.getContext('2d');const grad=sc.createRadialGradient(128,128,4,128,128,125);
  grad.addColorStop(0,'rgba(0,0,0,.55)');grad.addColorStop(.48,'rgba(0,0,0,.28)');grad.addColorStop(1,'rgba(0,0,0,0)');
  sc.fillStyle=grad;sc.fillRect(0,0,256,256);
  const contactMap=track(new THREE.CanvasTexture(shadowCanvas));
  const shadowGeo=track(new THREE.PlaneGeometry(3.4,2.95));
  const shadowMat=track(new THREE.MeshBasicMaterial({map:contactMap,transparent:true,depthWrite:false,opacity:.37,polygonOffset:true,polygonOffsetFactor:-2}));
  const contact=new THREE.Mesh(shadowGeo,shadowMat);
  contact.rotation.x=-Math.PI/2;contact.position.set(-2.12,.532,.02);contact.renderOrder=2;scene.add(contact);

  const foilNormal=localTexture('assets/img/eagle-pbr-normal.png');
  const foilRoughness=localTexture('assets/img/eagle-pbr-roughness.png');
  foilNormal.wrapS=foilNormal.wrapT=THREE.RepeatWrapping;
  foilRoughness.wrapS=foilRoughness.wrapT=THREE.RepeatWrapping;

  const palettes={
    goldBase:new THREE.Color('#b58433'), goldBright:new THREE.Color('#ebc470'), goldDark:new THREE.Color('#6e5029'),
    bronze:new THREE.Color('#a37543'), copper:new THREE.Color('#906132'),
    white:new THREE.Color('#edf0ef'), silver:new THREE.Color('#afb9c6'), silverShade:new THREE.Color('#66717e'),
    carbon:new THREE.Color('#282c33'), graphite:new THREE.Color('#11151b'), pad:new THREE.Color('#b6bcc5')
  };
  function hash3(x,y,z){
    const t=Math.sin(x*.071+y*.057+z*.041)*43758.5453;
    return t-Math.floor(t);
  }
  function paintGeometry(mesh){
    const geometry=mesh.geometry=mesh.geometry.clone();
    const positions=geometry.getAttribute('position'),normals=geometry.getAttribute('normal');
    if(!positions) return;
    const colors=new Float32Array(positions.count*3), finishes=new Float32Array(positions.count);
    const c=new THREE.Color();
    for(let i=0;i<positions.count;i++){
      const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i);
      const ny=normals?normals.getY(i):0, nz=normals?normals.getZ(i):0;
      const r=Math.hypot(x,z);
      const softly=(Math.sin(x*.029+z*.033+y*.011)*.5+.5);
      const folded=hash3(Math.floor(x/16),Math.floor(y/15),Math.floor(z/17));
      let finish=1;
      if(y < -196){
        // Landing pads: mostly silver alloy with darker lower faces.
        finish=3;c.copy(ny<-.5?palettes.silverShade:palettes.pad);
      } else if(y < -140){
        // Legs and structural members: gold/bronze, steel joints.
        finish=0;c.copy(palettes.goldBright).lerp(palettes.copper,.25+.35*softly);
        if(ny>.82&&folded>.84){finish=3;c.copy(palettes.silver);}
      } else if(y < 90){
        // Gold multilayer thermal insulation (Kapton/Mylar), nonuniform metal sheen.
        finish=0;c.copy(palettes.goldBase).lerp(palettes.goldBright,.18+.49*softly);
        if(folded<.16)c.lerp(palettes.goldDark,.35);
        if(y>25&&r<120&&folded<.08){finish=2;c.copy(palettes.carbon);}
      } else if(y < 132){
        // Dark/gray separation collar between ascent and descent stages.
        finish=2;c.copy(palettes.carbon).lerp(palettes.silverShade,.28+.22*softly);
      } else if(y < 305){
        // Faceted aluminum ascent cabin, silver fabric and charcoal thermal panels.
        finish=1;c.copy(palettes.silver).lerp(palettes.white,.2+.45*softly);
        if(ny<-.65)c.lerp(palettes.silverShade,.48);
        // Dark thermal blankets and window zones, concentrated on forward cabin.
        if((Math.abs(x)>164 && y>140 && y<263 && softly<.67) ||
           (nz<-.32 && y>177 && y<245 && Math.abs(x)<155 && folded<.30) ||
           (ny<-.42 && softly<.24)){
           finish=2;c.copy(palettes.graphite).lerp(palettes.carbon,.20+.25*softly);
        }
      } else {
        // Dish and upper antenna fittings.
        finish=1;c.copy(palettes.silver).lerp(palettes.white,.35+.4*softly);
        if(folded<.13)c.lerp(palettes.silverShade,.3);
      }
      colors[3*i]=c.r;colors[3*i+1]=c.g;colors[3*i+2]=c.b;
      finishes[i]=finish;
    }
    geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));
    geometry.setAttribute('apolloFinish',new THREE.BufferAttribute(finishes,1));
    track(geometry);

    const mat=track(new THREE.MeshPhysicalMaterial({
      vertexColors:true,
      color:0xffffff,
      metalness:.61,
      roughness:.47,
      normalMap:foilNormal,
      normalScale:new THREE.Vector2(.29,.29),
      roughnessMap:foilRoughness,
      clearcoat:.07,
      clearcoatRoughness:.31,
      side:THREE.DoubleSide,
      envMapIntensity:.92
    }));
    // Per-surface metal and roughness, not one constant finish for the entire craft.
    mat.onBeforeCompile=(shader)=>{
      shader.vertexShader=shader.vertexShader.replace('#include <common>',
        '#include <common>\nattribute float apolloFinish;\nvarying float vApolloFinish;');
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',
        '#include <begin_vertex>\nvApolloFinish=apolloFinish;');
      shader.fragmentShader=shader.fragmentShader.replace('#include <common>',
        '#include <common>\nvarying float vApolloFinish;');
      shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',
        '#include <roughnessmap_fragment>\nroughnessFactor=clamp(roughnessFactor * (vApolloFinish<.50 ? .92 : (vApolloFinish<1.50 ? 1.35 : (vApolloFinish<2.50 ? 2.5 : 1.52))),0.22,0.98);');
      shader.fragmentShader=shader.fragmentShader.replace('#include <metalnessmap_fragment>',
        '#include <metalnessmap_fragment>\nmetalnessFactor=clamp((vApolloFinish<.50 ? 1.3 : (vApolloFinish<1.50 ? 1.0 : (vApolloFinish<2.50 ? .23 : .85))) * metalnessFactor,0.03,0.95);');
    };
    mat.customProgramCacheKey=()=> 'apollo15-finish-v34';
    mesh.material=mat;
    mesh.castShadow=true;
    mesh.receiveShadow=true;
    mesh.frustumCulled=true;
  }

  // Apollo 15 Falcon represented with the available Apollo 11 LM geometry (shared LM family).
  // It is an educational approximation, not an exact Apollo 15 engineering model.
  // Center and ground the original model using measured bounds.
  const modelAnchor=new THREE.Group();modelAnchor.position.set(-2.12,.54,.08);scene.add(modelAnchor);
  const gltf=new GLTFLoader();
  let modelLoaded=false, modelLoadError=false;
  let dead=false;
  const loadPromise=new Promise(resolve=>{
    gltf.load('assets/models/apollo11-eagle.glb',(result)=>{
      if(dead){resolve();return;}
      const root=result.scene;
      root.traverse(child=>{if(child.isMesh)paintGeometry(child);});
      const unscaled=new THREE.Box3().setFromObject(root);
      const size=unscaled.getSize(new THREE.Vector3());
      const center=unscaled.getCenter(new THREE.Vector3());
      const scale=2.85/(Math.max(size.x,size.y,size.z)||1);
      root.scale.multiplyScalar(scale);
      root.position.sub(center.multiplyScalar(scale));
      root.updateMatrixWorld(true);
      const grounded=new THREE.Box3().setFromObject(root);
      root.position.y-=grounded.min.y;
      modelAnchor.add(root);
      modelLoaded=true;
      resolve();
    },undefined,e=>{console.error('Apollo 15 approximation: base GLB not loaded',e);modelLoadError=true;resolve();});
  });

  // Apollo 15 ALSEP: procedural educational approximations, NOT a 3D scan.
  // Based on documented types: passive seismic experiment, heat flow probes,
  // magnetometer, solar wind spectrometer and central station/antenna.
  const ALSEP=new THREE.Group();scene.add(ALSEP);
  const mkMaterial=(color,metalness=.2,roughness=.67)=>track(new THREE.MeshStandardMaterial({color,metalness,roughness}));
  const metal=mkMaterial(0xc5cbd2,.69,.38),light=mkMaterial(0xe1e3e5,.28,.55),grey=mkMaterial(0x6e7882,.55,.49);
  const gold=mkMaterial(0xb88a3b,.67,.43),dark=mkMaterial(0x28333d,.16,.78),insulator=mkMaterial(0x9b8a67,.17,.9);
  const black=mkMaterial(0x111920,.03,.93),blue=mkMaterial(0x2c566c,.17,.52);
  function mesh(geo,mat,parent=ALSEP){
    const m=new THREE.Mesh(track(geo),mat);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
  }
  function tube(a,b,r,mat,parent=ALSEP){
    const d=new THREE.Vector3().subVectors(new THREE.Vector3(...b),new THREE.Vector3(...a));
    const c=mesh(new THREE.CylinderGeometry(r,r,d.length(),9),mat,parent);
    c.position.copy(new THREE.Vector3(...a)).add(new THREE.Vector3(...b)).multiplyScalar(.5);
    c.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.clone().normalize());return c;
  }
  function lunarGround(x,z){return -17.35+Math.sqrt(Math.max(1,18*18-x*x-z*z));}
  function box(x,y,z,w,h,d,mat){const m=mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);return m;}
  function foot(x,z,size=.32){
    const y=lunarGround(x,z);
    const f=mesh(new THREE.CylinderGeometry(size,size*.9,.035,16),metal);f.position.set(x,y+.026,z);return y;
  }
  // Main ALSEP central station: standing rectangular equipment box and solar panels.
  const sx=1.72,sz=-.1,sy=lunarGround(sx,sz);
  box(sx,sy+.44,sz,.82,.62,.45,light);
  box(sx,sy+.75,sz,.87,.05,.5,dark);
  const panel=box(sx,sy+.46,sz+.245,.71,.32,.027,blue);
  for(let i=-2;i<=2;i++){box(sx+i*.112,sy+.46,sz+.267,.025,.23,.012,metal);}
  for(const dx of [-.34,.34])for(const dz of [-.17,.17])tube([sx+dx,sy+.13,sz+dz],[sx+dx,sy+.38,sz+dz],.018,metal);
  // Standalone passive seismometer: ribbed grey drum on tripod.
  const qx=.48,qz=.35,qy=lunarGround(qx,qz);
  const drum=mesh(new THREE.CylinderGeometry(.27,.27,.49,28),grey);drum.rotation.z=Math.PI/2;drum.position.set(qx,qy+.34,qz);
  for(let i=-3;i<=3;i++){const ring=mesh(new THREE.TorusGeometry(.272,.015,6,36),light);ring.rotation.y=Math.PI/2;ring.position.set(qx+i*.065,qy+.34,qz);}
  for(const dz of [-.18,.18])tube([qx-.22,qy+.17,qz+dz],[qx-.40,qy+.04,qz+dz*1.5],.025,metal);
  // L-shaped long mast with communication antenna: bowl plus pole/hinge.
  const ax=3.08,az=-.28,ay=lunarGround(ax,az);
  tube([ax,ay+.02,az],[ax,ay+1.65,az],.035,metal);
  const antenna=mesh(new THREE.SphereGeometry(.36,24,12,0,Math.PI*2,0,Math.PI*.48),light);
  antenna.position.set(ax,ay+1.52,az);antenna.rotation.x=.24;
  tube([ax,ay+1.53,az],[ax,ay+1.68,az+.12],.014,dark);
  // Solar-wind sensor / magnetometer tripod on right.
  const mx=4.12,mz=.16,my=lunarGround(mx,mz);
  const magnet=box(mx,my+.83,mz,.17,.20,.17,dark);
  for(let i=0;i<3;i++){const a=i*2*Math.PI/3;
    tube([mx,my+.8,mz],[mx+Math.cos(a)*.6,my+.04,mz+Math.sin(a)*.6],.022,metal);
  }
  tube([mx,my+.93,mz],[mx,my+1.2,mz],.022,metal);
  box(mx,my+1.25,mz,.24,.18,.24,grey);
  // Heat flow electronics and probes, represented as adjacent boxes and columns.
  const hx=2.78,hz=1.15,hy=lunarGround(hx,hz);
  box(hx,hy+.25,hz,.52,.38,.46,insulator);
  box(hx,hy+.46,hz,.48,.055,.43,gold);
  for(const dx of [-.35,.36]){
    const px=hx+dx,pz=hz+.42,py=lunarGround(px,pz);
    tube([px,py+.035,pz],[px,py+.70,pz],.021,metal);
  }
  // Fine dark leads, laid on the lunar ground from each instrument to station.
  function cable(coords){
    const pts=coords.map(([x,z])=>new THREE.Vector3(x,lunarGround(x,z)+.035,z));
    const curve=new THREE.CatmullRomCurve3(pts);
    mesh(new THREE.TubeGeometry(curve,22,.014,5,false),black);
  }
  cable([[qx+.25,qz],[1.0,.35],[1.27,.14],[sx,sz]]);
  cable([[sx,sz],[2.1,.42],[hx,hz]]);
  cable([[sx,sz],[2.35,-.24],[ax,az]]);
  cable([[sx,sz],[3.0,-.26],[3.65,-.05],[mx,mz]]);
  // Grounding: softly shaded pads help the independent equipment sit on the Moon.
  for(const [x,z,r] of [[sx,sz,.64],[qx,qz,.45],[ax,az,.28],[mx,mz,.40],[hx,hz,.36]]){
    const shade=mesh(new THREE.CircleGeometry(r,32),track(new THREE.MeshBasicMaterial({color:0x08080a,transparent:true,opacity:.19,depthWrite:false})));
    shade.rotation.x=-Math.PI/2;shade.position.set(x,lunarGround(x,z)+.008,z);
  }

  // Background points kept subtle so the craft and horizon remain the subjects.
  const count=lowPower?230:460;
  const coords=new Float32Array(count*3);
  let seed=1971;
  const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  for(let i=0;i<count;i++){
    const a=rand()*Math.PI*2,b=rand()*Math.PI*2,r=70+rand()*60;
    coords[3*i]=r*Math.sin(b)*Math.cos(a);
    coords[3*i+1]=r*Math.cos(b);
    coords[3*i+2]=r*Math.sin(b)*Math.sin(a);
  }
  const starGeo=track(new THREE.BufferGeometry());starGeo.setAttribute('position',new THREE.BufferAttribute(coords,3));
  const starMat=track(new THREE.PointsMaterial({color:0xd5e4fa,size:lowPower?.14:.10,sizeAttenuation:true,transparent:true,opacity:.7,depthWrite:false}));
  scene.add(new THREE.Points(starGeo,starMat));

  let frame=0,dirty=true,lastDraw=0;
  function resize(){
    if(dead)return;
    const w=Math.max(2,host.clientWidth),h=Math.max(2,host.clientHeight);
    camera.aspect=w/h;
    camera.updateProjectionMatrix();
    renderer.setSize(w,h,false);
    dirty=true;
  }
  const observer=typeof ResizeObserver==='function'?new ResizeObserver(resize):null;
  observer?.observe(host);
  resize();
  function tick(ts){
    if(dead)return;
    frame=requestAnimationFrame(tick);
    if(document.hidden||host.getBoundingClientRect().width<4) return;
    if(!host.isConnected) return;
    // Higher perceived clarity without wasting cycles on hidden scene rendering.
    if(lowPower && ts-lastDraw<25) return;
    lastDraw=ts;
    controls.update();
    renderer.render(scene,camera);
    dirty=false;
  }
  frame=requestAnimationFrame(tick);

  return {
    show(){resize();},
    isLoaded(){return modelLoaded&&!modelLoadError;},
    loading:loadPromise,
    destroy(){
      dead=true;cancelAnimationFrame(frame);
      observer?.disconnect();controls.dispose();
      for(const r of resources){try{r.dispose?.();}catch(_){}}
      envRenderTarget?.dispose();pmrem?.dispose();room?.dispose();
      renderer.dispose();renderer.forceContextLoss?.();
      if(renderer.domElement.isConnected) renderer.domElement.remove();
    }
  };
}
