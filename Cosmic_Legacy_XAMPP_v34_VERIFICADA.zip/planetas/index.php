<?php // Cosmic Legacy · prototipo visual educativo · Apache / XAMPP ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#020612"><meta name="description" content="Una experiencia espacial: Tierra, Luna y Marte en movimiento, con sus distancias y sus historias.">
<title>Cosmic Legacy — Abandonados pero no olvidados</title>
<link rel="stylesheet" href="assets/css/style.css?v=17">
<link rel="stylesheet" href="assets/css/fixes-v15.css?v=17">
<link rel="stylesheet" href="assets/css/v17.css?v=18">
<link rel="stylesheet" href="assets/css/v18.css?v=18">
<link rel="stylesheet" href="assets/css/v19.css?v=19">
<link rel="stylesheet" href="assets/css/v20.css?v=20">
<link rel="stylesheet" href="assets/css/v21.css?v=21">
<link rel="stylesheet" href="assets/css/v22.css?v=23">
<link rel="stylesheet" href="assets/css/v23.css?v=23">
<link rel="stylesheet" href="assets/css/v24.css?v=24">
<link rel="stylesheet" href="assets/css/v26.css?v=26">
<link rel="stylesheet" href="assets/css/v27.css?v=27">
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.1/examples/jsm/"}}</script>
</head>
<body>
<div id="sky" aria-hidden="true"></div><canvas id="star-canvas" aria-hidden="true"></canvas>
<div class="ambient ambient-blue" aria-hidden="true"></div><div class="ambient ambient-purple" aria-hidden="true"></div>
<canvas id="effects-canvas" aria-hidden="true"></canvas>
<main id="app">
 <header class="topbar">
  <a class="brand" href="#inicio" aria-label="Cosmic Legacy, inicio"><span class="brand-icon"><img src="assets/img/cosmic-mark.svg" alt="" aria-hidden="true"></span><span class="brand-name">COSMIC<span>LEGACY</span></span></a>
  <span class="nav-split"></span><span class="small-header" data-i18n="site.tagline">ECOS DE LA EXPLORACIÓN</span>
  <nav class="navigation" aria-label="Menú principal"><a href="#inicio" class="active" data-i18n="nav.explore">Explorar</a><button id="nav-missions" data-i18n="nav.missions">Misiones</button><a href="realidad-virtual.php" id="nav-vr"><span data-i18n="nav.vr">Realidad virtual</span> <span aria-hidden="true">✧</span></a><button id="nav-about" data-i18n="nav.about">Acerca de</button></nav>
  <div class="lang-switch" role="group" aria-label="Idioma / Language"><button type="button" data-lang="es" aria-pressed="true" aria-label="Español" title="Español">ES</button><button type="button" data-lang="en" aria-pressed="false" aria-label="English" title="English">EN</button></div>
  <button id="mobile-menu" class="mobile-menu" aria-label="Mostrar menú" aria-expanded="false">☰</button>
 </header>
 <button id="explore-back" class="explore-back" type="button" hidden aria-label="Regresar a la vista general"><span aria-hidden="true">←</span> <span data-i18n="nav.back">REGRESAR</span></button>
 <section class="space-scene" id="inicio" aria-label="Escena con órbita compartida interactiva: Tierra y Marte con sus satélites">
  <div id="universe" aria-hidden="true"></div>
  <div id="planet-fallback"><div class="fallback-shared-guide" aria-hidden="true"></div><button class="fallback-planet earth-img" data-planet="earth" aria-label="Seleccionar Tierra"></button><button class="fallback-planet moon-img" data-planet="moon" aria-label="Seleccionar Luna"></button><button class="fallback-planet mars-img" data-planet="mars" aria-label="Seleccionar Marte"></button>
  <div class="fallback-mars-orbits" aria-hidden="true"><div class="fallback-orbit orbit-p"><span class="fallback-satellite"><b></b><small>FOBOS</small></span></div><div class="fallback-orbit orbit-d"><span class="fallback-satellite"><b></b><small>DEIMOS</small></span></div></div></div>
    <div id="menu-zoom" class="menu-zoom" role="group" aria-label="Tamaño de los planetas">
    <span class="menu-zoom-caption" data-i18n="zoom.title">TAMAÑO DE LOS MUNDOS</span>
    <div class="menu-zoom-actions">
      <button id="zoom-minus" type="button" aria-label="Reducir tamaño de planetas" title="Reducir tamaño">−</button>
      <output id="zoom-value" for="zoom-minus zoom-plus" aria-live="polite">100%</output>
      <button id="zoom-plus" type="button" aria-label="Aumentar tamaño de planetas" title="Aumentar tamaño">+</button>
    </div>
  </div>
  <svg id="callout-lines" aria-hidden="true"><path id="callout-path"></path><circle id="callout-node" r="3"></circle></svg>
  <article id="planet-callout" class="planet-callout" aria-live="polite" hidden>
    <div class="callout-top"><span id="callout-type">PLANETA</span><span class="callout-spark">✧</span></div>
    <h2 id="callout-title">La Tierra</h2><p id="callout-desc"></p>
    <button id="callout-story"><span id="callout-action-text">CONOCER SU HISTORIA</span> <span>↗</span></button>
  </article>
  <aside id="moon-controls" class="moon-controls" hidden aria-label="Lunas de Marte"><div class="moons-head" data-i18n="moon.satellites">SATÉLITES NATURALES DE MARTE</div><button type="button" data-mars-moon="phobos">◉ FOBOS <small>22.2 km · 7 h 39 min</small></button><button type="button" data-mars-moon="deimos">◉ DEIMOS <small>12.6 km · 30 h 21 min</small></button><p id="moon-info" aria-live="polite">Selecciona una luna o arrástrala para girarla.</p></aside>
  <div id="planet-markers" class="planet-markers" aria-hidden="true"><span data-marker="earth" data-i18n="planet.earth.name">TIERRA</span><span data-marker="moon" data-i18n="planet.moon.name">LUNA</span><span data-marker="mars" data-i18n="planet.mars.name">MARTE</span><span class="mars-satellite-label" data-marker="phobos">FOBOS</span><span class="mars-satellite-label" data-marker="deimos">DEIMOS</span></div>
 </section>
 <section class="hero-copy"><h1><span data-i18n="hero.title1">ABANDONADOS</span> <em data-i18n="hero.title2">PERO NO OLVIDADOS</em></h1><p data-i18n-html="hero.subtitle">Las misiones terminan. Sus historias permanecen.<br>Descubre los mundos que transformaron nuestra forma de explorar.</p></section>
 <aside class="distance-panel" aria-label="Distancias astronómicas aproximadas">
  <span class="distance-label" data-i18n="distance.title">DISTANCIAS DESDE LA TIERRA</span>
  <div class="distance-row"><span class="distance-icon">◐</span><span class="distance-caption"><span data-i18n="planet.moon.name">LUNA</span><small data-i18n="distance.average">distancia media</small></span><strong>384,400 <small>km</small></strong></div>
  <div class="distance-rule"></div>
  <div class="distance-row"><span class="distance-icon red">●</span><span class="distance-caption"><span data-i18n="planet.mars.name">MARTE</span><small data-i18n="distance.variable">distancia variable</small></span><strong>54.6–401.4 <small>M km</small></strong></div>
  <div class="distance-rule"></div>
  <div class="distance-row"><span class="distance-icon moon-to-mars-icon">◐ ↔ ●</span><span class="distance-caption"><span data-i18n="distance.moonmars">LUNA–MARTE</span><small data-i18n="distance.estimated">rango aproximado</small></span><strong>≈54–402 <small>M km</small></strong></div>
  <p class="distance-clarification" data-i18n="distance.note">Luna–Marte: estimación orientativa a partir de las distancias Tierra–Marte y Tierra–Luna; cambia continuamente.</p>
  <span class="distance-sources"><a href="https://science.nasa.gov/moon/by-the-numbers/" target="_blank" rel="noopener noreferrer" class="distance-source">NASA · Luna ↗</a><a href="https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html" target="_blank" rel="noopener noreferrer" class="distance-source">NASA · Marte ↗</a></span>
 </aside>
 <aside id="explore-panel" class="explore-panel" hidden aria-label="Misiones y objetos espaciales">
  <div class="explore-panel-heading"><span id="explore-kicker" class="explore-kicker">ARCHIVO DE EXPLORACIÓN</span><h2 id="explore-title">Misiones</h2><p id="explore-summary"></p><p class="rotate-hint"><span aria-hidden="true">⟳</span> <span data-i18n="explore.drag">GIRA EL PLANETA 360° ARRASTRANDO</span></p><p id="rotation-countdown" class="rotation-countdown" aria-live="off">ROTACIÓN AUTOMÁTICA · ARRASTRA PARA EXPLORAR</p></div>
  <div class="explore-list-heading"><span id="explore-count">0 ELEMENTOS</span><span data-i18n="explore.choose">SELECCIONA UNO ↓</span></div>
  <div id="explore-list" class="explore-list" role="group" aria-label="Lista de misiones"></div>
  <article id="explore-detail" class="explore-detail" aria-live="polite">
    <span id="explore-detail-type" class="explore-detail-type">MISIÓN</span>
    <h3 id="explore-detail-title"></h3>
    <p id="explore-detail-desc"></p>
    <a id="explore-detail-source" target="_blank" rel="noopener noreferrer" href="https://science.nasa.gov/" data-i18n="explore.source">FUENTE OFICIAL NASA ↗</a>
  </article>
 </aside>
 <div class="bottom-hint"><span class="autospin-dot"></span> <span data-i18n="hint.rotation">UNA ÓRBITA EN 3D · ARRASTRA PARA INCLINARLA</span> <span class="hint-dot">✦</span> <span data-i18n="hint.select">SELECCIONA UN MUNDO PARA CONOCERLO</span></div>
 <div class="credit" data-i18n="site.disclaimer">RECORRIDO ORBITAL ILUSTRATIVO · DISTANCIAS NO A ESCALA · NO AFILIADO A NASA</div>
 <div class="team-credit"><span class="team-label" data-i18n="site.team">EQUIPO</span> · Estefanía · Fernanda · Ieshua Gabriel · Jocabeth · Jehieli · Lisset</div>
</main>
<div class="modal-layer" id="modal-layer" hidden><div class="modal-backdrop" data-close="true"></div><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button id="close-modal" class="modal-close" aria-label="Cerrar">×</button><span id="modal-kicker" class="modal-kicker">ARCHIVO COSMIC LEGACY</span><h2 id="modal-title"></h2><p id="modal-body"></p><div id="modal-extra"></div><button class="modal-ok" id="modal-ok" data-i18n="modal.return">VOLVER AL UNIVERSO ↗</button></section></div>
<script src="assets/js/i18n.js?v=27" defer></script>
<script type="module" src="assets/js/app.js?v=27"></script>
</body></html>
