// Cosmic Legacy — escena espacial automática, con selección sin detener rotaciones.
const $ = id => document.getElementById(id);
const data = {
 earth:{title:'La Tierra',type:'NUESTRO PLANETA',intro:'Nuestro hogar: un mundo de océanos, continentes y vida. Desde aquí comenzaron las grandes misiones espaciales.',story:'La Tierra es el punto de partida de las misiones que llegaron a la Luna y a Marte. Observarla desde el espacio también transformó nuestra comprensión del clima, los océanos y la atmósfera.',facts:['Tercer planeta desde el Sol.','Único mundo conocido que alberga vida.','Origen de las misiones Apolo y de los vehículos que exploraron Marte.']},
 moon:{title:'La Luna',type:'SATÉLITE NATURAL',intro:'Nuestro satélite conserva huellas, instrumentos y vehículos de las históricas misiones Apolo.',story:'En la superficie lunar aún permanecen instrumentos y vehículos de las misiones Apolo. Sus trayectorias, imágenes y experimentos ayudan a contar la historia de los primeros exploradores humanos de otro mundo.',facts:['Distancia media a la Tierra: 384,400 km.','Apollo 11 realizó el primer alunizaje humano en 1969.','Los vehículos de las misiones Apolo 15, 16 y 17 permanecen allí.']},
 mars:{title:'Marte',type:'EL PLANETA ROJO',intro:'Un mundo desértico donde antiguos exploradores robóticos dejaron descubrimientos y un legado extraordinario.',story:'Sojourner, Spirit, Opportunity, InSight e Ingenuity son ejemplos de equipos que hicieron historia en Marte. Sus datos aportaron pistas sobre su geología, su pasado con agua y las posibilidades del vuelo robótico.',facts:['La distancia a la Tierra cambia durante las órbitas.','Opportunity trabajó en Marte entre 2004 y 2018.','Ingenuity realizó el primer vuelo propulsado y controlado en otro planeta en 2021.']}
};
let selected=null, sceneControl=null;
const path=$('callout-path'),node=$('callout-node'),card=$('planet-callout');
let currentBox=null, currentNode=null, cardVersion=0;
function openModal(title,body,facts=[],kicker='ARCHIVO COSMIC LEGACY'){
 $('modal-title').textContent=title;$('modal-body').textContent=body;$('modal-kicker').textContent=kicker;
 const ex=$('modal-extra');ex.replaceChildren();if(facts.length){let ul=document.createElement('ul');for(const fact of facts){const li=document.createElement('li');li.textContent=fact;ul.append(li)}ex.append(ul)}
 $('modal-layer').hidden=false;$('close-modal').focus();
}
function closeModal(){$('modal-layer').hidden=true;}
$('close-modal').addEventListener('click',closeModal);$('modal-ok').addEventListener('click',closeModal);document.querySelector('[data-close]').addEventListener('click',closeModal);
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
function story(key=selected||'earth'){const d=data[key];openModal(d.title+': una historia que permanece',d.story,d.facts,'HISTORIAS DE LA EXPLORACIÓN');}
$('start-btn').addEventListener('click',()=>story());$('callout-story').addEventListener('click',()=>story());
$('nav-stories').addEventListener('click',()=>openModal('Historias que permanecen','Los equipos que llegaron a la Luna y Marte son testigos de grandes logros científicos. Escoge un cuerpo para conocer algunas de sus historias.', ['Luna: vehículos de las misiones Apolo.','Marte: Sojourner, Opportunity, InSight e Ingenuity.'],'NARRATIVAS ESPACIALES'));
$('nav-missions').addEventListener('click',()=>openModal('Misiones y descubrimientos','Exploramos cómo se diseñaron las misiones, qué instrumentos llevaron y qué contribuciones realizaron a la ciencia.', ['Apolo: exploración humana de la superficie lunar.','Opportunity: geología y evidencias de agua antigua en Marte.','Ingenuity: demostración de vuelo robótico en Marte.'],'EXPLORACIÓN NASA'));
$('nav-about').addEventListener('click',()=>openModal('Acerca de Cosmic Legacy','Proyecto educativo inspirado en el desafío “Abandoned but not Forgotten” de NASA Space Apps Challenge. Modelos y distancias visuales no están a escala. No es una web oficial ni está afiliada a NASA.', ['Los tres cuerpos giran automáticamente y a la vez.','Seleccionar un mundo revela una ficha informativa animada.','Distancia lunar media: NASA Science. Distancia a Marte: NASA Moon to Mars Architecture.'],'ACERCA DEL PROYECTO'));
$('mobile-menu').addEventListener('click',()=>{const open=document.querySelector('.navigation').classList.toggle('open');$('mobile-menu').setAttribute('aria-expanded',String(open))});
document.querySelectorAll('.navigation button').forEach(b=>b.addEventListener('click',()=>document.querySelector('.navigation').classList.remove('open')));
function selectPlanet(key){
 if(!data[key])return;
 const d=data[key];selected=key;cardVersion++;
 $('callout-title').textContent=d.title;$('callout-type').textContent=d.type;$('callout-desc').textContent=d.intro;
 document.querySelectorAll('[data-select]').forEach(b=>{b.classList.toggle('selected',b.dataset.select===key);b.setAttribute('aria-pressed',String(b.dataset.select===key))});
 card.hidden=false;card.classList.remove('callout-visible');path.classList.remove('drawn');node.classList.remove('node-visible');
 const token=cardVersion;
 sceneControl?.select?.(key);
 // Reiniciar únicamente la animación de la tarjeta, nunca la rotación de los modelos.
 requestAnimationFrame(()=>{if(token!==cardVersion)return;positionCard();requestAnimationFrame(()=>{if(token!==cardVersion)return;path.classList.add('drawn');node.classList.add('node-visible');card.classList.add('callout-visible')})});
}
document.querySelectorAll('[data-select]').forEach(b=>b.addEventListener('click',()=>selectPlanet(b.dataset.select)));
document.querySelectorAll('[data-planet]').forEach(b=>b.addEventListener('click',()=>selectPlanet(b.dataset.planet)));
function screenFallback(key){const ref=document.querySelector('.fallback-planet[data-planet="'+key+'"]');const a=ref?.getBoundingClientRect();if(!a)return null;return {x:a.left+a.width/2,y:a.top+a.height/2,r:a.width*.45};}
function positionCard(){
 if(!selected||card.hidden)return;
 const viewport=$('app').getBoundingClientRect(),target=sceneControl?.project?.(selected)||screenFallback(selected);if(!target)return;
 const x=target.x-viewport.left,y=target.y-viewport.top;
 const w=card.offsetWidth||225,h=card.offsetHeight||150;
 const isMobile=window.innerWidth<=650;
 const positions={moon:{dx:1,dy:-.30},earth:{dx:1,dy:-.78},mars:{dx:-1,dy:.18}};
 const p=positions[selected];
 let bx=x+(p.dx===1?target.r+18:-target.r-w-18);
 let by=y+target.r*p.dy-h*(p.dy<0?.55:.28);
 // El rectángulo no invade la cabecera ni los textos inferiores.
 const maxBottom=isMobile?Math.max(250,viewport.height*.73):viewport.height*.70;
 bx=Math.max(12,Math.min(viewport.width-w-12,bx));by=Math.max(isMobile?84:100,Math.min(maxBottom-h,by));
 card.style.left=bx+'px';card.style.top=by+'px';
 const cx=p.dx===1?bx:bx+w,cy=Math.min(by+h-14,Math.max(by+14,y));
 const sx=x+(p.dx===1?1:-1)*target.r*.73,sy=y+target.r*(p.dy<0?-.45:.16);
 const ex=cx,ey=cy,midX=sx+(ex-sx)*.47;
 path.setAttribute('d',`M ${sx.toFixed(1)} ${sy.toFixed(1)} L ${midX.toFixed(1)} ${ey.toFixed(1)} L ${ex.toFixed(1)} ${ey.toFixed(1)}`);
 path.style.strokeDasharray='700';path.style.strokeDashoffset=path.classList.contains('drawn')?'0':'700';
 node.setAttribute('cx',sx);node.setAttribute('cy',sy);
 currentBox={x:bx,y:by};currentNode={x,y};
}
// Canvas estelar: cada estrella tiene un ritmo propio de centelleo.
const starCanvas=$('star-canvas'),ctx=starCanvas.getContext('2d');
let W=1,H=1,DPR=1,stars=[],meteors=[],lastFrame=0,meteorCycle=0;
function random(a,b){return a+Math.random()*(b-a)}
function resizeStars(){
 W=innerWidth;H=innerHeight;DPR=Math.min(devicePixelRatio||1,2);starCanvas.width=Math.floor(W*DPR);starCanvas.height=Math.floor(H*DPR);
 starCanvas.style.width=W+'px';starCanvas.style.height=H+'px';ctx.setTransform(DPR,0,0,DPR,0,0);
 const count=Math.min(850,Math.round(W*H/2200));stars=Array.from({length:count},()=>({x:Math.random()*W,y:Math.random()*H,r:random(.24,1.55),base:random(.20,.78),phase:random(0,Math.PI*2),speed:random(.0007,.0037),spark:Math.random()<.12}));
}
function spawnThreeMeteors(){
 // Cada 5 segundos aparece un grupo nuevo formado por exactamente tres estrellas fugaces.
 for(let i=0;i<3;i++){
  meteors.push({start:performance.now()+i*260,x:random(-W*.15,W*.83),y:random(35,H*.4),vx:random(5,9),vy:random(2.2,5.1),duration:random(690,1100),length:random(90,175),weight:random(1.2,2.3)});
 }
}
function drawSky(now){
 ctx.clearRect(0,0,W,H);
 for(const s of stars){const f=(.65+.35*Math.sin(now*s.speed+s.phase));const alpha=s.base*f;
  ctx.fillStyle=`rgba(219,236,255,${alpha})`;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();
  if(s.spark&&f>.86){const l=s.r*4.5;ctx.strokeStyle=`rgba(173,217,255,${(f-.75)*.62})`;ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(s.x-l,s.y);ctx.lineTo(s.x+l,s.y);ctx.moveTo(s.x,s.y-l);ctx.lineTo(s.x,s.y+l);ctx.stroke();}
 }
 if(meteorCycle===0)meteorCycle=now;
 if(now-meteorCycle>=5000){const steps=Math.floor((now-meteorCycle)/5000);meteorCycle+=steps*5000;spawnThreeMeteors();}
 for(let i=meteors.length-1;i>=0;i--){const m=meteors[i],t=now-m.start;if(t<0)continue;if(t>m.duration){meteors.splice(i,1);continue;}
  const tNorm=t/m.duration,fade=Math.sin(Math.PI*tNorm),px=m.x+m.vx*t/16,py=m.y+m.vy*t/16;
  const norm=Math.hypot(m.vx,m.vy),tx=px-m.vx/norm*m.length,ty=py-m.vy/norm*m.length;
  const glow=ctx.createLinearGradient(tx,ty,px,py);glow.addColorStop(0,'rgba(121,180,255,0)');glow.addColorStop(.7,`rgba(143,200,255,${.30*fade})`);glow.addColorStop(1,`rgba(246,251,255,${fade})`);
  ctx.strokeStyle=glow;ctx.lineWidth=m.weight;ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(px,py);ctx.stroke();
  ctx.fillStyle=`rgba(241,251,255,${fade})`;ctx.beginPath();ctx.arc(px,py,1.5,0,Math.PI*2);ctx.fill();
 }
 lastFrame=now;requestAnimationFrame(drawSky);
}
addEventListener('resize',()=>{resizeStars();positionCard()});resizeStars();requestAnimationFrame(drawSky);
// Three.js: modelos de alta geometría con mapas incluidos (sin descargas de texturas en ejecución).
(async()=>{
 try{
  const THREE=await import('https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js');
  const host=$('universe'),scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(43,1,.1,1000);camera.position.set(0,0,15.5);
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.37;host.append(renderer.domElement);
  const loader=new THREE.TextureLoader();
  function texture(name,colors=true){const t=loader.load('assets/img/'+name);if(colors)t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),16);return t;}
  const maps={earth:texture('earth-map.jpg'),moon:texture('moon-map.jpg'),mars:texture('mars-map.jpg'),clouds:texture('earth-clouds.png'),moonBump:texture('moon-relief.jpg',false),marsBump:texture('mars-relief.jpg',false),earthBump:texture('earth-relief.jpg',false)};
  scene.add(new THREE.AmbientLight(0x9baac8,.37));
  const light=new THREE.DirectionalLight(0xffead4,3.25);light.position.set(-8,5,12);scene.add(light);
  const fill=new THREE.DirectionalLight(0x538acc,.33);fill.position.set(6,-3,-7);scene.add(fill);
  function planet(radius,color,bump,bumpScale){return new THREE.Mesh(new THREE.SphereGeometry(radius,128,96),new THREE.MeshStandardMaterial({map:color,bumpMap:bump,bumpScale,roughness:.96,metalness:0}));}
  const earth=planet(2.7,maps.earth,maps.earthBump,.028);earth.position.set(0,.45,0);earth.rotation.y=-1.55;earth.rotation.z=.07;scene.add(earth);
  const clouds=new THREE.Mesh(new THREE.SphereGeometry(2.725,128,96),new THREE.MeshStandardMaterial({map:maps.clouds,transparent:true,depthWrite:false,opacity:.76,roughness:1,side:THREE.DoubleSide}));earth.add(clouds);
  const moon=planet(1.03,maps.moon,maps.moonBump,.095);moon.position.set(-5.35,.52,-1.1);moon.rotation.y=-.55;scene.add(moon);
  const mars=planet(1.13,maps.mars,maps.marsBump,.068);mars.position.set(5.85,1.8,-5.5);mars.rotation.y=.5;scene.add(mars);
  // Halo atmosférico de la Tierra, calculado a partir del ángulo de visión.
  const atmos=new THREE.Mesh(new THREE.SphereGeometry(2.77,96,64),new THREE.ShaderMaterial({vertexShader:'varying vec3 n;varying vec3 v;void main(){n=normalize(normalMatrix*normal);vec4 p=modelViewMatrix*vec4(position,1.0);v=normalize(-p.xyz);gl_Position=projectionMatrix*p;}',fragmentShader:'varying vec3 n;varying vec3 v;void main(){float a=pow(1.0-max(0.0,dot(normalize(n),normalize(v))),4.5);gl_FragColor=vec4(.20,.54,1.0,a*.56);}',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}));earth.add(atmos);
  // Sol remoto: superficie emisiva, resplandor de corona y luz local.
  const solarCanvas=document.createElement('canvas');solarCanvas.width=solarCanvas.height=256;const solarCtx=solarCanvas.getContext('2d');let grad=solarCtx.createRadialGradient(128,128,12,128,128,128);grad.addColorStop(0,'rgba(255,249,200,.98)');grad.addColorStop(.15,'rgba(255,208,98,.70)');grad.addColorStop(.34,'rgba(255,144,49,.34)');grad.addColorStop(.65,'rgba(255,112,30,.07)');grad.addColorStop(1,'rgba(255,95,15,0)');solarCtx.fillStyle=grad;solarCtx.fillRect(0,0,256,256);
  const solarGlow=new THREE.CanvasTexture(solarCanvas);const sunGroup=new THREE.Group();sunGroup.position.set(-8.6,5.1,-13.5);scene.add(sunGroup);
  const sunCore=new THREE.Mesh(new THREE.SphereGeometry(.93,64,48),new THREE.MeshBasicMaterial({color:0xffd17a}));sunGroup.add(sunCore);
  const sunGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:solarGlow,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}));sunGlow.scale.set(9.6,9.6,1);sunGroup.add(sunGlow);
  const objects={earth,moon,mars};const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  const zero=new THREE.Vector3();let last=performance.now();
  function locate(key){
   const o=objects[key];if(!o)return null;
   const v=o.getWorldPosition(new THREE.Vector3()).project(camera);
   if(v.z>=1)return null;
   const r=host.getBoundingClientRect();
   const distance=camera.position.distanceTo(o.getWorldPosition(zero));
   const diameter=(o.geometry.parameters.radius*2)*r.height/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*distance);
   return{x:r.left+(v.x+1)/2*r.width,y:r.top+(1-v.y)/2*r.height,r:diameter/2};
  }
  function hitTest(e){const r=host.getBoundingClientRect();pointer.x=2*(e.clientX-r.left)/r.width-1;pointer.y=1-2*(e.clientY-r.top)/r.height;raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects([earth,moon,mars],false)[0];if(hit){const name=Object.keys(objects).find(k=>objects[k]===hit.object);if(name)selectPlanet(name);}}
  host.addEventListener('click',hitTest);host.style.cursor='pointer';
  // No PointerMove/Drag/Wheel handlers. Todo sigue girando siempre.
  sceneControl={select:()=>{},project:locate};
  function resize(){const ww=host.clientWidth,hh=host.clientHeight;camera.aspect=ww/hh;camera.fov=innerWidth<650?63:innerWidth<1000?53:43;camera.position.z=innerWidth<650?19:15.5;camera.updateProjectionMatrix();renderer.setSize(ww,hh,false);positionCard();}
  addEventListener('resize',resize);resize();$('planet-fallback').style.display='none';
  function frame(time){requestAnimationFrame(frame);let dt=Math.min((time-last)/1000,.05);last=time;
   earth.rotation.y+=dt*.071;moon.rotation.y+=dt*.089;mars.rotation.y+=dt*.063;clouds.rotation.y+=dt*.018;
   sunCore.rotation.y+=dt*.014;
   renderer.render(scene,camera);
   if(selected)positionCard();
   for(const [key,ob] of Object.entries(objects)){let p=locate(key),marker=document.querySelector('[data-marker="'+key+'"]');if(!p)continue;marker.style.left=(p.x-host.getBoundingClientRect().left)+'px';marker.style.top=(p.y-host.getBoundingClientRect().top+p.r+14)+'px';}
  }
  requestAnimationFrame(frame);
 }catch(err){console.warn('Se activó la vista alternativa, Three.js no disponible:',err);$('universe').style.display='none';document.querySelector('.sun-fallback').style.display='block';}
})();
