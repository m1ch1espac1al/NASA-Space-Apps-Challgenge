<?php // Cosmic Legacy · prototipo visual educativo · Apache / XAMPP ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#020612"><meta name="description" content="Una experiencia espacial: Tierra, Luna y Marte en movimiento, con sus distancias y sus historias.">
<title>Cosmic Legacy — Huellas en el cosmos</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div id="sky" aria-hidden="true"></div><canvas id="star-canvas" aria-hidden="true"></canvas>
<div class="ambient ambient-blue" aria-hidden="true"></div><div class="ambient ambient-purple" aria-hidden="true"></div>
<div id="rocket-flight" class="rocket-flight" aria-hidden="true"><div class="rocket-trail"></div><img src="assets/img/nasa-style-rocket.svg" alt="" draggable="false"></div>
<main id="app">
 <header class="topbar">
  <a class="brand" href="#inicio" aria-label="Cosmic Legacy, inicio"><span class="brand-icon">✦</span><span class="brand-name">COSMIC<span>LEGACY</span></span></a>
  <span class="nav-split"></span><span class="small-header">ECOS DE LA EXPLORACIÓN</span>
  <nav class="navigation" aria-label="Menú principal"><a href="#inicio" class="active">Explorar</a><button id="nav-missions">Misiones</button><button id="nav-stories">Historias</button><button id="nav-about">Acerca de</button></nav>
  <button id="mobile-menu" class="mobile-menu" aria-label="Mostrar menú" aria-expanded="false">☰</button>
 </header>
 <section class="space-scene" id="inicio" aria-label="Escena espacial de tres cuerpos que rotan automáticamente">
  <div id="universe" aria-hidden="true"></div>
  <div id="planet-fallback"><button class="fallback-planet earth-img" data-planet="earth" aria-label="Seleccionar Tierra"></button><button class="fallback-planet moon-img" data-planet="moon" aria-label="Seleccionar Luna"></button><button class="fallback-planet mars-img" data-planet="mars" aria-label="Seleccionar Marte"></button><div class="sun-fallback" aria-hidden="true"></div></div>
  <div class="orbital-line orbital-one"></div><div class="orbital-line orbital-two"></div>
  <svg id="callout-lines" aria-hidden="true"><path id="callout-path"></path><circle id="callout-node" r="3"></circle></svg>
  <article id="planet-callout" class="planet-callout" aria-live="polite" hidden>
    <div class="callout-top"><span id="callout-type">PLANETA</span><span class="callout-spark">✧</span></div>
    <h2 id="callout-title">La Tierra</h2><p id="callout-desc"></p>
    <button id="callout-story">CONOCER SU HISTORIA <span>↗</span></button>
  </article>
  <div id="planet-markers" class="planet-markers" aria-hidden="true"><span data-marker="earth">TIERRA</span><span data-marker="moon">LUNA</span><span data-marker="mars">MARTE</span></div>
 </section>
 <section class="hero-copy"><div class="eyebrow"><span>✦</span> ABANDONADOS, PERO NO OLVIDADOS <span>✦</span></div><h1>HUELLAS EN EL <em>COSMOS</em></h1><p>Las misiones terminan. Sus historias permanecen.<br>Descubre los mundos que transformaron nuestra forma de explorar.</p><button class="explore-button" id="start-btn">COMENZAR EXPLORACIÓN <span>↗</span></button></section>
 <aside class="distance-panel" aria-label="Distancias desde la Tierra"><span class="distance-label">DISTANCIAS DESDE LA TIERRA</span><div class="distance-row"><span class="distance-icon">◐</span><span class="distance-caption">LUNA <small>distancia media</small></span><strong>384,400 <small>km</small></strong></div><div class="distance-rule"></div><div class="distance-row"><span class="distance-icon red">●</span><span class="distance-caption">MARTE <small>distancia variable</small></span><strong>54.6–400+ <small>mill. km</small></strong></div><span class="distance-sources"><a href="https://science.nasa.gov/moon/by-the-numbers/" target="_blank" rel="noopener noreferrer" class="distance-source">NASA · Luna ↗</a><a href="https://www.nasa.gov/wp-content/uploads/2024/12/esdmd-001-add-rev-b.pdf" target="_blank" rel="noopener noreferrer" class="distance-source">NASA · Marte ↗</a></span></aside>
 <div class="planet-picker" role="group" aria-label="Seleccionar un cuerpo celeste"><button data-select="moon"><span class="picker-dot moon-dot"></span>Luna</button><button data-select="earth"><span class="picker-dot earth-dot"></span>Tierra</button><button data-select="mars"><span class="picker-dot mars-dot"></span>Marte</button></div>
 <div class="bottom-hint"><span class="autospin-dot"></span> ROTACIÓN CONTINUA DE LOS TRES CUERPOS <span class="hint-dot">✦</span> SELECCIONA UN MUNDO PARA CONOCERLO</div>
 <div class="credit">RECREACIÓN ARTÍSTICA · DISTANCIAS Y TAMAÑOS NO A ESCALA · NO AFILIADO A NASA</div>
</main>
<div class="modal-layer" id="modal-layer" hidden><div class="modal-backdrop" data-close="true"></div><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button id="close-modal" class="modal-close" aria-label="Cerrar">×</button><span id="modal-kicker" class="modal-kicker">ARCHIVO COSMIC LEGACY</span><h2 id="modal-title"></h2><p id="modal-body"></p><div id="modal-extra"></div><button class="modal-ok" id="modal-ok">VOLVER AL UNIVERSO ↗</button></section></div>
<script type="module" src="assets/js/app.js"></script>
</body></html>
