# Mapa del código — Cosmic Legacy v34 estructurada

```text
planetas/
├── index.php                              # Portada y exploración orbital
├── realidad-virtual.php                   # Museo interactivo
├── README.md                              # Instalación y rutas de edición
├── assets/
│   ├── css/
│   │   ├── inicio.css                     # Estilos ACTIVOS de la portada
│   │   └── realidad-virtual.css           # Estilos ACTIVOS del museo
│   ├── js/
│   │   ├── core/
│   │   │   └── idiomas.js                 # Internacionalización ES/EN
│   │   ├── data/
│   │   │   └── equipos-lunares.js         # Catálogo de piezas y fuentes NASA
│   │   ├── pages/
│   │   │   ├── inicio.js                  # Órbita, planetas y efectos de portada
│   │   │   └── realidad-virtual.js        # Mapa, descubrimientos, cuestionario
│   │   └── viewers/
│   │       ├── apollo11.js               # Escena 3D del Eagle
│   │       └── apollo15.js               # Escena 3D de Apollo 15/ALSEP
│   ├── img/
│   │   ├── equipment/                    # Ilustraciones SVG de los hallazgos
│   │   └── ...                           # Texturas, mapas y fondos
│   └── models/
│       ├── apollo11-eagle.glb
│       ├── phobos.glb
│       └── deimos.glb
├── herramientas/
│   └── verificar_estructura.py           # Revisión de archivos y enlaces internos
└── docs/
    ├── ESTRUCTURA.md                     # Este documento
    └── historial/
        ├── LEEME_VERSIONES_ANTERIORES.txt
        └── estilos-originales/           # CSS antiguos inactivos / respaldo
```

## Esquema de dependencias

```text
index.php
  ├── assets/css/inicio.css
  ├── assets/js/core/idiomas.js
  └── assets/js/pages/inicio.js
         └── Three.js desde CDN (a través de importmap)

realidad-virtual.php
  ├── assets/css/realidad-virtual.css
  ├── assets/js/core/idiomas.js
  └── assets/js/pages/realidad-virtual.js
         ├── assets/js/data/equipos-lunares.js
         ├── assets/js/viewers/apollo11.js
         ├── assets/js/viewers/apollo15.js
         └── Three.js desde CDN (a través de importmap)
```

## Convenciones

1. **Una pantalla, una hoja CSS activa.** Los parches históricos v17–v34 están incorporados en la hoja correspondiente y conservan su orden de precedencia. Cada fragmento conserva un comentario que indica su origen.
2. **Un punto de entrada JS por página.** Los datos y los visores son módulos separados importados desde la página de Realidad Virtual.
3. **No cambiar la ruta pública de los modelos ni las imágenes sin actualizar sus referencias.** Las URLs `assets/img/...` y `assets/models/...` se resuelven desde la página PHP, por eso se conservaron.
4. **No editar el código del visor 3D desde los archivos del historial.** El código activo vive en `assets/js/viewers/`.
5. **Conservar la v34 original como respaldo** si deseas comparar resultados o deshacer la reorganización.

## Límites de esta entrega

Este trabajo es una **reorganización de código y rutas** con la reparación de dos rutas CSS a imágenes inexistentes, que ahora apuntan a un fondo espacial incluido. No pretende modificar la fidelidad física, la precisión científica, la interfaz, las animaciones o las misiones existentes. En particular, no añade el módulo Surveyor 3 de versiones posteriores a la v34 subida.
