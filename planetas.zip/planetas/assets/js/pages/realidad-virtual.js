import { LUNAR_EQUIPMENT } from '../data/equipos-lunares.js';
/* Cosmic Legacy v12 · recorrido educativo 3D, sin base de datos.
   Las coordenadas de los marcadores son ilustrativas, NO ubicaciones científicas exactas.
   Las fichas enlazan a fuentes oficiales de NASA. */
const el = (id) => document.getElementById(id);
const tr=(key,es='')=>window.CosmicI18n?.t(key,es)??es;
const vrLoc=(world,index,field,es)=>{
 if(world==='moon'&&window.CosmicI18n?.homeField){
  if(field==='type'||field==='description')return window.CosmicI18n.homeField('moon',index,field,es);
  if(field==='learn')return window.CosmicI18n.homeField('moon',index,'short',es);
 }
 return window.CosmicI18n?.vrField(world,index,field,es)??es;
};
const eqLoc=(item,field,es)=>window.CosmicI18n?.equipField(item,field,es)??es;
const WORLDS = {
  moon: {
    title: 'La Luna', tag:'LUNA', sector:'EXPEDICIÓN LUNAR', texture:'moon-map-hd.jpg', bump:'moon-relief.jpg',
    fallback:'moon-animated.webp', accent:'#ace0ff',
    intro:'Rastrea vehículos, módulos de descenso e instrumentos científicos que las misiones de NASA dejaron en nuestro satélite natural.',
    quiz:{question:'¿Qué parte del módulo lunar Apolo permaneció en la superficie después del despegue de la tripulación?',answers:['La etapa de descenso','El módulo de mando','La etapa de ascenso'],correct:0,explanation:'La etapa de descenso quedó en la Luna; la etapa de ascenso regresó a la órbita lunar.'},
    items:[{name:'Apollo 11 LM / EASEP',type:'MÓDULO LUNAR + EXPERIMENTOS',year:'1969',description:'El módulo lunar Eagle dejó su etapa de descenso en la superficie. Los astronautas desplegaron EASEP con un experimento sísmico y un retroreflector láser para estudiar la Luna.',learn:'La primera misión tripulada que llegó a la Luna también dejó instrumentos científicos que siguieron contando su historia.',source:'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1969-059C',lat:10,lon:16},
      {name:'Apollo 15 Lunar Module / ALSEP',type:'MÓDULO + ESTACIÓN CIENTÍFICA',year:'1971',description:'Apollo 15 llevó un módulo lunar, el primer vehículo lunar tripulado (LRV) y una estación de experimentos ALSEP. El instrumental registró información sobre la superficie y el entorno lunar.',learn:'Algunas misiones no solo llegaron: dejaron instrumentos capaces de seguir investigando mucho después.',source:'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1971-063C',lat:-11,lon:-8},
      {name:'NSSDCA / COSPAR',type:'IDENTIFICADOR DOCUMENTAL',year:'Referencia',description:'NSSDCA y COSPAR se utilizan para identificar y catalogar misiones y objetos espaciales. Aquí se conserva como referencia documental del legado espacial vinculado al archivo lunar.',learn:'No todo legado es una máquina: también existen catálogos e identificadores que preservan la memoria de las misiones.',source:'https://nssdc.gsfc.nasa.gov/nmc/',lat:-29,lon:34},
      {name:'Surveyor 3 (Agrimensor 3)',type:'SONDA DE ATERRIZAJE',year:'1967',description:'Surveyor 3 aterrizó en la Luna en 1967 y examinó el terreno con una pala de muestreo. En 1969 astronautas de Apollo 12 visitaron la sonda y recuperaron piezas para estudiarlas en la Tierra.',learn:'Antes de los alunizajes tripulados, sondas como Surveyor ayudaron a entender cómo era realmente el suelo lunar.',source:'https://science.nasa.gov/mission/surveyor-3/',lat:28,lon:-40}]
  },
  mars: {
    title:'Marte',tag:'MARTE',sector:'EXPEDICIÓN MARCIANA',texture:'mars-map-hd.jpg',bump:'mars-relief.jpg',fallback:'mars-animated.webp',accent:'#e2ac82',
    intro:'Busca los robots y aterrizadores que estudiaron el planeta rojo y descubre lo que aprendieron durante sus misiones.',
    quiz:{question:'¿Cuál fue el logro pionero del pequeño helicóptero Ingenuity?',answers:['El primer vuelo controlado y propulsado en otro planeta','Traer rocas de Marte a la Tierra','Aterrizar seres humanos en Marte'],correct:0,explanation:'Ingenuity demostró el vuelo motorizado y controlado en la atmósfera marciana y realizó 72 vuelos.'},
    items:[
      {name:'Viking 1',type:'ATERRIZADOR',year:'1976',description:'Viking 1 aterrizó en Marte y envió imágenes y mediciones del suelo y de la atmósfera durante una misión histórica.',learn:'Amplió nuestro conocimiento directo de las condiciones de la superficie marciana.',source:'https://science.nasa.gov/mission/viking-1/',lat:15,lon:5},
      {name:'Viking 2',type:'ATERRIZADOR',year:'1976',description:'Viking 2 fue la misión hermana de Viking 1. Su aterrizador ayudó a estudiar otras condiciones en Marte mediante fotografías y experimentos.',learn:'Dos puntos de observación aportaron una perspectiva más amplia de las condiciones marcianas.',source:'https://science.nasa.gov/mission/viking-2/',lat:-12,lon:42},
      {name:'Mars Pathfinder',type:'ATERRIZADOR',year:'1997',description:'Pathfinder demostró el aterrizaje con bolsas de aire y depositó en Marte al pequeño rover Sojourner.',learn:'Ayudó a abrir una nueva etapa de exploración de Marte con vehículos móviles.',source:'https://science.nasa.gov/mission/mars-pathfinder/',lat:39,lon:60},
      {name:'Sojourner',type:'PRIMER ROVER MARCIANO NASA',year:'1997',description:'Sojourner fue el pequeño vehículo robótico transportado por Pathfinder. Recorrió el terreno para analizar rocas y suelo.',learn:'Demostró que un rover podía explorar y analizar objetivos en la superficie de otro planeta.',source:'https://science.nasa.gov/mission/mars-pathfinder/',lat:-32,lon:-33},
      {name:'Spirit',type:'ROVER',year:'2004',description:'Spirit exploró el cráter Gusev buscando pistas sobre antiguos procesos geológicos y ambientes afectados por el agua.',learn:'Las rocas y los minerales conservan evidencias de la historia ambiental de Marte.',source:'https://science.nasa.gov/mission/mer-spirit/',lat:10,lon:-65},
      {name:'Opportunity',type:'ROVER',year:'2004',description:'Opportunity operó durante casi 15 años y examinó minerales, capas sedimentarias y antiguas señales de agua.',learn:'Una misión prevista para unos 90 soles logró investigar durante años y superar su vida de diseño.',source:'https://science.nasa.gov/mission/mer-opportunity/',lat:-8,lon:96},
      {name:'Phoenix',type:'ATERRIZADOR POLAR',year:'2008',description:'Phoenix aterrizó en las altas latitudes norte de Marte y examinó el suelo y el hielo subsuperficial con un brazo robótico.',learn:'Sus mediciones ampliaron nuestro conocimiento sobre el hielo de agua y el entorno polar marciano.',source:'https://science.nasa.gov/mission/phoenix/',lat:51,lon:130},
      {name:'InSight',type:'ATERRIZADOR SÍSMICO',year:'2018',description:'InSight desplegó un sismómetro para estudiar los martemotos y comprender mejor el interior del planeta.',learn:'La actividad sísmica permite estudiar la estructura de un planeta incluso sin excavar profundamente.',source:'https://science.nasa.gov/mission/insight/',lat:-43,lon:151},
      {name:'Ingenuity',type:'HELICÓPTERO',year:'2021–2024',description:'Ingenuity realizó el primer vuelo motorizado y controlado en otro planeta; completó 72 vuelos antes de terminar su misión.',learn:'El vuelo robótico puede complementar la exploración terrestre en Marte.',source:'https://science.nasa.gov/mission/mars-2020-perseverance/ingenuity-mars-helicopter/',lat:22,lon:-138}
    ]
  }
};
const state={world:null,discovered:{moon:new Set(),mars:new Set()},selected:-1,objectSelected:-1,objectSeen:new Set(),quizDone:{moon:false,mars:false},quizOpen:false,render:null,launchToken:0,toastTimeout:null,detailOpen:false,detailTimer:null,revealed:{moon:new Set()}};
const MOON_EQUIPMENT_MAP=[0,5,null,2];
const equipmentGroup=(missionIndex)=> state.world==='moon' ? (MOON_EQUIPMENT_MAP[missionIndex]==null?null:LUNAR_EQUIPMENT[MOON_EQUIPMENT_MAP[missionIndex]]) : null;
const $ = el;
let rocketTimeout=null,ringTimeout=null,ringEndTimeout=null;
const SURFACE_OFFSETS=[[-46,-32],[48,-25],[-58,10],[56,14],[-10,44],[18,-52]];
// v34: one viewer per lunar artifact, with race-safe switching and return to map.
const MINI_MARKER_ICONS=['lander.svg','alsep.svg','reflector.svg','surveyor.svg'];
const MINI_MARKER_NAMES=['Apollo 11','Apollo 15','NSSDCA','Surveyor 3'];
const DISCOVERED_MARKER_KEY='cosmic-legacy-lunar-marks-v34';
function restoreRevealed(){
 try { const v=JSON.parse(sessionStorage.getItem(DISCOVERED_MARKER_KEY)||'[]');
   if(Array.isArray(v))v.filter(n=>Number.isInteger(n)&&n>=0&&n<4).forEach(n=>{state.revealed.moon.add(n);state.discovered.moon.add(n);});
 } catch(e) { /* storage disabled: still works in memory */ }
}
function persistRevealed(){
 try {sessionStorage.setItem(DISCOVERED_MARKER_KEY,JSON.stringify([...state.revealed.moon]));} catch(e) {}
}
function updateLunarMarker(btn,i,force=false){
 if(!btn || state.world!=='moon')return;
 const visible=state.revealed.moon.has(i);
 const markerState=(visible?'seen:':'hidden:')+(window.CosmicI18n?.lang?.()||'es');
 if(!force && btn.dataset.markerState===markerState)return;
 btn.dataset.markerState=markerState;
 btn.classList.toggle('vr-mini-reveal',visible);
 btn.classList.toggle('vr-hotspot-question',!visible);
 btn.classList.toggle('vr-hotspot-apollo',i===0&&!visible);
 btn.classList.toggle('vr-hotspot-apollo15',i===1&&!visible);
 btn.classList.toggle('vr-hotspot-document',i===2&&!visible);
 const content=btn.querySelector('span')||btn.appendChild(document.createElement('span'));
 content.replaceChildren();
 if(visible){
  const img=document.createElement('img');img.src='assets/img/equipment/'+MINI_MARKER_ICONS[i];img.alt='';img.draggable=false;img.className='vr-mini-icon';
  const label=document.createElement('small');label.textContent=MINI_MARKER_NAMES[i];
  content.append(img,label);
 }else {content.textContent='?';}
 const prefix=visible?(window.CosmicI18n?.lang?.()==='en'?'See ':'Ver '):(window.CosmicI18n?.lang?.()==='en'?'Discover ':'Descubrir ');
 btn.setAttribute('aria-label',prefix+WORLDS.moon.items[i].name);
 btn.title=prefix+WORLDS.moon.items[i].name;
}
let currentViewer=null,viewerIndex=-1,pendingViewer=null,viewerGeneration=0;
function hideLunarViewer(){const wrap=el('vr-discovery-viewer');if(wrap)wrap.hidden=true;}
function disposeLunarViewer(){
 ++viewerGeneration;
 try {currentViewer?.destroy?.();}catch(e){console.warn('Closing viewer',e)}
 currentViewer=null;viewerIndex=-1;pendingViewer=null;
 el('vr-apollo-viewer')?.replaceChildren();
 hideLunarViewer();
}
async function ensureLunarViewer(index){
 const wrap=el('vr-discovery-viewer'),host=el('vr-apollo-viewer');
 if(!wrap||!host||index>1)return;
 host.dataset.artifact=index===0?'apollo11':'apollo15';
 if(viewerIndex!==index)disposeLunarViewer();
 host.dataset.artifact=index===0?'apollo11':'apollo15';
 wrap.hidden=false;
 wrap.dataset.mission=String(index);
 const title=wrap.querySelector('.micro-label');if(title)title.textContent=index===0?'VISTA APOLLO 11':'VISTA APOLLO 15';
 const chip=wrap.querySelector('.vr-discovery-viewer-chip');if(chip)chip.textContent=index===0?'EAGLE':'FALCON + ALSEP';
 if(currentViewer){currentViewer.show?.();return;}
 if(pendingViewer)return pendingViewer;
 const generation=viewerGeneration;
 pendingViewer=(async()=>{
  let viewer=null;
  try{
   if(index===0){const {createApolloScene}=await import('../viewers/apollo11.js?v=1');
    if(generation!==viewerGeneration||state.world!=='moon'||!state.detailOpen||state.selected!==index)return;
    viewer=await createApolloScene(host);
   } else {const {createApollo15Scene}=await import('../viewers/apollo15.js?v=1');
    if(generation!==viewerGeneration||state.world!=='moon'||!state.detailOpen||state.selected!==index)return;
    viewer=await createApollo15Scene(host);
   }
   if(generation!==viewerGeneration||state.world!=='moon'||!state.detailOpen||state.selected!==index){viewer?.destroy?.();return;}
   currentViewer=viewer;viewerIndex=index;
  }catch(err){
   console.warn('Model viewer unavailable; showing the supplied visual instead.',err);
   if(generation!==viewerGeneration||state.world!=='moon'||!state.detailOpen||state.selected!==index)return;
   host.replaceChildren();
   const img=document.createElement('img');img.className='vr-artifact-fallback-image';
   img.src=index===0?'assets/img/apollo11-photo-clean.png':'assets/img/apollo15-composition.png';
   img.alt=index===0?'Ilustración del módulo Apollo 11':'Imagen aportada del módulo Apollo 15 y experimentos ALSEP';
   host.append(img);
   currentViewer={show(){wrap.hidden=false;},destroy(){host.replaceChildren();}};viewerIndex=index;
  }
 })();
 try {await pendingViewer;} finally {if(generation===viewerGeneration)pendingViewer=null;}
}
function clearSurfaceArtifacts(){ const layer=el('vr-surface-items');if(layer){layer.replaceChildren();delete layer.dataset.mission;} }
function renderSurfaceArtifacts(basePoint=null){
 const layer=el('vr-surface-items');if(!layer)return;
 if(state.world!=='moon'||state.selected<0||!state.detailOpen){layer.hidden=true;return;}
 const group=equipmentGroup(state.selected);if(!group?.items?.length){layer.hidden=true;return;}
 const marker=el('vr-hotspots').querySelector(`[data-index="${state.selected}"]`);
 if(!basePoint && (!marker||marker.hidden)){layer.hidden=true;return;}
 const stage=el('vr-stage-visual');
 const resolve=(value,axis)=>value?.endsWith('%')?parseFloat(value)*((axis==='x'?stage.clientWidth:stage.clientHeight)/100):parseFloat(value);
 const x=basePoint?.x??(marker.dataset.x?parseFloat(marker.dataset.x):resolve(marker.style.left,'x'));
 const y=basePoint?.y??(marker.dataset.y?parseFloat(marker.dataset.y):resolve(marker.style.top,'y'));
 if(!Number.isFinite(x)||!Number.isFinite(y)){layer.hidden=true;return;}
 layer.hidden=false;
 // Never rebuild the DOM on every 3D frame: update position only.
 if(layer.dataset.mission!==String(state.selected)||layer.children.length!==group.items.length){
  layer.replaceChildren();layer.dataset.mission=String(state.selected);
  group.items.forEach((item,i)=>{
   const btn=document.createElement('button');btn.type='button';btn.className='vr-surface-token';
   btn.setAttribute('aria-label',tr('vr.equipment.view','View artifact')+' '+eqLoc(item,'name',item.name));
   const img=document.createElement('img');img.src='assets/img/equipment/'+item.art+'.svg';img.alt='';img.loading='lazy';
   const name=document.createElement('span');name.textContent=eqLoc(item,'name',item.name).replace(/ · .*/, '').slice(0,20);
   btn.append(img,name);btn.addEventListener('click',()=>selectLunarObject(state.selected,i));layer.append(btn);
  });
 }
 [...layer.children].forEach((btn,i)=>{
  const off=SURFACE_OFFSETS[i%SURFACE_OFFSETS.length];btn.style.left=(x+off[0])+'px';btn.style.top=(y+off[1])+'px';
  btn.classList.toggle('active',i===state.objectSelected);
 });
}

function toast(message){const t=el('vr-toast');clearTimeout(state.toastTimeout);t.textContent=message;t.classList.add('show');state.toastTimeout=setTimeout(()=>t.classList.remove('show'),3200);}
function renderCatalog(){
 const entries=WORLDS[state.world].items,filter=el('vr-filter').value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
 const list=el('vr-mission-list');list.replaceChildren();
 entries.forEach((m,i)=>{
  if(!m.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').includes(filter))return;
  const b=document.createElement('button');b.type='button';b.className='archive-entry'+(state.selected===i?' current':'')+(state.discovered[state.world].has(i)?' found':'');b.setAttribute('aria-label',`Consultar ${m.name}`);
  const n=document.createElement('span');n.className='entry-number';n.textContent=String(i+1).padStart(2,'0');
  const copy=document.createElement('span');copy.className='entry-copy';const strong=document.createElement('strong');strong.textContent=m.name;const small=document.createElement('small');const group=state.world==='moon'?equipmentGroup(i):null;small.textContent=vrLoc(state.world,i,'type',m.type)+' · '+m.year+(state.world==='moon'?` · ${group?.items?.length||0} ${tr('vr.pieces','piezas').toLowerCase()}`: '');copy.append(strong,small);
  const mark=document.createElement('span');mark.className='entry-check';mark.textContent='✓';b.append(n,copy,mark);
  b.addEventListener('click',()=>state.world==='moon'?openDiscovery(i):inspect(i));list.append(b);
 });
 if(!list.children.length){const p=document.createElement('p');p.className='archive-foot';p.textContent=tr('vr.noresults','No hay registros con ese nombre.');list.append(p);}
}
function updateProgress(){
 const cur=state.discovered[state.world].size,total=WORLDS[state.world].items.length;
 el('vr-progress-top').textContent=`${cur} / ${total}`;el('vr-progress-label').textContent=window.CosmicI18n?.lang()==='en'?`${cur} of ${total}`:`${cur} de ${total}`;el('vr-progress-bar').style.width=`${(cur/total)*100}%`;
 const unlocked=cur>=4,completed=state.quizDone[state.world];
 el('vr-quiz-open').disabled=!unlocked;
 el('vr-challenge-status').textContent=completed?tr('vr.quiz.completed','COMPLETADO'):unlocked?tr('vr.quiz.available','DISPONIBLE'):tr('vr.quiz.blocked','BLOQUEADO');
 el('vr-challenge-copy').textContent=completed?tr('vr.quiz.done','¡Reto completado! Continúa descubriendo el archivo o explora otro mundo.'):unlocked?tr('vr.quiz.ready','Ya conoces cuatro vestigios. Demuestra lo que aprendiste.'):window.CosmicI18n?.lang()==='en'?`Discover ${4-cur} more records to unlock a question.`:`Descubre ${4-cur} registros más para desbloquear una pregunta.`;
 el('vr-quiz-open').textContent=completed?tr('vr.quiz.repeat','REPETIR PREGUNTA ↗'):unlocked?tr('vr.quiz.open','RESPONDER DESAFÍO ↗'):tr('vr.unlock','DESBLOQUEAR RETO ↗');
 if(cur===total)toast('¡Archivo explorado por completo! Ya conoces todos los registros de esta expedición.');
}
// Cada tema lunar tiene varias piezas físicas con identidad y destino propios.
function displayLunarEquipment(missionIndex){
 const group=equipmentGroup(missionIndex),lab=el('vr-object-lab');
 lab.hidden=!(state.world==='moon'&&group);
 if(lab.hidden){ clearSurfaceArtifacts(); return; }
 el('vr-objects-count').textContent=group.items.length+' '+tr('vr.pieces','PIEZAS');
 el('vr-object-warning').textContent=tr('vr.note.'+MOON_EQUIPMENT_MAP[missionIndex],group.note);
 const target=el('vr-object-choices');target.replaceChildren();
 group.items.forEach((item,i)=>{
  const btn=document.createElement('button');btn.type='button';btn.className='object-choice';
  btn.setAttribute('aria-pressed','false'); btn.setAttribute('aria-label','Ver '+item.name);
  const pic=document.createElement('img');pic.alt='';pic.loading='lazy';pic.src='assets/img/equipment/'+item.art+'.svg';
  const content=document.createElement('span');content.className='object-choice-text';
  const name=document.createElement('strong');name.textContent=eqLoc(item,'name',item.name);
  const type=document.createElement('small');type.textContent=eqLoc(item,'class',item.class);content.append(name,type);
  btn.append(pic,content);btn.addEventListener('click',()=>selectLunarObject(missionIndex,i));target.append(btn);
 });
 selectLunarObject(missionIndex,0);
}
function selectLunarObject(missionIndex,itemIndex){
 if(state.world!=='moon'||state.selected!==missionIndex)return;
 const group=equipmentGroup(missionIndex),item=group?.items[itemIndex];if(!item)return;
 state.objectSelected=itemIndex; state.objectSeen.add(missionIndex+':'+itemIndex);
 el('vr-object-choices').querySelectorAll('.object-choice').forEach((btn,i)=>{
  const active=i===itemIndex;btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));
  btn.classList.toggle('seen',state.objectSeen.has(missionIndex+':'+i));
 });
 el('vr-object-art').src='assets/img/equipment/'+item.art+'.svg';
 el('vr-object-art').alt='Ilustración esquemática de '+item.name;
 for(const [id,val] of Object.entries({
  'vr-object-kind':eqLoc(item,'class',item.class),'vr-object-status':eqLoc(item,'status',item.status),
  'vr-object-name':eqLoc(item,'name',item.name),'vr-object-what':eqLoc(item,'what',item.what),'vr-object-purpose':eqLoc(item,'purpose',item.purpose),
  'vr-object-fate':eqLoc(item,'fate',item.fate),'vr-object-discovery':eqLoc(item,'discovery',item.discovery)
 }))el(id).textContent=val;
 el('vr-object-source').href=item.source;
 el('vr-object-zoom').setAttribute('aria-label','Ampliar detalles de '+item.name);
 renderSurfaceArtifacts();
}

function openLunarObjectDetail(){
 if(state.world!=='moon'||state.selected<0||state.objectSelected<0)return;
 const item=equipmentGroup(state.selected)?.items[state.objectSelected];if(!item)return;
 const modal=el('vr-object-modal');
 for(const [id,v] of Object.entries({
  'vr-object-modal-kind':eqLoc(item,'class',item.class),'vr-object-modal-title':eqLoc(item,'name',item.name),'vr-object-modal-status':eqLoc(item,'status',item.status),
  'vr-object-modal-what':eqLoc(item,'what',item.what),'vr-object-modal-purpose':eqLoc(item,'purpose',item.purpose),
  'vr-object-modal-fate':eqLoc(item,'fate',item.fate),'vr-object-modal-discovery':eqLoc(item,'discovery',item.discovery)
 }))el(id).textContent=v;
 el('vr-object-modal-img').src='assets/img/equipment/'+item.art+'.svg';
 el('vr-object-modal-img').alt='Representación esquemática de '+item.name;
 el('vr-object-modal-link').href=item.source;
 if(typeof modal.showModal==='function')modal.showModal();else modal.setAttribute('open','');
 el('vr-object-modal-close').focus();
}
el('vr-object-zoom').addEventListener('click',openLunarObjectDetail);
el('vr-object-modal-close').addEventListener('click',()=>el('vr-object-modal').close());
el('vr-object-modal').addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.close();});
function inspect(i){
 const m=WORLDS[state.world]?.items[i];if(!m)return;
 state.selected=i;
 const isNew=!state.discovered[state.world].has(i);state.discovered[state.world].add(i);
 el('vr-evidence-index').textContent=`${String(i+1).padStart(2,'0')} / ${String(WORLDS[state.world].items.length).padStart(2,'0')}`;
 el('vr-empty-detail').hidden=true;el('vr-evidence-detail').hidden=false;
 el('vr-evidence-type').textContent=`${vrLoc(state.world,i,'type',m.type)} · ${m.year}`;el('evidence-title').textContent=m.name;el('vr-evidence-desc').textContent=vrLoc(state.world,i,'description',m.description);el('vr-evidence-learn').textContent=vrLoc(state.world,i,'learn',m.learn);el('vr-evidence-source').href=m.source;
 displayLunarEquipment(i);
 renderSurfaceArtifacts();
 renderCatalog();updateProgress();state.render?.refreshMarkers();
 if(isNew)toast(`✦ ${tr('vr.new','Nuevo hallazgo documentado:')} ${m.name}`);
}
// v27: the lunar '?' opens a real discovery state instead of showing all details immediately.
function populateDiscovery(i){
 const m=WORLDS.moon.items[i];if(!m)return;
 const english=window.CosmicI18n?.lang()==='en';
 el('vr-discovery-number').textContent=(english?'DISCOVERY ':'HALLAZGO ')+String(i+1).padStart(2,'0')+' / 04';
 el('vr-discovery-title').textContent=m.name;
 el('vr-discovery-description').textContent=vrLoc('moon',i,'description',m.description);
 el('vr-discovery-source').href=m.source;
 const list=el('vr-discovery-artifacts');list.replaceChildren();
 const group=equipmentGroup(i);
 el('vr-discovery-equip-title').hidden=!group;
 if(group?.items?.length){
  group.items.forEach((item,j)=>{
   const b=document.createElement('button');b.type='button';b.className='vr-discovery-artifact';
   const img=document.createElement('img');img.alt='';img.src='assets/img/equipment/'+item.art+'.svg';
   const txt=document.createElement('span');txt.textContent=eqLoc(item,'name',item.name);
   b.append(img,txt);b.addEventListener('click',()=>{selectLunarObject(i,j);openLunarObjectDetail();});list.append(b);
  });
 }
 el('vr-discovery-note').textContent=group ? tr('vr.note.'+[0,5,2,2][i],group.note) : (english?'This NSSDCA / COSPAR entry is a catalog identifier, not a physical object left on the Moon.':'NSSDCA / COSPAR es un identificador de catálogo, no un objeto físico abandonado en la Luna.');
}
function openDiscovery(i){
 if(state.world!=='moon'||!WORLDS.moon.items[i])return;
 const overlay=el('vr-discovery-overlay'),game=el('vr-game');
 state.detailOpen=true;clearTimeout(state.detailTimer);
 inspect(i);populateDiscovery(i);
 el('vr-object-lab').hidden=true;
 const immersive=i===0||i===1;
 game.classList.add('discovery-mode');
 game.classList.toggle('apollo-layout',immersive);
 game.dataset.discoveryIndex=String(i);
 overlay.hidden=false;overlay.classList.remove('visible');
 overlay.classList.toggle('apollo-mode',immersive);
 if(immersive)ensureLunarViewer(i); else hideLunarViewer();
 state.render?.focusOn?.(i);
 state.detailTimer=setTimeout(()=>{if(state.detailOpen&&state.world==='moon')overlay.classList.add('visible');},500);
}
function closeDiscovery(immediate=false){
 const overlay=el('vr-discovery-overlay'),game=el('vr-game');
 clearTimeout(state.detailTimer);
 // The marker is revealed only after the user leaves the discovery, not on entry.
 if(state.detailOpen&&state.world==='moon'&&state.selected>=0){
  state.revealed.moon.add(state.selected);persistRevealed();
 }
 state.detailOpen=false;
 overlay.classList.remove('visible','apollo-mode');game.classList.remove('discovery-mode','apollo-layout');
 delete game.dataset.discoveryIndex;
 disposeLunarViewer();
 state.render?.clearFocus?.();
 state.selected=-1;state.objectSelected=-1;
 clearSurfaceArtifacts();
 if(state.world==='moon'){
  el('vr-empty-detail').hidden=false;el('vr-evidence-detail').hidden=true;
  el('vr-evidence-index').textContent='— / 04';
  renderCatalog();state.render?.refreshMarkers();
 }
 if(immediate){overlay.hidden=true;return;}
 state.detailTimer=setTimeout(()=>{if(!state.detailOpen)overlay.hidden=true;},420);
}
el('vr-discovery-close').addEventListener('click',()=>closeDiscovery());
function showQuiz(){
 if(state.discovered[state.world].size<4)return;
 state.quizOpen=true;
 const quiz=WORLDS[state.world].quiz;
 el('vr-quiz').hidden=false;el('vr-question').textContent=tr('vr.'+state.world+'.question',quiz.question);el('vr-quiz-feedback').textContent='';el('vr-answers').replaceChildren();
 quiz.answers.forEach((answer,i)=>{
  const b=document.createElement('button');b.type='button';b.textContent=`${String.fromCharCode(65+i)}. ${tr('vr.'+state.world+'.answers.'+i,answer)}`;
  b.addEventListener('click',()=>{
   if(i!==quiz.correct){b.classList.add('incorrect');el('vr-quiz-feedback').textContent=tr('vr.quiz.try','Inténtalo de nuevo: revisa la historia del equipo.');return;}
   b.classList.add('correct');el('vr-quiz-feedback').textContent=tr('vr.quiz.correct','¡Correcto!')+' '+tr('vr.'+state.world+'.explanation',quiz.explanation);state.quizDone[state.world]=true;updateProgress();activateRings();
   el('vr-answers').querySelectorAll('button').forEach(x=>x.disabled=true);
  });el('vr-answers').append(b);
 });
 el('vr-quiz-open').hidden=true;
}
function resetQuiz(){state.quizOpen=false;el('vr-quiz').hidden=true;el('vr-quiz-open').hidden=false;}
function activateRings(){const rings=el('vr-cosmos-rings');rings.classList.remove('engaged');void rings.offsetWidth;rings.classList.add('engaged');clearTimeout(ringEndTimeout);ringEndTimeout=setTimeout(()=>rings.classList.remove('engaged'),5900);}
function launchRocket(){
 clearTimeout(rocketTimeout);clearTimeout(ringTimeout);clearTimeout(ringEndTimeout);
 const rings=el('vr-cosmos-rings');if(!rings)return;
 rings.classList.remove('engaged');void rings.offsetWidth;
 ringTimeout=setTimeout(()=>{if(state.world)activateRings();},120);
}

function stopRocket(){clearTimeout(rocketTimeout);clearTimeout(ringTimeout);clearTimeout(ringEndTimeout);el('vr-cosmos-rings')?.classList.remove('engaged');}
async function enterWorld(key){
 if(!WORLDS[key])return;
 stopRocket();disposeLunarViewer();state.render?.destroy();state.render=null;
 state.world=key;if(key==='moon')restoreRevealed();state.detailOpen=false;clearTimeout(state.detailTimer);el('vr-game').classList.remove('discovery-mode','apollo-layout');el('vr-discovery-overlay').hidden=true;el('vr-discovery-overlay').classList.remove('visible');document.body.dataset.vrWorld=key;state.selected=-1;state.objectSelected=-1;state.objectSeen.clear();el('vr-object-lab').hidden=true;clearSurfaceArtifacts();
 el('vr-gateway').hidden=true;el('vr-game').hidden=false;el('vr-moon-controls').hidden=key!=='mars';
 el('vr-title').textContent=tr('vr.world.'+key+'.title','Explora '+(key==='moon'?'la Luna':'Marte'));el('vr-subtitle').textContent=tr('vr.'+key+'.intro',WORLDS[key].intro);
 el('vr-world-tag').textContent=tr('vr.world.'+key+'.tag',WORLDS[key].tag);el('vr-sector').textContent=tr('vr.world.'+key+'.sector',WORLDS[key].sector);
 el('vr-filter').value='';el('vr-empty-detail').hidden=false;el('vr-evidence-detail').hidden=true;el('vr-evidence-index').textContent=`— / ${String(WORLDS[key].items.length).padStart(2,'0')}`;
 resetQuiz();renderCatalog();updateProgress();
 el('vr-fallback-img').src='assets/img/'+WORLDS[key].fallback;
 createHotspotControls();
 await renderPlanet(key);
 if(state.world===key)launchRocket();
}
function leaveWorld(){
 closeDiscovery(true);stopRocket();disposeLunarViewer();el('vr-game').classList.remove('apollo-layout');state.render?.destroy();state.render=null;state.world=null;delete document.body.dataset.vrWorld;state.selected=-1;state.objectSelected=-1;el('vr-object-lab').hidden=true; clearSurfaceArtifacts(); if(el('vr-object-modal').open)el('vr-object-modal').close();
 el('vr-game').hidden=true;el('vr-gateway').hidden=false;el('vr-moon-controls').hidden=true;el('vr-hotspots').replaceChildren();el('vr-toast').classList.remove('show');
}
function createHotspotControls(){
 const parent=el('vr-hotspots');parent.replaceChildren();
 WORLDS[state.world].items.forEach((m,i)=>{
  const b=document.createElement('button');b.type='button';b.className='vr-hotspot';b.dataset.index=String(i);
  const label=document.createElement('span');b.append(label);
  if(state.world==='moon')updateLunarMarker(b,i,true);
  else {label.textContent=m.name;b.setAttribute('aria-label','Descubrir '+m.name);b.title=m.name;}
  b.addEventListener('click',()=>state.world==='moon'?openDiscovery(i):inspect(i));parent.append(b);
 });
}
async function renderPlanet(key){
 const host=el('vr-three-host');host.replaceChildren();el('vr-fallback').hidden=true;
 let THREE,GLTFLoader;
 try{
  THREE=await import('three');
  try{({GLTFLoader}=await import('three/addons/loaders/GLTFLoader.js'));}
  catch(err){GLTFLoader=null;console.warn('Modelos GLB no disponibles: modo roca de respaldo',err);}
 }catch(err){console.warn('Three.js no disponible. Se muestra alternativa:',err);makeFallback();return;}
 if(state.world!==key)return;
 let renderer;
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});}catch(err){console.warn('WebGL no disponible:',err);makeFallback();return;}
 const d=WORLDS[key],scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(42,1,.1,100);
 camera.position.set(0,0,key==='mars'?13:9.25);
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,innerWidth<700?1:1.2));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.36; host.append(renderer.domElement);
 scene.add(new THREE.AmbientLight(0xc8d5f6,.34));
 const keyLight=new THREE.DirectionalLight(0xffe6cd,3.15);keyLight.position.set(-6,5,8);scene.add(keyLight);
 const rim=new THREE.DirectionalLight(key==='moon'?0x6091e7:0xb97950,.65);rim.position.set(5,-2,-6);scene.add(rim);
 const loader=new THREE.TextureLoader(),gltfLoader=GLTFLoader?new GLTFLoader():null,anisotropy=Math.min(6,renderer.capabilities.getMaxAnisotropy());
 const tex=loader.load('assets/img/'+d.texture,()=>{},undefined,e=>console.warn('Textura:',e));tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=anisotropy;
 const bump=loader.load('assets/img/'+d.bump);bump.anisotropy=anisotropy;
 const radius=key==='moon'?3.18:2.72;
 const planet=new THREE.Mesh(new THREE.SphereGeometry(radius,84,58),new THREE.MeshStandardMaterial({map:tex,bumpMap:bump,bumpScale:key==='moon'?.085:.06,roughness:.98,metalness:0}));
 planet.rotation.order='YXZ';planet.rotation.y=-.45;scene.add(planet);
 function glowSprite(stops,scale){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=256;const ctx=canvas.getContext('2d');
  const g=ctx.createRadialGradient(128,128,10,128,128,128); for(const s of stops)g.addColorStop(s[0],s[1]); ctx.fillStyle=g; ctx.fillRect(0,0,256,256);
  const t=new THREE.CanvasTexture(canvas); t.colorSpace=THREE.SRGBColorSpace;
  const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending})); sprite.scale.set(scale,scale,1); return sprite;
 }
 const aura= key==='moon'
  ? glowSprite([[0,'rgba(255,255,255,.52)'],[.28,'rgba(255,255,255,.15)'],[1,'rgba(255,255,255,0)']], radius*2.9)
  : glowSprite([[0,'rgba(255,146,110,.32)'],[.35,'rgba(255,110,70,.13)'],[1,'rgba(255,85,55,0)']], radius*3.1);
 planet.add(aura);
 const anchors=d.items.map((m,i)=>{
  const lat=m.lat*Math.PI/180,lon=m.lon*Math.PI/180;
  const anchor=new THREE.Object3D();anchor.position.set(radius*1.012*Math.cos(lat)*Math.sin(lon),radius*1.012*Math.sin(lat),radius*1.012*Math.cos(lat)*Math.cos(lon));planet.add(anchor);return anchor;
 });
 let phobosOrbit=null,deimosOrbit=null,phobosBody=null,deimosBody=null;
 if(key==='mars'){
  const moonMat=new THREE.MeshStandardMaterial({color:0xa7acb5,roughness:1,metalness:0});
  const makeRock=size=>new THREE.Mesh(new THREE.IcosahedronGeometry(size,2),moonMat.clone());
  phobosOrbit=new THREE.Group();deimosOrbit=new THREE.Group();scene.add(phobosOrbit,deimosOrbit);
  phobosOrbit.rotation.set(.18,-.22,.17);deimosOrbit.rotation.set(-.11,.71,-.08);
  function traceOrbit(group,r,color){
   const pts=[];for(let n=0;n<=120;n++){const a=n/120*2*Math.PI;pts.push(new THREE.Vector3(Math.cos(a)*r,Math.sin(a)*r*.32,Math.sin(a)*r*.71));}
   group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color,transparent:true,opacity:.25,depthWrite:false})));
  }
  traceOrbit(phobosOrbit,radius*1.33,0xe2c6aa);traceOrbit(deimosOrbit,radius*1.78,0xa1aabb);
  const phobosHolder=new THREE.Group(),deimosHolder=new THREE.Group();phobosOrbit.add(phobosHolder);deimosOrbit.add(deimosHolder);
  phobosBody=new THREE.Group();deimosBody=new THREE.Group();phobosHolder.add(phobosBody);deimosHolder.add(deimosBody);
  const phobosVisualR=radius*.16,deimosVisualR=radius*.13;
  const phobosFallback=makeRock(phobosVisualR),deimosFallback=makeRock(deimosVisualR);phobosBody.add(phobosFallback);deimosBody.add(deimosFallback);
  phobosHolder.position.set(radius*1.33,.12,0);deimosHolder.position.set(-radius*1.78,-.18,0);
  function prep(root,target){const box=new THREE.Box3().setFromObject(root),size=new THREE.Vector3(),center=new THREE.Vector3();box.getSize(size);box.getCenter(center);const wrapper=new THREE.Group();root.position.sub(center);wrapper.add(root);wrapper.scale.setScalar((target*2)/(Math.max(size.x,size.y,size.z)||1));return wrapper;}
  if(gltfLoader)gltfLoader.load('assets/models/phobos.glb',g=>{phobosFallback.visible=false;phobosBody.add(prep(g.scene,phobosVisualR));},undefined,e=>console.warn('No se pudo cargar Fobos',e));
  if(gltfLoader)gltfLoader.load('assets/models/deimos.glb',g=>{deimosFallback.visible=false;deimosBody.add(prep(g.scene,deimosVisualR));},undefined,e=>console.warn('No se pudo cargar Deimos',e));
 }
 let raf=0,disposed=false,last=performance.now(),dragging=false,pointerId=null,prevX=0,prevY=0,lastMarker=-Infinity;
 const manual={mars:{yaw:0,pitch:0,targetYaw:0,targetPitch:0,spin:0,released:0},moon:{yaw:0,pitch:0,targetYaw:0,targetPitch:0,spin:0,released:0},phobos:{yaw:0,pitch:0,targetYaw:0,targetPitch:0,spin:0,released:0},deimos:{yaw:0,pitch:0,targetYaw:0,targetPitch:0,spin:0,released:0}};
 const focus={index:-1,zoom:0,yaw:0,pitch:0};
 let dragTarget=key==='mars'?'mars':'moon',baseZ=key==='mars'?13:9.25;
 const raycaster=new THREE.Raycaster(),pt=new THREE.Vector2();
 const changeTarget=(subject)=>{
  if(key!=='mars'||!['mars','phobos','deimos'].includes(subject))return;
  dragTarget=subject;
  document.querySelectorAll('[data-vr-moon]').forEach(b=>b.classList.toggle('active',b.dataset.vrMoon===subject));
  const facts={phobos:'Fobos: radio orbital real de 9,377 km, período de 7 h 39 min.',deimos:'Deimos: radio orbital real de 23,460 km, período de 30 h 21 min.',mars:'Arrastra Marte para rotarlo.'};
  el('vr-moon-hint').textContent=facts[subject]+' Arrastra para girar.';
 };
 const moonButtons=[...document.querySelectorAll('[data-vr-moon]')];
 const buttonListeners=moonButtons.map(b=>{const fn=()=>changeTarget(b.dataset.vrMoon);b.addEventListener('click',fn);return [b,fn];});
 const markers=[...el('vr-hotspots').querySelectorAll('.vr-hotspot')];
 function resize(){
  if(disposed)return;
  const w=Math.max(1,host.clientWidth),h=Math.max(1,host.clientHeight);
  camera.aspect=w/h;camera.updateProjectionMatrix();
  baseZ=key==='mars'?(window.innerWidth<600?14.6:13):(window.innerWidth<600?11.2:9.25);
  renderer.setSize(w,h,false);
  if(phobosOrbit){phobosOrbit.position.copy(planet.position);deimosOrbit.position.copy(planet.position);}
 }
 let pendingResize=0;
 const observer=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{
  if(!pendingResize)pendingResize=requestAnimationFrame(()=>{pendingResize=0;resize();});
 }):null;
 observer?.observe(host);
 function refreshMarkers(){
  if(disposed)return;planet.updateMatrixWorld(true);camera.updateMatrixWorld(true);
  const width=host.clientWidth,height=host.clientHeight,camPos=camera.position;
  let activePoint=null;
  anchors.forEach((anchor,i)=>{
   const btn=markers[i];if(!btn)return;
   const pos=anchor.getWorldPosition(new THREE.Vector3());const normal=pos.clone().normalize();const towardCam=camPos.clone().sub(pos).normalize();
   const front=normal.dot(towardCam)>.075, projected=pos.clone().project(camera);
   const x=(projected.x*.5+.5)*width,y=(-projected.y*.5+.5)*height;
   const inside=x>14&&x<width-14&&y>14&&y<height-14&&projected.z<1;
   btn.hidden=!front||!inside;
   // CSS translate moves in the compositor, preserving the button's centering transform.
   btn.style.left='0px';btn.style.top='0px';btn.style.translate=x.toFixed(2)+'px '+y.toFixed(2)+'px';
   btn.dataset.x=x.toFixed(2);btn.dataset.y=y.toFixed(2);
   btn.classList.toggle('found',state.discovered[key].has(i));btn.classList.toggle('active',state.selected===i);
   if(key==='moon')updateLunarMarker(btn,i);
   if(key==='moon'&&state.selected===i&&front&&inside)activePoint={x,y};
  });
  if(key==='moon')renderSurfaceArtifacts(activePoint);
 }
 function focusOn(index){
  if(key!=='moon'||!d.items[index])return;
  focus.index=index;
  const m=d.items[index],lon=m.lon*Math.PI/180,lat=m.lat*Math.PI/180;
  // Rotate the selected lunar coordinate into view. Preserve shortest angular path.
  const desired=-lon;
  focus.yaw=desired+Math.round((planet.rotation.y-desired)/(Math.PI*2))*Math.PI*2;
  focus.pitch=Math.max(-.89,Math.min(.89,lat));
 }
 function clearFocus(){
  focus.index=-1;
  manual.moon.spin=planet.rotation.y+.45-manual.moon.yaw;
  manual.moon.targetYaw=manual.moon.yaw;
  manual.moon.targetPitch=manual.moon.pitch;
 }
 function down(e){
  if(e.button!==0||disposed)return;
  if(key==='mars'&&phobosBody){
   const rect=renderer.domElement.getBoundingClientRect();pt.set(2*(e.clientX-rect.left)/rect.width-1,1-2*(e.clientY-rect.top)/rect.height);raycaster.setFromCamera(pt,camera);
   const hits=raycaster.intersectObjects([phobosBody,deimosBody,planet],true);
   if(hits.length){let hit=hits[0].object;while(hit){if(hit===phobosBody){changeTarget('phobos');break;}if(hit===deimosBody){changeTarget('deimos');break;}if(hit===planet){changeTarget('mars');break;}hit=hit.parent;}}
  }
  dragging=true;pointerId=e.pointerId;prevX=e.clientX;prevY=e.clientY;
  try{renderer.domElement.setPointerCapture(e.pointerId);}catch(_){}
  e.preventDefault();
 }
 function move(e){
  if(!dragging||e.pointerId!==pointerId)return;
  const dx=e.clientX-prevX,dy=e.clientY-prevY;prevX=e.clientX;prevY=e.clientY;
  if(key==='moon'&&focus.index>=0){
   focus.yaw+=dx*.0046;focus.pitch=Math.max(-1.2,Math.min(1.2,focus.pitch+dy*.0046));
  }else{
   const m=manual[dragTarget];m.targetYaw+=dx*.0052;m.targetPitch=Math.max(-1.25,Math.min(1.25,m.targetPitch+dy*.0052));
  }
  e.preventDefault();
 }
 function up(e){if(!dragging||(e&&e.pointerId!==pointerId))return;dragging=false;manual[dragTarget].released=performance.now();try{renderer.domElement.releasePointerCapture(pointerId);}catch(_){}pointerId=null;}
 renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointermove',move);renderer.domElement.addEventListener('pointerup',up);renderer.domElement.addEventListener('pointercancel',up);
 window.addEventListener('resize',resize);resize();
 function frame(t){
  raf=requestAnimationFrame(frame);
  if(disposed||document.hidden){last=t;return;}
  const dt=Math.min((t-last)/1000,.065);last=t;
  const smooth=1-Math.exp(-dt*16),camSmooth=1-Math.exp(-dt*5.2);
  for(const [name,m] of Object.entries(manual)){
   if(!(name==='moon'&&focus.index>=0))m.spin+=dt*(name==='phobos'?.28:name==='deimos'?.18:.10);
   if(!dragging||dragTarget!==name){
    if(t-m.released>3400 && !(name==='moon'&&focus.index>=0)){
     const damp=Math.exp(-dt*1.08);m.targetYaw*=damp;m.targetPitch*=damp;
    }
   }
   m.yaw+=(m.targetYaw-m.yaw)*smooth;m.pitch+=(m.targetPitch-m.pitch)*smooth;
  }
  focus.zoom+=(Number(focus.index>=0)-focus.zoom)*camSmooth;
  const parent=manual[key];
  const desiredYaw=focus.index>=0?focus.yaw:parent.spin-.45+parent.yaw;
  const desiredPitch=focus.index>=0?focus.pitch:parent.pitch;
  planet.rotation.y+=(desiredYaw-planet.rotation.y)*smooth;
  planet.rotation.x+=(desiredPitch-planet.rotation.x)*smooth;
  const apolloFocus=key==='moon'&&focus.index===0;
  const goalZ=key==='moon'&&focus.index>=0?(apolloFocus?(innerWidth<700?4.2:3.55):(innerWidth<700?5.85:5.1)):baseZ;
  // Zoom continues smoothly even when the side panels change the canvas width.
  camera.position.z+=(goalZ-camera.position.z)*camSmooth;
  const goalX=key==='moon'&&focus.index>=0&&innerWidth>=700?(apolloFocus?0.25:2.05):0;
  camera.position.x+=(goalX-camera.position.x)*camSmooth;
  if(phobosOrbit){
   phobosOrbit.rotation.y+=dt*.42;deimosOrbit.rotation.y+=dt*.11;
   phobosBody.rotation.y=manual.phobos.spin+manual.phobos.yaw;phobosBody.rotation.x=manual.phobos.pitch;
   deimosBody.rotation.y=manual.deimos.spin+manual.deimos.yaw;deimosBody.rotation.x=manual.deimos.pitch;
  }
  renderer.render(scene,camera);
  if(t-lastMarker>(dragging||focus.index>=0?28:55)){refreshMarkers();lastMarker=t;}
 }
 raf=requestAnimationFrame(frame);
 state.render={refreshMarkers,focusOn,clearFocus,destroy(){
  disposed=true;cancelAnimationFrame(raf);cancelAnimationFrame(pendingResize);observer?.disconnect();window.removeEventListener('resize',resize);
  buttonListeners.forEach(([b,fn])=>b.removeEventListener('click',fn));
  tex.dispose();bump.dispose();planet.geometry.dispose();planet.material.dispose();renderer.dispose();renderer.domElement.remove();
 }};
}
function makeFallback(){
 el('vr-fallback').hidden=false;
 if(state.world==='mars'){document.querySelectorAll('[data-vr-moon]').forEach(b=>b.onclick=()=>{el('vr-moon-hint').textContent=b.dataset.vrMoon==='phobos'?'Fobos: 22.2 km, orbita Marte en 7 h 39 min.':'Deimos: 12.6 km, orbita Marte en 30 h 21 min.';});}
 const pos=[[34,40],[60,31],[39,59],[65,60],[52,53],[43,26],[60,74],[32,70],[72,39]];
 el('vr-hotspots').querySelectorAll('.vr-hotspot').forEach((btn,i)=>{btn.hidden=false;btn.style.left=pos[i%pos.length][0]+'%';btn.style.top=pos[i%pos.length][1]+'%';btn.classList.toggle('found',state.discovered[state.world].has(i));if(state.world==='moon')updateLunarMarker(btn,i);});
 state.render={focusOn(){},clearFocus(){},refreshMarkers(){el('vr-hotspots').querySelectorAll('.vr-hotspot').forEach((btn,i)=>{btn.classList.toggle('found',state.discovered[state.world].has(i));btn.classList.toggle('active',state.selected===i);if(state.world==='moon')updateLunarMarker(btn,i);}); if(state.world==='moon') renderSurfaceArtifacts(); else clearSurfaceArtifacts();},destroy(){clearSurfaceArtifacts();}};
 toast('Vista alternativa: para rotación 3D se requiere WebGL y conexión a Three.js.');
}
document.querySelectorAll('[data-vr-world]').forEach(b=>b.addEventListener('click',()=>enterWorld(b.dataset.vrWorld)));
el('vr-return').addEventListener('click',leaveWorld);
el('vr-relaunch').addEventListener('click',()=>{if(state.world)launchRocket();});
el('vr-quiz-open').addEventListener('click',showQuiz);
el('vr-filter').addEventListener('input',renderCatalog);
window.addEventListener('cosmic-language-change',()=>{
 if(!state.world)return;
 const key=state.world;
 el('vr-title').textContent=tr('vr.world.'+key+'.title','Explora '+(key==='moon'?'la Luna':'Marte'));
 el('vr-subtitle').textContent=tr('vr.'+key+'.intro',WORLDS[key].intro);
 el('vr-world-tag').textContent=tr('vr.world.'+key+'.tag',WORLDS[key].tag);
 el('vr-sector').textContent=tr('vr.world.'+key+'.sector',WORLDS[key].sector);
 renderCatalog();updateProgress();
 if(state.selected>=0){const mission=state.selected,selectedItem=state.objectSelected;inspect(mission);if(key==='moon'&&selectedItem>=0)selectLunarObject(mission,selectedItem);}
 if(state.quizOpen)showQuiz();
 if(state.detailOpen&&key==='moon')populateDiscovery(state.selected);
 clearSurfaceArtifacts();document.querySelectorAll('#vr-hotspots .vr-hotspot').forEach((b,i)=>{if(key==='moon')updateLunarMarker(b,i,true);});state.render?.refreshMarkers();
});

document.addEventListener('keydown',(e)=>{if(e.key==='Escape'&&state.world&&!el('vr-object-modal').open){if(state.detailOpen)closeDiscovery();else leaveWorld();}});
