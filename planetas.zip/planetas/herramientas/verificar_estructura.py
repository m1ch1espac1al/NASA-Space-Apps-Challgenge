#!/usr/bin/env python3
"""Verifica rutas locales de Cosmic Legacy sin herramientas externas.
Ejecuta desde cualquier ubicación: python herramientas/verificar_estructura.py
"""
from pathlib import Path
from urllib.parse import urlsplit
import re, sys

BASE=Path(__file__).resolve().parent.parent
errors=[]

def check(ref, owner, owner_dir=None):
    if not ref or ref.startswith(('#','http:','https:','data:','mailto:','//')):return
    ref=urlsplit(ref).path.strip()
    if not ref or ref.startswith('javascript:'):return
    path=(owner_dir or BASE)/ref
    if not path.exists():errors.append(f'{owner}: falta {ref} -> {path.relative_to(BASE) if path.is_relative_to(BASE) else path}')

for filename in ('index.php','realidad-virtual.php'):
    src=BASE/filename
    html=src.read_text(encoding='utf-8')
    for tag in re.findall(r'<(?:script|link|img|a)\b[^>]*>',html,flags=re.I):
        for ref in re.findall(r'(?:src|href)=["\']([^"\']+)',tag):
            check(ref, filename)

for file in (BASE/'assets'/'css').glob('*.css'):
    css=file.read_text(encoding='utf-8')
    for ref in re.findall(r'url\(\s*["\']?([^\)"\']+)',css):check(ref.strip(),str(file.relative_to(BASE)),file.parent)

for file in (BASE/'assets'/'js').rglob('*.js'):
    js=file.read_text(encoding='utf-8')
    for ref in re.findall(r"(?:from\s*|import\s*\()[\"'](\.{1,2}/[^\"']+)[\"']",js):
        check(ref, str(file.relative_to(BASE)),file.parent)
    for ref in re.findall(r"[\"'](assets/(?:img|models)/[^'\"\s?]+)",js):
        if '${' not in ref:check(ref,str(file.relative_to(BASE)))

for file in ('apollo11-eagle.glb','deimos.glb','phobos.glb'):
    check('assets/models/'+file,'modelos 3D')

if errors:
    print('❌ Errores de rutas:')
    for e in sorted(set(errors)):print(' -',e)
    sys.exit(1)
print('✅ Estructura verificada: dos páginas, estilos, scripts e imágenes/modelos locales encontrados.')
