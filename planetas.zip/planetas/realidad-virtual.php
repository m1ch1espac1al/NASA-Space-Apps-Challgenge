<?php // Cosmic Legacy · archivo interactivo inmersivo, no requiere MySQL. ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#030713">
<meta name="description" content="Explora el legado de los equipos de NASA en la Luna y Marte en una experiencia tridimensional educativa.">
<title>Realidad virtual | Cosmic Legacy</title>
<link rel="stylesheet" href="assets/css/realidad-virtual.css?v=estructurado1">
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.1/examples/jsm/"}}</script>
</head>
<body>
<div class="cosmos-backdrop" aria-hidden="true"></div>
<div class="grain" aria-hidden="true"></div>
<main class="vr-shell">
  <header class="vr-topbar">
    <a href="index.php" class="brand" aria-label="Regresar al inicio de Cosmic Legacy"><span class="brand-orb"><img src="assets/img/cosmic-mark.svg" alt="" aria-hidden="true"></span><span>COSMIC<span class="brand-accent">LEGACY</span></span></a>
    <div class="header-divider" aria-hidden="true"></div>
    <span class="header-tag" data-i18n="vr.header">ARCHIVO ESPACIAL INTERACTIVO</span>
    <div class="top-actions">
      <span class="mode-badge"><span></span> <span data-i18n="vr.mode">EXPERIENCIA 3D</span></span>
      <div class="lang-switch" role="group" aria-label="Idioma / Language"><button type="button" data-lang="es" aria-pressed="true" aria-label="Español" title="Español">ES</button><button type="button" data-lang="en" aria-pressed="false" aria-label="English" title="English">EN</button></div><a class="back-link" href="index.php" data-i18n="vr.home">← Inicio</a>
    </div>
  </header>

  <section id="vr-gateway" class="vr-gateway" aria-labelledby="gateway-title">
    <div class="gateway-copy">
      <p class="micro-label">COSMIC LEGACY <span> / </span> <span data-i18n="vr.mission01">MISIÓN 01</span></p>
      <h1 id="gateway-title"><span data-i18n="vr.gateway1">ELLOS PARTIERON.</span><br><em data-i18n="vr.gateway2">SU LEGADO PERMANECE.</em></h1>
      <p data-i18n="vr.intro">Viaja a los mundos que guardan las huellas de nuestras misiones. Descubre módulos, vehículos e instrumentos y averigua qué nos enseñaron.</p>
      <div class="gateway-instructions"><span data-i18n="vr.step1">01 · ELIGE UN DESTINO</span><i></i><span data-i18n="vr.step2">02 · EXPLORA LOS VESTIGIOS</span><i></i><span data-i18n="vr.step3">03 · SUPERA EL RETO</span></div>
    </div>
    <div class="destination-grid" aria-label="Selecciona un destino">
      <button type="button" class="destination destination-moon" data-vr-world="moon">
        <span class="destination-top"><span data-i18n="vr.destination01">DESTINO 01</span><span class="destination-icon">↗</span></span>
        <span class="destination-world"><img src="assets/img/moon-animated.webp" alt="" draggable="false"></span>
        <span class="destination-bottom"><span class="destination-name" data-i18n="planet.moon.name">LA LUNA</span><span class="destination-count" data-i18n="vr.moon.count">4 descubrimientos históricos</span><span class="destination-arrow" data-i18n="vr.begin">INICIAR EXPLORACIÓN ↗</span></span>
      </button>
      <button type="button" class="destination destination-mars" data-vr-world="mars">
        <span class="destination-top"><span data-i18n="vr.destination02">DESTINO 02</span><span class="destination-icon">↗</span></span>
        <span class="destination-world"><img src="assets/img/mars-animated.webp" alt="" draggable="false"></span>
        <span class="destination-bottom"><span class="destination-name" data-i18n="planet.mars.name">MARTE</span><span class="destination-count" data-i18n="vr.mars.count">9 descubrimientos robóticos</span><span class="destination-arrow" data-i18n="vr.begin">INICIAR EXPLORACIÓN ↗</span></span>
      </button>
    </div>
    <p class="gateway-disclaimer" data-i18n="vr.disclaimer">Experiencia recreativa y educativa. No es un inventario completo de todos los objetos ni un mapa de posiciones exactas. No afiliado a NASA.</p>
  </section>

  <section id="vr-game" class="vr-game" aria-label="Expedición espacial educativa" hidden>
    <div class="game-toolbar">
      <div class="game-toolbar-left"><button id="vr-return" type="button" class="vr-back-button" data-i18n="vr.back">← ELEGIR MUNDO</button><span class="toolbar-divider"></span><span class="micro-label" id="vr-sector">EXPEDICIÓN LUNAR</span></div>
      <div class="game-toolbar-right"><span class="game-counter"><span id="vr-progress-top">0 / 4</span> <span data-i18n="vr.found">ENCONTRADOS</span></span><button id="vr-relaunch" type="button" class="ring-button" data-i18n="vr.rings">◎ ACTIVAR ANILLOS CÓSMICOS</button></div>
    </div>
    <div class="game-columns">
      <aside class="archive-panel">
        <p class="micro-label" data-i18n="vr.log">BITÁCORA DE LA EXPEDICIÓN</p>
        <h2 id="vr-title">Explora la Luna</h2>
        <p id="vr-subtitle" class="archive-intro">Descubre los objetos que quedaron en la superficie.</p>
        <div class="progress-caption"><span data-i18n="vr.documented">OBJETOS DOCUMENTADOS</span><span id="vr-progress-label">0 de 4</span></div>
        <div class="progress-track"><div id="vr-progress-bar"></div></div>
        <div class="archive-searchbox"><span aria-hidden="true">⌕</span><input id="vr-filter" type="search" placeholder="Buscar misión..." data-i18n-placeholder="vr.search" aria-label="Buscar misión en el archivo" autocomplete="off"></div>
        <div class="archive-list" id="vr-mission-list" role="group" aria-label="Vestigios y misiones"></div>
        <p class="archive-foot" data-i18n="vr.archivefoot">Selecciona los marcadores del planeta o cualquier registro. Los puntos son ilustrativos, no coordenadas reales.</p>
      </aside>
      <section class="globe-stage" aria-label="Planeta interactivo tridimensional">
        <div class="stage-head"><span class="micro-label"><span data-i18n="vr.observation">ESTACIÓN DE OBSERVACIÓN</span> <span aria-hidden="true">//</span> <span id="vr-world-tag">LUNA</span></span><span class="online-dot" data-i18n="vr.online">EN LÍNEA</span></div>
        <div class="stage-visual" id="vr-stage-visual">
          <div id="vr-cosmos-rings" class="cosmos-rings" aria-hidden="true"><span class="cosmos-ring ring-one"></span><span class="cosmos-ring ring-two"></span><span class="cosmos-ring ring-three"></span><span class="cosmos-ring ring-flash"></span></div>
          <div class="globe-halo" aria-hidden="true"></div>
          <div id="vr-three-host" class="vr-three-host" aria-label="Globo tridimensional; arrastra para rotarlo"></div>
          <div id="vr-fallback" class="vr-fallback" hidden><img id="vr-fallback-img" src="assets/img/moon-animated.webp" alt="Vista del planeta"></div>
          <div id="vr-hotspots" class="vr-hotspots" aria-label="Marcadores sobre el planeta"></div>
          <div id="vr-surface-items" class="vr-surface-items" aria-label="Piezas visibles sobre la superficie"></div>
          <div id="vr-moon-controls" class="vr-moon-controls" hidden>
            <button type="button" data-vr-moon="phobos">Fobos <small>22.2 km · 7 h 39 min</small></button>
            <button type="button" data-vr-moon="deimos">Deimos <small>12.6 km · 30 h 21 min</small></button>
            <p id="vr-moon-hint" data-i18n="vr.moonhint">Sus órbitas están representadas a escala visual, no a distancias reales.</p>
          </div>
          </div>
        <div class="stage-bottom"><span data-i18n="vr.drag">↔ ARRASTRA PARA GIRAR</span><span data-i18n="vr.points">✦ PULSA LOS PUNTOS LUMINOSOS</span></div>
        <div class="vr-toast" id="vr-toast" aria-live="polite"></div>
        <section id="vr-discovery-overlay" class="vr-discovery-overlay" aria-labelledby="vr-discovery-title" hidden>
          <div class="vr-discovery-top">
            <button type="button" id="vr-discovery-close" class="vr-discovery-close">← <span data-i18n="vr.discovery.back">VOLVER AL MAPA</span></button>
            <span id="vr-discovery-number" class="vr-discovery-number">HALLAZGO 01 / 04</span>
          </div>
          <aside id="vr-discovery-viewer" class="vr-discovery-viewer" hidden aria-label="Modelo 3D del hallazgo">
            <div class="vr-discovery-viewer-head">
              <span class="micro-label">VISTA APOLLO 11</span>
              <span class="vr-discovery-viewer-chip">EAGLE</span>
            </div>
            <div id="vr-apollo-viewer" class="vr-apollo-viewer"></div>
            <p class="vr-apollo-tip">Arrastra para mover la cámara y usa la rueda para acercar o alejar</p>
          </aside>
          <div class="vr-discovery-information">
            <p class="vr-discovery-kicker" data-i18n="vr.discovery.kicker">ARCHIVO LUNAR · DESCUBRIMIENTO</p>
            <h2 id="vr-discovery-title"></h2>
            <p id="vr-discovery-description" class="vr-discovery-description"></p>
            <h3 id="vr-discovery-equip-title" data-i18n="vr.discovery.equipment">EQUIPOS Y COMPONENTES</h3>
            <div id="vr-discovery-artifacts" class="vr-discovery-artifacts"></div>
            <p id="vr-discovery-note" class="vr-discovery-note"></p>
            <a id="vr-discovery-source" class="vr-discovery-source" target="_blank" rel="noopener noreferrer" href="https://www.nasa.gov/" data-i18n="vr.discovery.source">CONSULTAR FUENTE NASA ↗</a>
          </div>
        </section>
      </section>
      <aside class="evidence-panel" aria-labelledby="evidence-title">
        <div class="evidence-heading"><span class="micro-label" data-i18n="vr.record">REGISTRO DE DESCUBRIMIENTO</span><span class="data-number" id="vr-evidence-index">— / 04</span></div>
        <div id="vr-empty-detail" class="evidence-empty"><span class="empty-symbol">✧</span><h2 data-i18n="vr.emptytitle">Tu próximo descubrimiento te espera</h2><p data-i18n="vr.emptydesc">Busca una señal sobre el globo o selecciona un elemento en la bitácora.</p></div>
        <article id="vr-evidence-detail" class="evidence-detail" hidden>
          <span id="vr-evidence-type" class="evidence-type">VEHÍCULO LUNAR · 1971</span>
          <h2 id="evidence-title">Apollo 15</h2>
          <p id="vr-evidence-desc"></p>
          <section id="vr-object-lab" class="object-lab" aria-labelledby="vr-objects-title" hidden>
            <div class="object-lab-title"><span class="micro-label" data-i18n="vr.museum">MUSEO DE OBJETOS LUNARES</span><span id="vr-objects-count">0 PIEZAS</span></div>
            <h3 id="vr-objects-title" data-i18n="vr.left">¿Qué dejó esta misión?</h3>
            <p id="vr-object-warning" class="object-warning"></p>
            <div id="vr-object-choices" class="object-choices" aria-label="Elige una pieza para descubrirla"></div>
            <div id="vr-object-card" class="object-card" aria-live="polite">
              <div class="object-art-frame"><img id="vr-object-art" src="" alt="Representación visual del equipo lunar" loading="lazy"><span data-i18n="vr.diagram">ESQUEMA ILUSTRATIVO · NO A ESCALA</span></div>
              <div class="object-card-head"><span id="vr-object-kind">CLASE</span><span id="vr-object-status">ESTADO</span></div>
              <h4 id="vr-object-name"></h4>
              <dl class="object-facts">
                <div><dt data-i18n="vr.equipment.what">¿QUÉ ES?</dt><dd id="vr-object-what"></dd></div>
                <div><dt data-i18n="vr.equipment.purpose">¿PARA QUÉ SERVÍA?</dt><dd id="vr-object-purpose"></dd></div>
                <div><dt data-i18n="vr.equipment.fate">¿QUÉ OCURRIÓ?</dt><dd id="vr-object-fate"></dd></div>
                <div><dt data-i18n="vr.equipment.discovery">¿QUÉ APORTÓ?</dt><dd id="vr-object-discovery"></dd></div>
              </dl>
              <button id="vr-object-zoom" type="button" class="object-zoom" data-i18n="vr.expand">AMPLIAR Y LEER LA FICHA ↗</button>
              <a id="vr-object-source" class="object-nasa-link" target="_blank" rel="noopener noreferrer" href="https://www.nasa.gov/" data-i18n="vr.nasa">CONSULTAR FUENTE NASA ↗</a>
            </div>
            <p class="object-disclaimer" data-i18n="vr.objectdisclaimer">Selección educativa documentada. No representa un inventario completo de todos los objetos depositados en la Luna.</p>
          </section>
          <div class="why-it-matters"><span data-i18n="vr.lesson">¿QUÉ NOS ENSEÑÓ LA MISIÓN?</span><p id="vr-evidence-learn"></p></div>
          <a id="vr-evidence-source" href="https://science.nasa.gov/" target="_blank" rel="noopener noreferrer" class="source-link" data-i18n="vr.nasa">VER DOCUMENTACIÓN NASA ↗</a>
        </article>
        <div class="learning-challenge"><div class="challenge-top"><span data-i18n="vr.challenge">✦ RETO DE CONOCIMIENTO</span><span id="vr-challenge-status">BLOQUEADO</span></div><p id="vr-challenge-copy">Descubre al menos cuatro registros para desbloquear una pregunta.</p><div id="vr-quiz" hidden><p id="vr-question"></p><div id="vr-answers"></div><p id="vr-quiz-feedback" role="status"></p></div><button type="button" id="vr-quiz-open" disabled data-i18n="vr.unlock">DESBLOQUEAR RETO <span>↗</span></button></div>
      </aside>
    </div>
    <footer class="vr-footer"><span data-i18n="vr.footerdisclaimer">RECREACIÓN CIENTÍFICO-ARTÍSTICA · LOS MARCADORES NO SEÑALAN UBICACIONES EXACTAS</span><span data-i18n="vr.history">OBJETOS HISTÓRICOS: NO DEBEN TRATARSE COMO RESIDUOS PARA RECOLECTAR</span><span class="vr-team-credit"><span data-i18n="site.team">EQUIPO</span> · Estefanía · Fernanda · Ieshua Gabriel · Jocabeth · Jehieli · Lisset</span></footer>
  </section>
</main>
  <dialog id="vr-object-modal" class="object-modal" aria-labelledby="vr-object-modal-title">
    <button id="vr-object-modal-close" type="button" class="object-modal-close" aria-label="Cerrar ficha detallada">×</button>
    <div class="object-modal-grid">
      <div class="object-modal-image"><img id="vr-object-modal-img" alt="Ilustración del objeto lunar seleccionado"><small data-i18n="vr.notphoto">REPRESENTACIÓN ESQUEMÁTICA · NO FOTOGRAFÍA</small></div>
      <div class="object-modal-text"><span id="vr-object-modal-kind" class="micro-label">EQUIPO HISTÓRICO</span><h2 id="vr-object-modal-title"></h2>
        <p class="object-modal-status" id="vr-object-modal-status"></p>
        <h3 data-i18n="vr.equipment.what">¿Qué es?</h3><p id="vr-object-modal-what"></p>
        <h3 data-i18n="vr.equipment.purpose">¿Para qué se utilizó?</h3><p id="vr-object-modal-purpose"></p>
        <h3 data-i18n="vr.equipment.fate">¿Qué sucedió con él?</h3><p id="vr-object-modal-fate"></p>
        <h3 data-i18n="vr.equipment.discovery">¿Por qué importa?</h3><p id="vr-object-modal-discovery"></p>
        <a id="vr-object-modal-link" data-i18n="vr.originalsource" class="object-modal-link" href="https://science.nasa.gov" rel="noopener noreferrer" target="_blank">LEER DOCUMENTACIÓN ORIGINAL DE NASA ↗</a>
      </div>
    </div>
  </dialog>

<script src="assets/js/core/idiomas.js?v=estructurado1" defer></script>
<script type="module" src="assets/js/pages/realidad-virtual.js?v=estructurado1"></script>
</body>
</html>
