# COSMIC LEGACY — Código estructurado (base v34)

Proyecto web de exploración espacial educativa. **Esta reorganización se hizo directamente sobre la v34 verificada proporcionada por el usuario.** No incorpora cambios de versiones posteriores.

## Ejecutar con XAMPP

1. Copia la carpeta `planetas` completa en `C:\xampp\htdocs\`.
2. Inicia **Apache** desde el panel de control de XAMPP. No hace falta activar MySQL.
3. Abre `http://localhost/planetas/` o `http://localhost/planetas/index.php`.
4. Para el museo lunar/marciano, abre `http://localhost/planetas/realidad-virtual.php`.
5. Si acabas de reemplazar otra versión, presiona **Ctrl + F5**.

**Se requiere Internet** para Three.js y sus complementos cargados por CDN (los mapas de planetas, los modelos `.glb` y la mayor parte del contenido visual sí están incluidos localmente).

## ¿Dónde se cambia cada parte?

| Quiero cambiar… | Archivo |
| --- | --- |
| La portada, sus paneles o el menú | `index.php` |
| Las órbitas, rotación, cometas y zoom en portada | `assets/js/pages/inicio.js` |
| Los colores, tamaños y disposición de portada | `assets/css/inicio.css` |
| El museo y sus controles en HTML | `realidad-virtual.php` |
| Los `?`, misiones, progreso y mecánica del museo | `assets/js/pages/realidad-virtual.js` |
| El aspecto del museo | `assets/css/realidad-virtual.css` |
| Las piezas físicas documentadas de misiones lunares | `assets/js/data/equipos-lunares.js` |
| Las traducciones ES/EN | `assets/js/core/idiomas.js` |
| El renderizado de Apollo 11 | `assets/js/viewers/apollo11.js` |
| El renderizado de Apollo 15 | `assets/js/viewers/apollo15.js` |
| Los mapas y demás imágenes | `assets/img/` |
| Los modelos GLB de Apollo 11, Fobos y Deimos | `assets/models/` |

**Importante:** los estilos de las versiones anteriores se conservaron en `docs/historial/estilos-originales/` como respaldo, pero **no son utilizados** por la web. Modifica solo los dos archivos CSS activos.

Para ver el árbol de carpetas, las dependencias y el funcionamiento del museo, consulta [docs/ESTRUCTURA.md](docs/ESTRUCTURA.md).

## Alcance

- Mantiene el comportamiento y los recursos de la v34 subida: órbita interactiva, zoom, navegación, ES/EN, modelos y museo lunar/marciano.
- Se reorganizaron los scripts por responsabilidad y se consolidaron 24 estilos históricos en 2 archivos activos en el mismo orden que el original.
- Se corrigieron dos referencias antiguas a imágenes inexistentes (`space-bg.jpg` y `milky-way-user.jpg`) con un fondo espacial que ya venía en el ZIP; fuera de ello no se modificó la lógica.
- **No se reescribió** la lógica Three.js de los planetas ni los modelos. Los archivos voluminosos de `inicio.js` y `realidad-virtual.js` permanecen intactos, salvo las rutas de importación.
- Las posiciones de marcadores y las proporciones de las órbitas son ilustrativas, no coordenadas científicas exactas.
- No incluye MySQL ni archivo SQL, porque esta versión no lo requiere.

## Verificación

Desde la carpeta `planetas`:

```bash
python herramientas/verificar_estructura.py
```

El script usa solo la biblioteca estándar de Python. Comprueba las rutas locales, HTML y modelos esperados. Para ejecutar la web se necesita PHP/XAMPP y un navegador con WebGL para el 3D.
